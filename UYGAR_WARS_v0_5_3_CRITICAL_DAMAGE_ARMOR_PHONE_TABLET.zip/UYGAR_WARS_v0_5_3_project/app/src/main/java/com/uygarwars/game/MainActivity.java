package com.uygarwars.game;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private GameSurface gameSurface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        try {
            gameSurface = new GameSurface(this);
            setContentView(gameSurface);
            applyImmersiveMode();
        } catch (Throwable firstError) {
            getSharedPreferences("uygar_wars", MODE_PRIVATE).edit()
                    .remove("campaign_level")
                    .remove("upgrade_points")
                    .remove("statue_upgrade")
                    .remove("miner_upgrade")
                    .remove("sword_upgrade")
                    .remove("spear_power_upgrade")
                    .remove("spear_range_upgrade")
                    .remove("archer_upgrade")
                    .remove("diamonds")
                    .remove("mine_depth")
                    .remove("mine_progress")
                    .apply();
            System.gc();
            try {
                gameSurface = new GameSurface(this);
                setContentView(gameSurface);
                applyImmersiveMode();
            } catch (Throwable secondError) {
                showStartupError(secondError);
            }
        }
    }

    /**
     * Applies fullscreen mode only after the decor view exists.
     * Android 16 may throw inside PhoneWindow#getInsetsController when this is
     * requested before setContentView. Using the decor view and posting the
     * API 30+ operation avoids that framework-side null dereference.
     */
    private void applyImmersiveMode() {
        final Window window = getWindow();
        if (window == null) return;

        final View decorView = window.getDecorView();
        if (decorView == null) return;

        // Reliable fallback for every supported Android version.
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            decorView.post(() -> {
                try {
                    window.setDecorFitsSystemWindows(false);
                    WindowInsetsController controller = decorView.getWindowInsetsController();
                    if (controller != null) {
                        controller.hide(
                                WindowInsets.Type.statusBars()
                                        | WindowInsets.Type.navigationBars()
                        );
                        controller.setSystemBarsBehavior(
                                WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                        );
                    }
                } catch (Throwable ignored) {
                    // The legacy flags above keep the game fullscreen even if
                    // a device-specific WindowInsets implementation fails.
                }
            });
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersiveMode();
    }

    @Override
    protected void onResume() {
        super.onResume();
        applyImmersiveMode();
        if (gameSurface != null) {
            gameSurface.resumeGame();
        }
    }

    @Override
    protected void onPause() {
        if (gameSurface != null) {
            gameSurface.pauseGame();
        }
        super.onPause();
    }

    private void showStartupError(Throwable error) {
        TextView errorView = new TextView(this);
        errorView.setBackgroundColor(Color.rgb(15, 23, 42));
        errorView.setTextColor(Color.WHITE);
        errorView.setGravity(Gravity.CENTER);
        errorView.setTextSize(18f);
        String detail = error == null ? "Bilinmeyen hata"
                : error.getClass().getSimpleName() + ": " + String.valueOf(error.getMessage());
        errorView.setText("UYGAR WARS BAŞLANGIÇ HATASI\n\n" + detail
                + "\n\nBu ekranın fotoğrafını gönder.");
        setContentView(errorView);
        applyImmersiveMode();
    }
}

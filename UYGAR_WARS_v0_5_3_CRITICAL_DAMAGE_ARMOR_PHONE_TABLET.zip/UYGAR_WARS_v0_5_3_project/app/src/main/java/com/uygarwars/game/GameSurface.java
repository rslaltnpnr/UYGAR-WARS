package com.uygarwars.game;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.SystemClock;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public final class GameSurface extends SurfaceView implements SurfaceHolder.Callback, Runnable {
    private enum Screen { MENU, HUB_BATTLE, HUB_PROGRESS, HUB_ECONOMY, HUB_SYSTEM, MAP, ARENA, MISSIONS, HERO, UPGRADES, SHOP, MINE, SETTINGS, PLAYING, PAUSED, WIN, LOSE }
    private enum UnitType { MINER, SWORD, SPEAR, ARCHER }
    private enum DamageType { CUT, PIERCE, IMPACT }
    private enum CommandMode { ATTACK, DEFEND }
    private enum FormationMode { LINE, SHIELD_WALL, RANGED }

    private static final float BASE_MAX_HP = 1900f;
    private static final long PLAY_FRAME_MS = 16L;
    private static final long IDLE_FRAME_MS = 100L;
    private static final int PLAYER_MINE_COUNT = 3;
    private static final int MINER_TO_MINE = 0;
    private static final int MINER_MINING = 1;
    private static final int MINER_TO_BASE = 2;
    private static final int MINER_IDLE = 3;
    private static final int PROJECTILE_ARROW = 0;
    private static final int PROJECTILE_SPEAR = 1;

    private static final int GOLD = Color.rgb(226, 173, 62);
    private static final int GOLD_LIGHT = Color.rgb(255, 216, 112);
    private static final int PANEL = Color.rgb(13, 20, 34);
    private static final int PANEL_2 = Color.rgb(22, 31, 48);
    private static final int BLUE = Color.rgb(63, 142, 222);
    private static final int RED = Color.rgb(199, 61, 56);

    private final SurfaceHolder surfaceHolder;
    private final Object stateLock = new Object();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random();
    private final List<Unit> playerUnits = new ArrayList<>();
    private final List<Unit> enemyUnits = new ArrayList<>();
    private final List<Projectile> projectiles = new ArrayList<>();
    private final List<Impact> impacts = new ArrayList<>();
    private final List<FloatingText> floatingTexts = new ArrayList<>();
    private final List<Particle> particles = new ArrayList<>();
    private final List<DeathEffect> deathEffects = new ArrayList<>();
    private final float[] playerMineGold = new float[PLAYER_MINE_COUNT];
    private final float[] playerMineMaxGold = new float[PLAYER_MINE_COUNT];
    private final SharedPreferences preferences;
    private final float density;

    // v0.4.2: müzik ve efekt kanalları ayrı yönetilir; her krallığın kendi savaş müziği vardır.
    private SoundPool soundPool;
    private MediaPlayer musicPlayer;
    private boolean musicEnabled;
    private boolean effectsEnabled;
    private int musicVolumeLevel;
    private int effectsVolumeLevel;
    private int currentMusicTrack;
    private int sndSwordHit;
    private int sndArrowShot;
    private int sndPickaxeHit;
    private int sndInjury;
    private int sndFootstep;
    private int sndSpearThrow;
    private int sndSpearHit;
    private int sndBaseHit;
    private int sndBossEntry;
    private int sndWarCry;
    private int sndShield;
    private int sndArrowRain;
    private int sndVictory;
    private int sndDefeat;
    private float swordSfxCooldown;
    private float arrowSfxCooldown;
    private float pickaxeSfxCooldown;
    private float baseSfxCooldown;
    private float injurySfxCooldown;
    private float footstepSfxCooldown;
    private float spearSfxCooldown;

    // Telefon ve tabletlerde aynı sahne oranını korurken arayüzü okunabilir tutan
    // uyarlanabilir ölçüler. Bu değerler ekran değiştiğinde yeniden hesaplanır.
    private boolean tabletLayout;
    private float uiScale = 1f;
    private float safePadding = 14f;
    private float baseInset = 132f;
    private float cacheRenderScale = 1f;

    // Koyu degradelerin bazı cihazlarda iki farklı Surface tamponu arasında
    // renk atlaması yapmasını önlemek için sahne ARGB_8888 bitmaplere önceden çizilir.
    private Bitmap backgroundCache;
    private Bitmap menuCache;
    private int cacheWidth = -1;
    private int cacheHeight = -1;
    private int cacheThemeKey = -1;
    private int menuCacheWins = -1;
    private int menuCacheProgressHash = -1;
    private boolean cacheDisabled;

    private volatile boolean running;
    private volatile boolean surfaceReady;
    private Thread gameThread;
    private Throwable fatalError;

    private Screen screen = Screen.MENU;
    private float width;
    private float height;
    private float groundY;
    private float worldWidth;
    private float cameraX;
    private float touchDownX;
    private float touchDownY;
    private float touchStartCameraX;
    private float manualCameraHoldTimer;
    private boolean cameraDragEligible;
    private boolean cameraDragging;
    private CommandMode commandMode = CommandMode.ATTACK;
    private FormationMode formationMode = FormationMode.LINE;
    private long lastFrame;

    private float playerBaseHp;
    private float enemyBaseHp;
    private float gold;
    private float enemyGold;
    private float enemySpawnClock;
    private float passiveGoldClock;
    private float elapsed;
    private int wave;
    private int wins;
    private int campaignLevel;
    private int battleLevel;
    private int mapSelectedLevel;
    private int mapPage;
    private final int[] levelStars = new int[51];
    private final boolean[] bossRewardClaimed = new boolean[51];
    private final boolean[] chapterRewardClaimed = new boolean[6];
    private int bossesDefeated;
    private int earnedStarsThisBattle;
    private int replayRewardDiamonds;
    private int earnedChapterDiamonds;
    private int earnedChapterPoints;
    private boolean firstClearBattle;
    private boolean bossSpawned;
    private boolean bossDefeated;
    private boolean campaignRecordsDirty;
    private float bossBannerTimer;
    private float chapterBannerTimer;
    private float bossShieldToastCooldown;
    private int upgradePoints;
    private int statueUpgradeLevel;
    private int minerUpgradeLevel;
    private int swordUpgradeLevel;
    private int spearPowerLevel;
    private int spearRangeLevel;
    private int archerUpgradeLevel;
    private int minerOutfitOwned;
    private int swordOutfitOwned;
    private int spearOutfitOwned;
    private int archerOutfitOwned;
    private int minerOutfitEquipped;
    private int swordOutfitEquipped;
    private int spearOutfitEquipped;
    private int archerOutfitEquipped;
    private int diamondStatueBoost;
    private int diamondMinerBoost;
    private int diamondSwordBoost;
    private int diamondArcherBoost;
    private int commandersDefeated;
    private boolean shopPowerPage;
    private int completedLevel;
    private int earnedUpgradePoints;
    private int diamonds;
    private int mineDepth;
    private int mineProgressPermille;
    private int lastMineReward;
    private float mineLayerHp;
    private float mineLayerMaxHp;
    private float mineClock;
    private float mineSaveClock;
    private float resetConfirmTimer;

    // v0.2.4: kalıcı profil, günlük görevler, savaş sandığı ve başarımlar.
    private int profileXp;
    private int lifetimeWins;
    private int lifetimeKills;
    private int lifetimeMineLayers;
    private int battleChestProgress;
    private int battleChestsOpened;
    private int dailyDayKey;
    private int dailyWins;
    private int dailyMineLayers;
    private int dailyKills;
    private boolean dailyWinClaimed;
    private boolean dailyMineClaimed;
    private boolean dailyKillClaimed;
    private boolean dailyChestClaimed;
    private boolean missionsAchievementsPage;
    private final boolean[] achievementClaimed = new boolean[5];

    // v0.2.5: oyuncu komutanı, komutan seviyesi ve liderlik yetenekleri.
    private int heroLevel;
    private int heroXp;
    private int heroPowerLevel;
    private int heroArmorLevel;
    private int heroLeadershipLevel;
    private boolean heroSpawned;

    // v0.2.6: sonsuz arena, dalga rekorları ve arena ödülleri.
    // v0.2.7.2: arena orta hatta toplanır, kule/barikat devre dışıdır.
    private boolean arenaMode;
    private int arenaBestWave;
    private int arenaBestKills;
    private int arenaRuns;
    private int arenaKillsThisRun;
    private int arenaLastRewardWave;
    private int arenaRunStartDiamonds;
    private int arenaRunDiamondReward;
    private int arenaRunXpReward;
    private int arenaChampionsThisRun;
    private boolean arenaNewWaveRecord;
    private boolean arenaNewKillRecord;
    private float arenaChampionEntryTimer;
    private float arenaChampionEntryX;

    private boolean developerPanel;
    private boolean fullResetArmed;
    private boolean godMode;
    private float damageMultiplier = 1f;
    private float gameSpeed = 1f;
    private String toastText = "";
    private float toastTimer;
    private float playerBaseFlash;
    private float enemyBaseFlash;
    private float ambientClock;
    private float baseParticleClock;
    private float waveBannerTimer;
    private float commanderBannerTimer;
    private float warCryTimer;
    private float warCryCooldown;
    private float statueShieldTimer;
    private float statueShieldCooldown;
    private float arrowRainTimer;
    private float arrowRainCooldown;
    private float arrowRainCenterX;
    private float hitStopTimer;
    private float combatPulseTimer;
    private int combatPulseColor = Color.TRANSPARENT;
    private float resultPulseTimer;
    private boolean resultVictory;
    private int lastCommanderWave;
    private float screenShake;
    private boolean tacticalPanel;
    private boolean unitMenuOpen;
    private UnitType selectedUnitType = UnitType.SWORD;
    private float playerBarricadeHp;
    private float playerBarricadeMaxHp;
    private float playerTowerHp;
    private float playerTowerMaxHp;
    private float playerTowerCooldown;

    private final RectF startButton = new RectF();
    private final RectF categoryBattleButton = new RectF();
    private final RectF categoryProgressButton = new RectF();
    private final RectF categoryEconomyButton = new RectF();
    private final RectF categorySystemButton = new RectF();
    private final RectF hubPrimaryButton = new RectF();
    private final RectF hubSecondaryButton = new RectF();
    private final RectF hubTertiaryButton = new RectF();
    private final RectF mapMenuButton = new RectF();
    private final RectF arenaMenuButton = new RectF();
    private final RectF arenaStartButton = new RectF();
    private final RectF mapStartButton = new RectF();
    private final RectF mapPrevButton = new RectF();
    private final RectF mapNextButton = new RectF();
    private final RectF[] mapLevelButtons = new RectF[10];
    private final RectF upgradesButton = new RectF();
    private final RectF mineMenuButton = new RectF();
    private final RectF shopButton = new RectF();
    private final RectF settingsButton = new RectF();
    private final RectF missionsButton = new RectF();
    private final RectF heroMenuButton = new RectF();
    private final RectF heroPowerButton = new RectF();
    private final RectF heroArmorButton = new RectF();
    private final RectF heroLeadershipButton = new RectF();
    private final RectF missionDailyTabButton = new RectF();
    private final RectF missionAchievementTabButton = new RectF();
    private final RectF dailyWinButton = new RectF();
    private final RectF dailyMineButton = new RectF();
    private final RectF dailyKillButton = new RectF();
    private final RectF dailyChestButton = new RectF();
    private final RectF battleChestButton = new RectF();
    private final RectF[] achievementButtons = new RectF[5];
    private final RectF backButton = new RectF();
    private final RectF shopOutfitsTabButton = new RectF();
    private final RectF shopPowersTabButton = new RectF();
    private final RectF shopMinerOutfitButton = new RectF();
    private final RectF shopSwordOutfitButton = new RectF();
    private final RectF shopSpearOutfitButton = new RectF();
    private final RectF shopArcherOutfitButton = new RectF();
    private final RectF shopMinerBuyButton = new RectF();
    private final RectF shopSwordBuyButton = new RectF();
    private final RectF shopSpearBuyButton = new RectF();
    private final RectF shopArcherBuyButton = new RectF();
    private final RectF shopStatuePowerButton = new RectF();
    private final RectF shopMinerPowerButton = new RectF();
    private final RectF shopSwordPowerButton = new RectF();
    private final RectF shopArcherPowerButton = new RectF();
    private final RectF mineDigButton = new RectF();
    private final RectF pauseButton = new RectF();
    private final RectF pauseContinueButton = new RectF();
    private final RectF pauseRestartButton = new RectF();
    private final RectF pauseMenuButton = new RectF();
    private final RectF musicToggleButton = new RectF();
    private final RectF effectsToggleButton = new RectF();
    private final RectF musicVolumeButton = new RectF();
    private final RectF effectsVolumeButton = new RectF();
    private final RectF resetLevelButton = new RectF();
    private final RectF resetProgressButton = new RectF();
    private final RectF upgradeStatueButton = new RectF();
    private final RectF upgradeMinerButton = new RectF();
    private final RectF upgradeSwordButton = new RectF();
    private final RectF upgradeSpearCard = new RectF();
    private final RectF upgradeSpearPowerButton = new RectF();
    private final RectF upgradeSpearRangeButton = new RectF();
    private final RectF upgradeArcherButton = new RectF();
    private final RectF minerButton = new RectF();
    private final RectF swordButton = new RectF();
    private final RectF archerButton = new RectF();
    private final RectF spearButton = new RectF();
    private final RectF unitMenuToggleButton = new RectF();
    private final RectF quickUnitButton = new RectF();
    private final RectF speedHudButton = new RectF();
    private final RectF devButton = new RectF();
    private final RectF addGoldButton = new RectF();
    private final RectF damageButton = new RectF();
    private final RectF godButton = new RectF();
    private final RectF speedButton = new RectF();
    private final RectF attackButton = new RectF();
    private final RectF defendButton = new RectF();
    private final RectF warCryButton = new RectF();
    private final RectF statueShieldButton = new RectF();
    private final RectF arrowRainButton = new RectF();
    private final RectF tacticalButton = new RectF();
    private final RectF formationButton = new RectF();
    private final RectF barricadeButton = new RectF();
    private final RectF towerButton = new RectF();

    public GameSurface(Context context) {
        super(context);
        surfaceHolder = getHolder();
        surfaceHolder.setFormat(PixelFormat.RGBA_8888);
        surfaceHolder.addCallback(this);
        setFocusable(true);
        setKeepScreenOn(true);
        setHapticFeedbackEnabled(true);

        density = Math.max(1f, getResources().getDisplayMetrics().density);
        preferences = context.getSharedPreferences("uygar_wars", Context.MODE_PRIVATE);
        int legacySound = readIntPreference("sound_enabled", 1, 0, 1);
        musicEnabled = readIntPreference("music_enabled", legacySound, 0, 1) == 1;
        effectsEnabled = readIntPreference("effects_enabled", legacySound, 0, 1) == 1;
        musicVolumeLevel = readIntPreference("music_volume_level", 3, 1, 4);
        effectsVolumeLevel = readIntPreference("effects_volume_level", 3, 1, 4);
        initializeAudioLocked(context);
        wins = readIntPreference("wins", 0, 0, 9999);
        campaignLevel = readIntPreference("campaign_level", Math.max(1, wins + 1), 1, 50);
        battleLevel = campaignLevel;
        mapSelectedLevel = campaignLevel;
        mapPage = Math.max(0, Math.min(4, (campaignLevel - 1) / 10));
        bossesDefeated = readIntPreference("bosses_defeated", 0, 0, 99999);
        for (int level = 1; level <= 50; level++) {
            levelStars[level] = readIntPreference("level_stars_" + level, 0, 0, 3);
            bossRewardClaimed[level] = readIntPreference("boss_reward_" + level, 0, 0, 1) == 1;
        }
        for (int chapter = 1; chapter <= 5; chapter++) {
            chapterRewardClaimed[chapter] = readIntPreference("chapter_reward_" + chapter, 0, 0, 1) == 1;
        }
        for (int index = 0; index < mapLevelButtons.length; index++) {
            mapLevelButtons[index] = new RectF();
        }
        for (int index = 0; index < achievementButtons.length; index++) {
            achievementButtons[index] = new RectF();
        }
        upgradePoints = readIntPreference("upgrade_points", 0, 0, 9999);
        statueUpgradeLevel = readIntPreference("statue_upgrade", 1, 1, 5);
        minerUpgradeLevel = readIntPreference("miner_upgrade", 1, 1, 5);
        swordUpgradeLevel = readIntPreference("sword_upgrade", 1, 1, 5);
        spearPowerLevel = readIntPreference("spear_power_upgrade", 1, 1, 5);
        spearRangeLevel = readIntPreference("spear_range_upgrade", 1, 1, 5);
        archerUpgradeLevel = readIntPreference("archer_upgrade", 1, 1, 5);
        minerOutfitOwned = readIntPreference("miner_outfit_owned", 0, 0, 3);
        swordOutfitOwned = readIntPreference("sword_outfit_owned", 0, 0, 3);
        spearOutfitOwned = readIntPreference("spear_outfit_owned", 0, 0, 3);
        archerOutfitOwned = readIntPreference("archer_outfit_owned", 0, 0, 3);
        minerOutfitEquipped = Math.min(minerOutfitOwned,
                readIntPreference("miner_outfit_equipped", 0, 0, 3));
        swordOutfitEquipped = Math.min(swordOutfitOwned,
                readIntPreference("sword_outfit_equipped", 0, 0, 3));
        spearOutfitEquipped = Math.min(spearOutfitOwned,
                readIntPreference("spear_outfit_equipped", 0, 0, 3));
        archerOutfitEquipped = Math.min(archerOutfitOwned,
                readIntPreference("archer_outfit_equipped", 0, 0, 3));
        diamondStatueBoost = readIntPreference("diamond_statue_boost", 0, 0, 3);
        diamondMinerBoost = readIntPreference("diamond_miner_boost", 0, 0, 3);
        diamondSwordBoost = readIntPreference("diamond_sword_boost", 0, 0, 3);
        diamondArcherBoost = readIntPreference("diamond_archer_boost", 0, 0, 3);
        commandersDefeated = readIntPreference("commanders_defeated", 0, 0, 99999);
        diamonds = readIntPreference("diamonds", 0, 0, 999999);
        mineDepth = readIntPreference("mine_depth", 0, 0, 9999);
        mineProgressPermille = readIntPreference("mine_progress", 0, 0, 999);
        profileXp = readIntPreference("profile_xp", 0, 0, 99999999);
        lifetimeWins = readIntPreference("lifetime_wins", wins, 0, 999999);
        lifetimeKills = readIntPreference("lifetime_kills", 0, 0, 99999999);
        lifetimeMineLayers = readIntPreference("lifetime_mine_layers", mineDepth, 0, 999999);
        battleChestProgress = readIntPreference("battle_chest_progress", 0, 0, 3);
        battleChestsOpened = readIntPreference("battle_chests_opened", 0, 0, 999999);
        dailyDayKey = readIntPreference("daily_day_key", 0, 0, 9999999);
        dailyWins = readIntPreference("daily_wins", 0, 0, 9999);
        dailyMineLayers = readIntPreference("daily_mine_layers", 0, 0, 9999);
        dailyKills = readIntPreference("daily_kills", 0, 0, 999999);
        dailyWinClaimed = readIntPreference("daily_win_claimed", 0, 0, 1) == 1;
        dailyMineClaimed = readIntPreference("daily_mine_claimed", 0, 0, 1) == 1;
        dailyKillClaimed = readIntPreference("daily_kill_claimed", 0, 0, 1) == 1;
        dailyChestClaimed = readIntPreference("daily_chest_claimed", 0, 0, 1) == 1;
        for (int index = 0; index < achievementClaimed.length; index++) {
            achievementClaimed[index] = readIntPreference("achievement_" + index, 0, 0, 1) == 1;
        }
        heroLevel = readIntPreference("hero_level", 1, 1, 15);
        heroXp = readIntPreference("hero_xp", 0, 0, 999999);
        heroPowerLevel = readIntPreference("hero_power", 0, 0, 5);
        heroArmorLevel = readIntPreference("hero_armor", 0, 0, 5);
        heroLeadershipLevel = readIntPreference("hero_leadership", 0, 0, 5);
        arenaBestWave = readIntPreference("arena_best_wave", 0, 0, 99999);
        arenaBestKills = readIntPreference("arena_best_kills", 0, 0, 9999999);
        arenaRuns = readIntPreference("arena_runs", 0, 0, 999999);
        normalizeHeroProgressLocked(false);
        ensureDailyMissionsLocked();
        prepareMineLayerLocked();

        paint.setDither(false);
        paint.setFilterBitmap(false);
        stroke.setDither(false);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        resetGameLocked();
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        surfaceReady = true;
        resumeGame();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
        synchronized (stateLock) {
            width = Math.max(1, w);
            height = Math.max(1, h);
            updateResponsiveMetricsLocked();
            invalidateSceneCachesLocked();
            layoutButtonsLocked();
        }
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        surfaceReady = false;
        pauseGame();
    }

    public void resumeGame() {
        if (!surfaceReady || running) return;
        running = true;
        lastFrame = SystemClock.uptimeMillis();
        gameThread = new Thread(this, "UygarWarsGameLoop");
        gameThread.start();
    }

    public void pauseGame() {
        running = false;
        Thread thread = gameThread;
        if (thread != null && thread != Thread.currentThread()) {
            try {
                thread.join(800L);
            } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
            }
        }
        gameThread = null;
        synchronized (stateLock) {
            pauseMusicLocked();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        pauseGame();
        synchronized (stateLock) {
            releaseAudioLocked();
        }
        super.onDetachedFromWindow();
    }

    @Override
    public void run() {
        while (running && surfaceReady) {
            long frameStart = SystemClock.uptimeMillis();
            long frameBudget = PLAY_FRAME_MS;
            try {
                long now = frameStart;
                float dt = Math.min(0.05f, Math.max(0f, (now - lastFrame) / 1000f));
                lastFrame = now;

                synchronized (stateLock) {
                    float scaledDt = dt * gameSpeed;
                    if (screen == Screen.PLAYING) updateGameLocked(scaledDt);
                    else if (screen == Screen.MINE) updateMineLocked(dt);
                    if (toastTimer > 0f) toastTimer = Math.max(0f, toastTimer - dt);
                    if (resetConfirmTimer > 0f) {
                        resetConfirmTimer = Math.max(0f, resetConfirmTimer - dt);
                        if (resetConfirmTimer <= 0f) fullResetArmed = false;
                    }
                    updateMusicForScreenLocked();
                    frameBudget = (screen == Screen.PLAYING || screen == Screen.MINE)
                            ? PLAY_FRAME_MS : IDLE_FRAME_MS;
                }
                drawFrame();
            } catch (Throwable error) {
                fatalError = error;
                drawFrame();
                running = false;
            }

            long used = SystemClock.uptimeMillis() - frameStart;
            long sleep = frameBudget - used;
            if (sleep > 0L) SystemClock.sleep(sleep);
        }
    }

    private void drawFrame() {
        if (!surfaceReady) return;
        Canvas canvas = null;
        try {
            canvas = surfaceHolder.lockCanvas();
            if (canvas == null) return;
            synchronized (stateLock) {
                if (fatalError != null) drawFatalError(canvas, fatalError);
                else drawGameLocked(canvas);
            }
        } catch (Throwable drawError) {
            fatalError = drawError;
        } finally {
            if (canvas != null) {
                try {
                    surfaceHolder.unlockCanvasAndPost(canvas);
                } catch (Throwable ignored) {
                    // Surface kapanırken oluşabilecek yarış koşulu.
                }
            }
        }
    }

    private void resetGameLocked() {
        playerUnits.clear();
        enemyUnits.clear();
        projectiles.clear();
        impacts.clear();
        floatingTexts.clear();
        particles.clear();
        deathEffects.clear();
        playerBaseHp = playerStatueMaxHp();
        enemyBaseHp = enemyStatueMaxHp();
        gold = 185f + Math.min(130f, (battleLevel - 1) * 14f);
        enemyGold = 185f + (battleLevel - 1) * 22f;
        enemySpawnClock = 0f;
        passiveGoldClock = 0f;
        elapsed = 0f;
        wave = 1;
        completedLevel = 0;
        earnedUpgradePoints = 0;
        earnedStarsThisBattle = 0;
        replayRewardDiamonds = 0;
        earnedChapterDiamonds = 0;
        earnedChapterPoints = 0;
        firstClearBattle = false;
        bossSpawned = false;
        bossDefeated = false;
        bossBannerTimer = 0f;
        chapterBannerTimer = 0f;
        bossShieldToastCooldown = 0f;
        developerPanel = false;
        godMode = false;
        damageMultiplier = 1f;
        gameSpeed = 1f;
        commandMode = CommandMode.ATTACK;
        formationMode = FormationMode.LINE;
        cameraX = 0f;
        touchDownX = 0f;
        touchDownY = 0f;
        touchStartCameraX = 0f;
        manualCameraHoldTimer = 0f;
        cameraDragEligible = false;
        cameraDragging = false;
        toastText = "";
        toastTimer = 0f;
        playerBaseFlash = 0f;
        enemyBaseFlash = 0f;
        ambientClock = 0f;
        baseParticleClock = 0f;
        waveBannerTimer = 0f;
        commanderBannerTimer = 0f;
        warCryTimer = 0f;
        warCryCooldown = 0f;
        statueShieldTimer = 0f;
        statueShieldCooldown = 0f;
        arrowRainTimer = 0f;
        arrowRainCooldown = 0f;
        arrowRainCenterX = 0f;
        hitStopTimer = 0f;
        combatPulseTimer = 0f;
        combatPulseColor = Color.TRANSPARENT;
        resultPulseTimer = 0f;
        resultVictory = false;
        swordSfxCooldown = 0f;
        arrowSfxCooldown = 0f;
        pickaxeSfxCooldown = 0f;
        baseSfxCooldown = 0f;
        injurySfxCooldown = 0f;
        footstepSfxCooldown = 0f;
        spearSfxCooldown = 0f;
        lastCommanderWave = 0;
        screenShake = 0f;
        tacticalPanel = false;
        unitMenuOpen = false;
        selectedUnitType = UnitType.SWORD;
        playerBarricadeHp = 0f;
        playerBarricadeMaxHp = barricadeMaxHpLocked();
        playerTowerHp = 0f;
        playerTowerMaxHp = towerMaxHpLocked();
        playerTowerCooldown = 0f;
        heroSpawned = false;
        arenaKillsThisRun = 0;
        arenaLastRewardWave = 0;
        arenaRunDiamondReward = 0;
        arenaRunXpReward = 0;
        arenaChampionsThisRun = 0;
        arenaNewWaveRecord = false;
        arenaNewKillRecord = false;
        arenaChampionEntryTimer = 0f;
        arenaChampionEntryX = 0f;

        float levelReserve = Math.min(260f, (battleLevel - 1) * 18f);
        playerMineMaxGold[0] = 620f + levelReserve;
        playerMineMaxGold[1] = 820f + levelReserve;
        playerMineMaxGold[2] = 1080f + levelReserve;
        for (int i = 0; i < PLAYER_MINE_COUNT; i++) playerMineGold[i] = playerMineMaxGold[i];
    }

    private void updateGameLocked(float dt) {
        elapsed += dt;
        ambientClock += dt;
        baseParticleClock += dt;
        enemySpawnClock += dt;
        passiveGoldClock += dt;
        waveBannerTimer = Math.max(0f, waveBannerTimer - dt);
        commanderBannerTimer = Math.max(0f, commanderBannerTimer - dt);
        bossBannerTimer = Math.max(0f, bossBannerTimer - dt);
        chapterBannerTimer = Math.max(0f, chapterBannerTimer - dt);
        bossShieldToastCooldown = Math.max(0f, bossShieldToastCooldown - dt);
        arenaChampionEntryTimer = Math.max(0f, arenaChampionEntryTimer - dt);
        warCryTimer = Math.max(0f, warCryTimer - dt);
        warCryCooldown = Math.max(0f, warCryCooldown - dt);
        statueShieldTimer = Math.max(0f, statueShieldTimer - dt);
        statueShieldCooldown = Math.max(0f, statueShieldCooldown - dt);
        arrowRainTimer = Math.max(0f, arrowRainTimer - dt);
        arrowRainCooldown = Math.max(0f, arrowRainCooldown - dt);
        hitStopTimer = Math.max(0f, hitStopTimer - dt);
        combatPulseTimer = Math.max(0f, combatPulseTimer - dt);
        resultPulseTimer = Math.max(0f, resultPulseTimer - dt);
        swordSfxCooldown = Math.max(0f, swordSfxCooldown - dt);
        arrowSfxCooldown = Math.max(0f, arrowSfxCooldown - dt);
        pickaxeSfxCooldown = Math.max(0f, pickaxeSfxCooldown - dt);
        baseSfxCooldown = Math.max(0f, baseSfxCooldown - dt);
        injurySfxCooldown = Math.max(0f, injurySfxCooldown - dt);
        footstepSfxCooldown = Math.max(0f, footstepSfxCooldown - dt);
        spearSfxCooldown = Math.max(0f, spearSfxCooldown - dt);
        manualCameraHoldTimer = Math.max(0f, manualCameraHoldTimer - dt / Math.max(1f, gameSpeed));
        screenShake = Math.max(0f, screenShake - dt * 28f);

        if (hitStopTimer > 0f) {
            updateEffectsLocked(dt * 0.35f);
            updateParticlesLocked(dt * 0.35f);
            updateDeathEffectsLocked(dt * 0.35f);
            playerBaseFlash = Math.max(0f, playerBaseFlash - dt * 0.2f);
            enemyBaseFlash = Math.max(0f, enemyBaseFlash - dt * 0.2f);
            return;
        }

        while (passiveGoldClock >= 1f) {
            passiveGoldClock -= 1f;
            // Heykel küçük bir temel gelir sağlar; asıl ekonomi madencilerin taşıdığı altındır.
            gold += 2f + (statueUpgradeLevel - 1) * 0.35f;
            enemyGold += (5f + Math.min(7, wave) * 1.5f) * enemyEconomyMultiplier();
        }

        float waveDuration = arenaMode
                ? Math.max(14f, 24f - Math.min(8, wave) * 0.55f)
                : Math.max(23f, 36f - battleLevel * 0.65f);
        int newWave = 1 + (int) (elapsed / waveDuration);
        if (newWave > wave) {
            wave = newWave;
            waveBannerTimer = 2.4f;
            if (arenaMode) {
                arenaBestWave = Math.max(arenaBestWave, wave);
                if (wave % 3 == 0 && arenaLastRewardWave != wave) {
                    arenaLastRewardWave = wave;
                    diamonds += 1;
                    arenaRunDiamondReward += 1;
                    profileXp += 12;
                    saveProgressLocked();
                    invalidateMenuCacheLocked();
                    showToastLocked("ARENA DALGA " + wave + " • +1 ELMAS");
                } else {
                    showToastLocked("ARENA DALGA " + wave + " BAŞLADI");
                }
                if (wave % 5 == 0) {
                    spawnArenaChampionLocked();
                } else if (wave >= 3 && wave % 3 == 0 && lastCommanderWave != wave) {
                    spawnEnemyCommanderLocked();
                    lastCommanderWave = wave;
                }
            } else {
                showToastLocked("DALGA " + wave + " BAŞLADI");
                if (!isBossBattleLocked() && wave >= 2 && (wave - 2) % 3 == 0 && lastCommanderWave != wave) {
                    spawnEnemyCommanderLocked();
                    lastCommanderWave = wave;
                }
            }
        }

        if (isBossBattleLocked() && !bossSpawned && elapsed >= 4.2f) spawnEnemyBossLocked();

        float enemyInterval = arenaMode
                ? Math.max(0.82f, 3.75f - wave * 0.16f)
                : Math.max(1.15f, 5.15f - wave * 0.25f - (battleLevel - 1) * 0.18f);
        if (enemySpawnClock >= enemyInterval) {
            enemySpawnClock = 0f;
            spawnEnemyAutoLocked();
        }

        updateUnitsLocked(playerUnits, enemyUnits, dt, true);
        updateUnitsLocked(enemyUnits, playerUnits, dt, false);
        resolveUnitSpacingLocked(playerUnits, true);
        resolveUnitSpacingLocked(enemyUnits, false);
        updateDefenseStructuresLocked(dt);
        updateProjectilesLocked(dt);
        updateEffectsLocked(dt);
        updateParticlesLocked(dt);
        updateDeathEffectsLocked(dt);
        cleanDeadUnitsLocked(playerUnits, true);
        cleanDeadUnitsLocked(enemyUnits, false);
        updateBaseAtmosphereLocked();
        updateCameraLocked(dt);
        playerBaseFlash = Math.max(0f, playerBaseFlash - dt);
        enemyBaseFlash = Math.max(0f, enemyBaseFlash - dt);

        if (enemyBaseHp <= 0f) {
            enemyBaseHp = 0f;
            completedLevel = battleLevel;
            earnedStarsThisBattle = calculateBattleStarsLocked();
            int previousStars = levelStars[completedLevel];
            if (earnedStarsThisBattle > previousStars) {
                levelStars[completedLevel] = earnedStarsThisBattle;
                campaignRecordsDirty = true;
            }
            firstClearBattle = completedLevel == campaignLevel && previousStars == 0;
            replayRewardDiamonds = 0;
            if (firstClearBattle) {
                earnedUpgradePoints = 2 + Math.min(4, completedLevel / 3);
                wins++;
                upgradePoints += earnedUpgradePoints;
                claimChapterRewardIfNeededLocked(completedLevel);
                campaignLevel = Math.min(50, campaignLevel + 1);
                mapSelectedLevel = campaignLevel;
                mapPage = Math.max(0, Math.min(4, (campaignLevel - 1) / 10));
            } else {
                earnedUpgradePoints = 0;
                replayRewardDiamonds = Math.max(0, earnedStarsThisBattle - previousStars);
                diamonds += replayRewardDiamonds;
            }
            ensureDailyMissionsLocked();
            dailyWins++;
            lifetimeWins++;
            battleChestProgress = Math.min(3, battleChestProgress + 1);
            profileXp += 24 + earnedStarsThisBattle * 6 + (isBossBattleLocked() ? 18 : 0);
            addHeroXpLocked(24 + earnedStarsThisBattle * 7 + (isBossBattleLocked() ? 22 : 0));
            saveProgressLocked();
            invalidateMenuCacheLocked();
            resultVictory = true;
            resultPulseTimer = 1.6f;
            triggerCombatFeelLocked(Color.rgb(255, 206, 98), 0.22f, 7.8f, 0.03f, true);
            playSoundLocked(sndVictory, 0.95f, 1f);
            screen = Screen.WIN;
        } else if (playerBaseHp <= 0f) {
            playerBaseHp = 0f;
            if (arenaMode) finishArenaRunLocked();
            else saveProgressLocked();
            resultVictory = false;
        swordSfxCooldown = 0f;
        arrowSfxCooldown = 0f;
        pickaxeSfxCooldown = 0f;
        baseSfxCooldown = 0f;
        injurySfxCooldown = 0f;
        footstepSfxCooldown = 0f;
        spearSfxCooldown = 0f;
            resultPulseTimer = 1.8f;
            triggerCombatFeelLocked(Color.rgb(255, 110, 88), 0.24f, 8.2f, 0.036f, true);
            screen = Screen.LOSE;
        }
    }

    private void prepareMineLayerLocked() {
        mineLayerMaxHp = 145f + mineDepth * 34f + Math.min(1600f, mineDepth * mineDepth * 1.45f);
        float completedRatio = Math.max(0f, Math.min(0.999f, mineProgressPermille / 1000f));
        mineLayerHp = Math.max(1f, mineLayerMaxHp * (1f - completedRatio));
        mineClock = 0f;
        mineSaveClock = 0f;
    }

    private int diamondMinerCountLocked() {
        return 1 + Math.min(2, (minerUpgradeLevel - 1) / 2);
    }

    private float diamondMiningPowerLocked() {
        return diamondMinerCountLocked() * (6.4f + minerUpgradeLevel * 2.0f)
                * (1f + diamondMinerBoost * 0.12f);
    }

    private void updateMineLocked(float dt) {
        ambientClock += dt;
        mineClock += dt;
        mineSaveClock += dt;
        pickaxeSfxCooldown = Math.max(0f, pickaxeSfxCooldown - dt);
        mineLayerHp -= diamondMiningPowerLocked() * dt;
        updateMineProgressLocked();
        if (mineLayerHp <= 0f) completeMineLayerLocked();
        if (mineSaveClock >= 2.5f) {
            mineSaveClock = 0f;
            saveProgressLocked();
        }
    }

    private void manualMineHitLocked() {
        playPickaxeSoundLocked(0.88f);
        float strike = (22f + minerUpgradeLevel * 8f + diamondMinerCountLocked() * 5f)
                * (1f + diamondMinerBoost * 0.12f);
        mineLayerHp -= strike;
        updateMineProgressLocked();
        if (mineLayerHp <= 0f) completeMineLayerLocked();
        else showToastLocked("KAZI GÜCÜ +" + Math.round(strike));
    }

    private void updateMineProgressLocked() {
        float ratio = 1f - Math.max(0f, mineLayerHp) / Math.max(1f, mineLayerMaxHp);
        mineProgressPermille = Math.max(0, Math.min(999, Math.round(ratio * 1000f)));
    }

    private void completeMineLayerLocked() {
        int finishedLayer = mineDepth + 1;
        int reward = 0;
        if (finishedLayer % 10 == 0) reward = 3;
        else if (finishedLayer % 5 == 0) reward = 2;
        else if (finishedLayer % 3 == 0 || random.nextInt(100) < 24) reward = 1;
        if (mineDepth >= 20 && random.nextInt(100) < 12) reward++;

        ensureDailyMissionsLocked();
        diamonds += reward;
        lastMineReward = reward;
        mineDepth++;
        dailyMineLayers++;
        lifetimeMineLayers++;
        profileXp += 5 + reward * 3;
        mineProgressPermille = 0;
        prepareMineLayerLocked();
        saveProgressLocked();
        invalidateMenuCacheLocked();
        showToastLocked(reward > 0
                ? "KATMAN AÇILDI • +" + reward + " ELMAS"
                : "KATMAN AÇILDI • DAHA DERİNE İNİLDİ");
    }

    private int mineStoneColorLocked(int layerOffset) {
        int band = Math.max(0, mineDepth + layerOffset);
        if (band < 5) return Color.rgb(92, 76, 61);
        if (band < 12) return Color.rgb(68, 70, 78);
        if (band < 24) return Color.rgb(54, 58, 70);
        return Color.rgb(38, 43, 58);
    }

    private int countPlayerMinersLocked() {
        return countUnitsOfTypeLocked(playerUnits, UnitType.MINER);
    }

    private int countUnitsOfTypeLocked(List<Unit> units, UnitType type) {
        int count = 0;
        for (Unit unit : units) {
            if (unit.hp > 0f && unit.type == type && !unit.hero) count++;
        }
        return count;
    }

    private int playerMinerLimitLocked() {
        return statueUpgradeLevel >= 4 ? 5 : 4;
    }

    private int playerSwordLimitLocked() {
        return 10 + Math.max(0, statueUpgradeLevel - 1);
    }

    private int playerArcherLimitLocked() {
        return 6 + (statueUpgradeLevel >= 3 ? 2 : 0) + (statueUpgradeLevel >= 5 ? 1 : 0);
    }

    private int playerSpearLimitLocked() {
        return 6 + Math.max(0, statueUpgradeLevel - 2);
    }

    private int playerCombatLimitLocked() {
        return 16 + Math.max(0, statueUpgradeLevel - 1) * 2 + diamondStatueBoost;
    }

    private int enemyCombatLimitLocked() {
        if (arenaMode) return Math.min(42, 16 + campaignLevel + wave * 2);
        return Math.min(32, 13 + battleLevel * 2 + wave);
    }

    private void spawnEnemyCommanderLocked() {
        for (Unit unit : enemyUnits) {
            if (unit.hp > 0f && unit.commander) return;
        }
        Unit commander = createEnemyUnitLocked(UnitType.SWORD,
                enemyBaseX() - 175f * uiScale, enemyUnits.size());
        commander.commander = true;
        commander.visualScale = 1.38f;
        commander.maxHp *= 3.15f + Math.min(1.25f, battleLevel * 0.06f);
        commander.damage *= 1.72f;
        commander.speed *= 0.84f;
        commander.range *= 1.18f;
        commander.attackDelay *= 1.08f;
        commander.hp = commander.maxHp;
        enemyUnits.add(commander);
        commanderBannerTimer = 2.8f;
        screenShake = Math.max(screenShake, 5.5f);
        showToastLocked("DÜŞMAN KOMUTANI SAVAŞA GİRDİ");
    }

    private boolean isBossBattleLocked() {
        return !arenaMode && battleLevel > 0 && battleLevel % 5 == 0;
    }

    private void spawnEnemyBossLocked() {
        if (bossSpawned) return;
        for (Unit unit : enemyUnits) {
            if (unit.hp > 0f && unit.boss) return;
        }
        Unit boss = createEnemyUnitLocked(UnitType.SWORD,
                enemyBaseX() - 205f * uiScale, enemyUnits.size());
        boss.commander = true;
        boss.boss = true;
        boss.visualScale = 1.72f;
        boss.maxHp *= 6.2f + Math.min(2.4f, battleLevel * 0.08f);
        boss.damage *= 2.15f + Math.min(0.6f, battleLevel * 0.025f);
        boss.speed *= 0.70f;
        boss.range *= 1.34f;
        boss.attackDelay *= 1.12f;
        boss.hp = boss.maxHp;
        enemyUnits.add(boss);
        bossSpawned = true;
        bossBannerTimer = 3.4f;
        screenShake = Math.max(screenShake, 10f);
        playSoundLocked(sndBossEntry, 0.95f, 0.94f);
        showToastLocked("BÖLÜM BOSSU SAVAŞA GİRDİ");
    }

    private void spawnArenaChampionLocked() {
        for (Unit unit : enemyUnits) {
            if (unit.hp > 0f && unit.boss) return;
        }
        Unit champion = createEnemyUnitLocked(UnitType.SWORD,
                enemyBaseX() - 205f * uiScale, enemyUnits.size());
        champion.commander = true;
        champion.boss = true;
        champion.visualScale = 1.58f + Math.min(0.32f, wave * 0.012f);
        champion.maxHp *= 4.2f + wave * 0.16f;
        champion.damage *= 1.78f + wave * 0.025f;
        champion.speed *= 0.76f;
        champion.range *= 1.28f;
        champion.attackDelay *= 1.08f;
        champion.hp = champion.maxHp;
        enemyUnits.add(champion);
        arenaChampionEntryTimer = 2.35f;
        arenaChampionEntryX = champion.x;
        bossSpawned = true;
        bossDefeated = false;
        bossBannerTimer = 3.2f;
        screenShake = Math.max(screenShake, 9f);
        playSoundLocked(sndBossEntry, 0.95f, 0.86f);
        showToastLocked("ARENA ŞAMPİYONU GELİYOR");
    }

    private void startArenaLocked() {
        ensureDailyMissionsLocked();
        arenaMode = true;
        updateResponsiveMetricsLocked();
        battleLevel = Math.max(1, campaignLevel);
        resetGameLocked();
        arenaMode = true;
        updateResponsiveMetricsLocked();
        arenaRunStartDiamonds = diamonds;
        arenaRunDiamondReward = 0;
        arenaRunXpReward = 0;
        arenaChampionsThisRun = 0;
        arenaNewWaveRecord = false;
        arenaNewKillRecord = false;
        gold = 310f + statueUpgradeLevel * 16f;
        enemyGold = 280f;
        enemyBaseHp = 9999999f;
        arenaRuns++;
        arenaBestWave = Math.max(arenaBestWave, 1);
        spawnPlayerHeroLocked();
        screen = Screen.PLAYING;
        chapterBannerTimer = 3.2f;
        waveBannerTimer = 2.2f;
        invalidateSceneCachesLocked();
        saveProgressLocked();
        invalidateMenuCacheLocked();
        showToastLocked("SONSUZ ARENA BAŞLADI");
    }

    private void finishArenaRunLocked() {
        int previousBestWave = arenaBestWave;
        int previousBestKills = arenaBestKills;
        arenaNewWaveRecord = wave > previousBestWave;
        arenaNewKillRecord = arenaKillsThisRun > previousBestKills;
        arenaBestWave = Math.max(arenaBestWave, wave);
        arenaBestKills = Math.max(arenaBestKills, arenaKillsThisRun);
        int bonusDiamonds = wave >= 10 ? Math.min(5, wave / 10) : 0;
        if (bonusDiamonds > 0) {
            diamonds += bonusDiamonds;
            arenaRunDiamondReward += bonusDiamonds;
        }
        arenaRunXpReward = Math.max(4, wave * 3 + arenaKillsThisRun / 4);
        profileXp += arenaRunXpReward;
        addHeroXpLocked(Math.max(2, wave * 2 + arenaKillsThisRun / 6));
        // Güvenlik: dalga ödülleri başka bir sistemden değişse bile gerçek toplamı göster.
        arenaRunDiamondReward = Math.max(arenaRunDiamondReward, diamonds - arenaRunStartDiamonds);
        saveProgressLocked();
        invalidateMenuCacheLocked();
        showToastLocked(arenaNewWaveRecord || arenaNewKillRecord
                ? "YENİ ARENA REKORU"
                : bonusDiamonds > 0
                ? "ARENA BİTTİ • +" + bonusDiamonds + " ELMAS"
                : "ARENA BİTTİ • SONUÇLAR HAZIR");
    }

    private int calculateBattleStarsLocked() {
        int stars = 1;
        float healthRatio = playerBaseHp / Math.max(1f, playerStatueMaxHp());
        if (healthRatio >= 0.55f) stars++;
        float speedTarget = Math.max(78f, 118f - battleLevel * 1.7f);
        if (elapsed <= speedTarget) stars++;
        return Math.max(1, Math.min(3, stars));
    }

    private void startBattleLocked(int level) {
        ensureDailyMissionsLocked();
        arenaMode = false;
        battleLevel = Math.max(1, Math.min(campaignLevel, level));
        mapSelectedLevel = battleLevel;
        resetGameLocked();
        spawnPlayerHeroLocked();
        screen = Screen.PLAYING;
        chapterBannerTimer = 3.2f;
        waveBannerTimer = 1.9f;
        invalidateSceneCachesLocked();
        showToastLocked(isBossBattleLocked() ? "BOSS BÖLÜMÜ BAŞLADI" : "SAVAŞ BAŞLADI");
    }

    private boolean heroUnlockedLocked() {
        return campaignLevel >= 4;
    }

    private int heroXpNeededLocked() {
        return 80 + Math.max(0, heroLevel - 1) * 55;
    }

    private void normalizeHeroProgressLocked(boolean announce) {
        while (heroLevel < 15 && heroXp >= heroXpNeededLocked()) {
            heroXp -= heroXpNeededLocked();
            heroLevel++;
            upgradePoints++;
            if (announce) showToastLocked("KOMUTAN SEVİYE " + heroLevel + " OLDU");
        }
        if (heroLevel >= 15) heroXp = Math.min(heroXp, heroXpNeededLocked());
    }

    private void addHeroXpLocked(int amount) {
        if (!heroUnlockedLocked() || amount <= 0) return;
        heroXp += amount;
        normalizeHeroProgressLocked(true);
        invalidateMenuCacheLocked();
    }

    private int heroTraitCostLocked(int currentLevel) {
        return 4 + currentLevel * 4;
    }

    private void tryUpgradeHeroTraitLocked(String trait) {
        if (!heroUnlockedLocked()) {
            showToastLocked("KOMUTAN BÖLÜM 4'TE AÇILIR");
            return;
        }
        int current = "power".equals(trait) ? heroPowerLevel
                : "armor".equals(trait) ? heroArmorLevel : heroLeadershipLevel;
        if (current >= 5) {
            showToastLocked("KOMUTAN YETENEĞİ AZAMİ SEVİYE");
            return;
        }
        int cost = heroTraitCostLocked(current);
        if (diamonds < cost) {
            showToastLocked("BU YETENEK İÇİN " + cost + " ELMAS GEREKİR");
            return;
        }
        diamonds -= cost;
        if ("power".equals(trait)) heroPowerLevel++;
        else if ("armor".equals(trait)) heroArmorLevel++;
        else heroLeadershipLevel++;
        saveProgressLocked();
        invalidateMenuCacheLocked();
        showToastLocked("KOMUTAN YETENEĞİ GELİŞTİRİLDİ");
    }

    private void spawnPlayerHeroLocked() {
        if (!heroUnlockedLocked() || heroSpawned) return;
        Unit hero = createPlayerUnitLocked(UnitType.SWORD,
                playerBaseX() + 188f * uiScale, playerUnits.size());
        hero.hero = true;
        hero.visualScale = 1.46f;
        hero.maxHp = (390f + heroLevel * 46f) * (1f + heroArmorLevel * 0.12f);
        hero.damage = (58f + heroLevel * 6.2f) * (1f + heroPowerLevel * 0.10f);
        hero.speed = 58f * (1f + heroLeadershipLevel * 0.015f);
        hero.range = 62f * uiScale;
        hero.attackDelay = Math.max(0.48f, 0.70f - heroLevel * 0.008f);
        hero.hp = hero.maxHp;
        hero.lane = 0;
        playerUnits.add(hero);
        heroSpawned = true;
        applyFormationLanesLocked();
    }

    private Unit livingPlayerHeroLocked() {
        for (Unit unit : playerUnits) {
            if (unit.hero && unit.hp > 0f) return unit;
        }
        return null;
    }

    private float heroAuraDamageMultiplierLocked(Unit unit, boolean playerSide) {
        if (!playerSide || heroLeadershipLevel <= 0 || unit.hero || unit.type == UnitType.MINER) return 1f;
        Unit hero = livingPlayerHeroLocked();
        if (hero == null) return 1f;
        float auraRange = (245f + heroLeadershipLevel * 22f) * uiScale;
        return Math.abs(unit.x - hero.x) <= auraRange ? 1f + heroLeadershipLevel * 0.035f : 1f;
    }

    private boolean warCryUnlockedLocked() {
        return campaignLevel >= 1;
    }

    private boolean statueShieldUnlockedLocked() {
        return campaignLevel >= 2;
    }

    private boolean arrowRainUnlockedLocked() {
        return campaignLevel >= 3;
    }

    private void activateWarCryLocked() {
        if (!warCryUnlockedLocked()) {
            showToastLocked("SAVAŞ NARASI BÖLÜM 1'DE AÇILIR");
            return;
        }
        if (warCryCooldown > 0f) {
            showToastLocked("SAVAŞ NARASI " + Math.max(1, Math.round(warCryCooldown)) + " SN");
            return;
        }
        warCryTimer = 8f;
        warCryCooldown = 30f;
        triggerCombatFeelLocked(Color.rgb(255, 189, 74), 0.14f, 4.4f, 0.018f, true);
        playSoundLocked(sndWarCry, 0.88f, 1f);
        for (Unit unit : playerUnits) {
            if (unit.hp > 0f && unit.type != UnitType.MINER) {
                spawnHitParticlesLocked(unit.x, groundY + laneOffset(unit.lane) - 42f,
                        GOLD_LIGHT, 5, 0.42f);
            }
        }
        showToastLocked("SAVAŞ NARASI • HASAR VE HIZ ARTTI");
    }

    private void activateStatueShieldLocked() {
        if (!statueShieldUnlockedLocked()) {
            showToastLocked("HEYKEL KALKANI BÖLÜM 2'DE AÇILIR");
            return;
        }
        if (statueShieldCooldown > 0f) {
            showToastLocked("HEYKEL KALKANI " + Math.max(1, Math.round(statueShieldCooldown)) + " SN");
            return;
        }
        statueShieldTimer = 9f;
        statueShieldCooldown = 38f;
        playSoundLocked(sndShield, 0.82f, 1f);
        triggerCombatFeelLocked(Color.rgb(105, 231, 255), 0.14f, 3.8f, 0.015f, false);
        spawnHitParticlesLocked(playerBaseX(), groundY - 115f * uiScale,
                Color.rgb(105, 231, 255), 18, 0.72f);
        showToastLocked("HEYKEL KALKANI • HASAR %65 AZALDI");
    }

    private void activateArrowRainLocked() {
        if (!arrowRainUnlockedLocked()) {
            showToastLocked("OK YAĞMURU BÖLÜM 3'TE AÇILIR");
            return;
        }
        if (arrowRainCooldown > 0f) {
            showToastLocked("OK YAĞMURU " + Math.max(1, Math.round(arrowRainCooldown)) + " SN");
            return;
        }
        float total = 0f;
        int count = 0;
        for (Unit unit : enemyUnits) {
            if (unit.hp > 0f && unit.type != UnitType.MINER) {
                total += unit.x;
                count++;
            }
        }
        arrowRainCenterX = count > 0 ? total / count : enemyBaseX() - 220f * uiScale;
        float radius = 360f * uiScale;
        float damage = 72f + battleLevel * 4.5f + archerUpgradeLevel * 5f;
        for (Unit unit : enemyUnits) {
            if (unit.hp <= 0f || unit.type == UnitType.MINER) continue;
            float distance = Math.abs(unit.x - arrowRainCenterX);
            if (distance <= radius) {
                float falloff = 1f - distance / radius * 0.35f;
                damageUnitLocked(unit, damage * falloff, true, DamageType.PIERCE, false);
            }
        }
        if (Math.abs(enemyBaseX() - arrowRainCenterX) <= radius * 0.72f) {
            damageBaseLocked(true, damage * 0.42f);
        }
        arrowRainTimer = 1.35f;
        arrowRainCooldown = 26f;
        triggerCombatFeelLocked(Color.rgb(163, 126, 255), 0.18f, 5.0f, 0.022f, true);
        playSoundLocked(sndArrowRain, 0.86f, 1f);
        screenShake = Math.max(screenShake, 5.2f);
        showToastLocked("OK YAĞMURU BAŞLADI");
    }

    private boolean barricadeUnlockedLocked() {
        return campaignLevel >= 2;
    }

    private boolean towerUnlockedLocked() {
        return campaignLevel >= 4;
    }

    private float barricadeMaxHpLocked() {
        return 620f + statueUpgradeLevel * 105f + diamondStatueBoost * 65f;
    }

    private float towerMaxHpLocked() {
        return 470f + archerUpgradeLevel * 85f + diamondArcherBoost * 55f;
    }

    private float playerBarricadeXLocked() {
        return playerBaseX() + Math.min(width * 0.34f, 510f * uiScale);
    }

    private float playerTowerXLocked() {
        return playerBaseX() + Math.min(width * 0.20f, 305f * uiScale);
    }

    private void buildOrRepairBarricadeLocked() {
        if (arenaMode) {
            showToastLocked("ARENA MODUNDA BARİKAT KULLANILMAZ");
            return;
        }
        if (!barricadeUnlockedLocked()) {
            showToastLocked("BARİKAT BÖLÜM 2'DE AÇILIR");
            return;
        }
        playerBarricadeMaxHp = barricadeMaxHpLocked();
        boolean repairing = playerBarricadeHp > 0f;
        float cost = repairing ? 120f : 220f;
        if (repairing && playerBarricadeHp >= playerBarricadeMaxHp * 0.96f) {
            showToastLocked("BARİKAT ZATEN SAĞLAM");
            return;
        }
        if (gold < cost) {
            showToastLocked("BARİKAT İÇİN " + Math.round(cost) + " ALTIN GEREKİR");
            return;
        }
        gold -= cost;
        if (repairing) {
            playerBarricadeHp = Math.min(playerBarricadeMaxHp,
                    playerBarricadeHp + playerBarricadeMaxHp * 0.40f);
            showToastLocked("BARİKAT ONARILDI");
        } else {
            playerBarricadeHp = playerBarricadeMaxHp;
            showToastLocked("BARİKAT KURULDU");
        }
        spawnHitParticlesLocked(playerBarricadeXLocked(), groundY - 42f * uiScale,
                Color.rgb(181, 132, 74), 16, 0.75f);
    }

    private void buildOrRepairTowerLocked() {
        if (arenaMode) {
            showToastLocked("ARENA MODUNDA KULE KULLANILMAZ");
            return;
        }
        if (!towerUnlockedLocked()) {
            showToastLocked("OKÇU KULESİ BÖLÜM 4'TE AÇILIR");
            return;
        }
        playerTowerMaxHp = towerMaxHpLocked();
        boolean repairing = playerTowerHp > 0f;
        float cost = repairing ? 180f : 340f;
        if (repairing && playerTowerHp >= playerTowerMaxHp * 0.96f) {
            showToastLocked("KULE ZATEN SAĞLAM");
            return;
        }
        if (gold < cost) {
            showToastLocked("KULE İÇİN " + Math.round(cost) + " ALTIN GEREKİR");
            return;
        }
        gold -= cost;
        if (repairing) {
            playerTowerHp = Math.min(playerTowerMaxHp, playerTowerHp + playerTowerMaxHp * 0.36f);
            showToastLocked("OKÇU KULESİ ONARILDI");
        } else {
            playerTowerHp = playerTowerMaxHp;
            playerTowerCooldown = 0.25f;
            showToastLocked("OKÇU KULESİ KURULDU");
        }
        spawnHitParticlesLocked(playerTowerXLocked(), groundY - 90f * uiScale,
                GOLD_LIGHT, 18, 0.82f);
    }

    private void cycleFormationLocked() {
        if (formationMode == FormationMode.LINE) formationMode = FormationMode.SHIELD_WALL;
        else if (formationMode == FormationMode.SHIELD_WALL) formationMode = FormationMode.RANGED;
        else formationMode = FormationMode.LINE;
        applyFormationLanesLocked();
        showToastLocked("DİZİLİM: " + formationLabelLocked());
    }

    private void applyFormationLanesLocked() {
        int swordIndex = 0;
        int archerIndex = 0;
        for (Unit unit : playerUnits) {
            if (unit.hp <= 0f || unit.type == UnitType.MINER) continue;
            if (unit.hero) {
                unit.lane = 0;
                continue;
            }
            if (formationMode == FormationMode.LINE) {
                unit.lane = (unit.formationSlot % 3) - 1;
            } else if (formationMode == FormationMode.SHIELD_WALL) {
                unit.lane = (unit.type == UnitType.SWORD || unit.type == UnitType.SPEAR) ? 0 : ((archerIndex++ % 2) == 0 ? -1 : 1);
            } else {
                unit.lane = unit.type == UnitType.ARCHER ? 0 : ((swordIndex++ % 2) == 0 ? -1 : 1);
            }
        }
    }

    private String formationLabelLocked() {
        if (formationMode == FormationMode.SHIELD_WALL) return "KALKAN DUVARI";
        if (formationMode == FormationMode.RANGED) return "MENZİLLİ HAT";
        return "DÜZ HAT";
    }

    private float effectiveRangeLocked(Unit unit, boolean playerSide) {
        float range = unit.range;
        if (playerSide && formationMode == FormationMode.RANGED && unit.type == UnitType.ARCHER) {
            range *= 1.30f;
        }
        if (playerSide && formationMode == FormationMode.RANGED && unit.type == UnitType.SPEAR) {
            range *= 1.10f;
        }
        if (unit.type == UnitType.ARCHER) range *= chapterArcherRangeMultiplierLocked();
        return range;
    }

    private float formationDamageMultiplierLocked(Unit unit, boolean playerSide) {
        if (!playerSide) return 1f;
        if (formationMode == FormationMode.RANGED && unit.type == UnitType.ARCHER) return 1.16f;
        if (formationMode == FormationMode.RANGED && unit.type == UnitType.SPEAR) return 1.08f;
        if (formationMode == FormationMode.SHIELD_WALL && (unit.type == UnitType.SWORD || unit.type == UnitType.SPEAR)) return 0.94f;
        return 1f;
    }

    private boolean handleEnemyStructureTargetLocked(Unit unit, float dt) {
        if (arenaMode) return false;
        boolean targetBarricade = playerBarricadeHp > 0f;
        boolean targetTower = !targetBarricade && playerTowerHp > 0f;
        if (!targetBarricade && !targetTower) return false;

        float targetX = targetBarricade ? playerBarricadeXLocked() : playerTowerXLocked();
        float effectiveRange = Math.max(unit.range, unit.siege ? 72f * uiScale : unit.range);
        float distance = Math.abs(unit.x - targetX);
        if (distance <= effectiveRange + 18f * uiScale) {
            unit.moving = false;
            if (unit.attackCooldown <= 0f) {
                unit.attackCooldown = unit.attackDelay;
                unit.attackAnim = unit.type == UnitType.ARCHER ? 0.44f
                        : unit.type == UnitType.SWORD ? 0.38f : 0.34f;
                float structureDamage = unit.damage * (unit.siege ? 2.55f : 1f);
                damageDefenseStructureLocked(targetBarricade, structureDamage, unit.siege);
            }
        } else {
            moveUnitTowardLocked(unit, targetX, dt, false);
        }
        return true;
    }

    private void damageDefenseStructureLocked(boolean barricade, float damage, boolean siege) {
        float x = barricade ? playerBarricadeXLocked() : playerTowerXLocked();
        float y = groundY - (barricade ? 46f : 105f) * uiScale;
        if (barricade) {
            playerBarricadeHp = Math.max(0f, playerBarricadeHp - damage);
        } else {
            playerTowerHp = Math.max(0f, playerTowerHp - damage);
        }
        addImpactLocked(x, y, siege ? Color.rgb(255, 92, 67) : Color.rgb(255, 145, 96));
        spawnHitParticlesLocked(x, y, Color.rgb(184, 128, 73), siege ? 18 : 9, siege ? 1.2f : 0.72f);
        addFloatingTextLocked(x, y - 10f, "-" + Math.max(1, Math.round(damage)),
                Color.rgb(255, 150, 112));
        screenShake = Math.max(screenShake, siege ? 7.5f : 3.5f);
        if (barricade && playerBarricadeHp <= 0f) showToastLocked("BARİKAT YIKILDI");
        if (!barricade && playerTowerHp <= 0f) showToastLocked("OKÇU KULESİ YIKILDI");
    }

    private void updateDefenseStructuresLocked(float dt) {
        if (arenaMode) return;
        playerTowerCooldown = Math.max(0f, playerTowerCooldown - dt);
        if (playerTowerHp <= 0f || playerTowerCooldown > 0f) return;
        Unit target = null;
        float best = Float.MAX_VALUE;
        float towerX = playerTowerXLocked();
        float range = (510f + archerUpgradeLevel * 22f + diamondArcherBoost * 18f) * uiScale;
        for (Unit unit : enemyUnits) {
            if (unit.hp <= 0f || unit.type == UnitType.MINER) continue;
            float distance = Math.abs(unit.x - towerX);
            if (distance <= range && distance < best) {
                best = distance;
                target = unit;
            }
        }
        if (target == null) return;
        Projectile projectile = new Projectile();
        projectile.kind = PROJECTILE_ARROW;
        projectile.playerSide = true;
        projectile.target = target;
        projectile.targetsBase = false;
        projectile.damage = (31f + archerUpgradeLevel * 5.5f) * (1f + diamondArcherBoost * 0.08f)
                * chapterTowerDamageMultiplierLocked();
        projectile.damageType = DamageType.PIERCE;
        projectile.critical = random.nextFloat() < (0.07f + archerUpgradeLevel * 0.008f);
        projectile.x = towerX + 12f * uiScale;
        projectile.y = groundY - 145f * uiScale;
        projectile.speed = 520f * uiScale;
        prepareProjectileArcLocked(projectile);
        projectiles.add(projectile);
        playerTowerCooldown = Math.max(0.70f, 1.34f - archerUpgradeLevel * 0.07f);
        spawnBowReleaseLocked(projectile.x, projectile.y, true);
    }

    private void spawnEnemyAutoLocked() {
        if (countCombatUnitsLocked(enemyUnits) >= enemyCombatLimitLocked()) return;

        int roll = random.nextInt(100);
        boolean siegeSpawn = battleLevel >= 4 && wave >= 3 && roll >= Math.max(82, 94 - battleLevel);
        UnitType type;
        if (siegeSpawn) type = UnitType.SWORD;
        else if (battleLevel >= 5 && wave >= 2 && roll >= 86) type = UnitType.SPEAR;
        else if ((wave >= 3 || battleLevel >= 3) && roll > Math.max(52, 76 - battleLevel * 3)) type = UnitType.ARCHER;
        else type = UnitType.SWORD;

        float cost = siegeSpawn ? 230f : type == UnitType.ARCHER ? 150f : type == UnitType.SPEAR ? 175f : 100f;
        if (enemyGold >= cost) {
            enemyGold -= cost;
            Unit unit = createEnemyUnitLocked(type, enemyBaseX() - 148f * uiScale, enemyUnits.size());
            if (siegeSpawn) {
                unit.siege = true;
                unit.visualScale = 1.30f;
                unit.maxHp *= 2.65f;
                unit.damage *= 1.58f;
                unit.speed *= 0.56f;
                unit.range = 62f * uiScale;
                unit.attackDelay = 1.12f;
                unit.hp = unit.maxHp;
                showToastLocked("DÜŞMAN KUŞATMA BİRLİĞİ GELİYOR");
            }
            enemyUnits.add(unit);
        }
    }

    private void updateUnitsLocked(List<Unit> own, List<Unit> opponents, float dt, boolean playerSide) {
        for (Unit unit : own) {
            if (unit.hp <= 0f) continue;
            unit.attackCooldown = Math.max(0f, unit.attackCooldown - dt);
            unit.attackAnim = Math.max(0f, unit.attackAnim - dt);
            unit.hitFlash = Math.max(0f, unit.hitFlash - dt);
            unit.hitRecoil = Math.max(0f, unit.hitRecoil - dt);
            float walkRate = unit.type == UnitType.SWORD ? 11.6f
                    : unit.type == UnitType.SPEAR ? 10.1f
                    : unit.type == UnitType.ARCHER ? 9.2f : 10.4f;
            unit.anim += dt * (unit.moving ? walkRate : 3.4f);
            unit.dustClock += dt;

            if (unit.type == UnitType.MINER) {
                if (playerSide) updateMinerLocked(unit, dt);
                else unit.moving = false;
                continue;
            }

            if (!playerSide && handleEnemyStructureTargetLocked(unit, dt)) continue;

            Unit target;
            float targetX;
            boolean mayStrikeStatue = true;

            if (playerSide && commandMode == CommandMode.DEFEND) {
                target = nearestDefenseThreatLocked(unit, opponents);
                mayStrikeStatue = false;
                if (target == null) {
                    targetX = playerGuardXLocked(unit);
                    moveUnitTowardLocked(unit, targetX, dt, playerSide);
                    continue;
                }
                targetX = target.x;
            } else {
                target = nearestTargetLocked(unit, opponents, playerSide);
                if (target != null) {
                    targetX = target.x;
                } else if (arenaMode && playerSide) {
                    // v0.2.7.2: Arena'da oyuncu birlikleri sağ uca yığılmak yerine orta hatta toplanır.
                    targetX = arenaPlayerHoldXLocked();
                    mayStrikeStatue = false;
                } else {
                    targetX = playerSide ? enemyStatueTargetX() : playerStatueTargetX();
                }
            }

            float distance = Math.abs(targetX - unit.x);
            float effectiveRange = effectiveRangeLocked(unit, playerSide);
            if (distance <= effectiveRange) {
                unit.moving = false;
                if (unit.attackCooldown <= 0f) {
                    unit.attackCooldown = unit.attackDelay;
                    unit.attackAnim = unit.type == UnitType.ARCHER ? 0.44f
                            : unit.type == UnitType.SPEAR ? 0.52f
                            : unit.type == UnitType.SWORD ? 0.38f : 0.34f;
                    float battleBuff = playerSide && warCryTimer > 0f ? 1.28f : 1f;
                    float formationDamage = formationDamageMultiplierLocked(unit, playerSide);
                    float leadershipBuff = heroAuraDamageMultiplierLocked(unit, playerSide);
                    float dealt = unit.damage * (playerSide ? damageMultiplier : 1f)
                            * battleBuff * formationDamage * leadershipBuff;
                    if (unit.type == UnitType.ARCHER) {
                        unit.rangedAttack = true;
                        if (target != null || mayStrikeStatue) {
                            playArrowSoundLocked();
                            spawnArrowLocked(unit, target, playerSide, dealt);
                        }
                    } else if (unit.type == UnitType.SPEAR) {
                        boolean throwSpear = distance > spearMeleeRangeLocked(unit);
                        unit.rangedAttack = throwSpear;
                        if (throwSpear && (target != null || mayStrikeStatue)) {
                            playSpearThrowSoundLocked();
                            spawnSpearLocked(unit, target, playerSide, dealt * 2f);
                        } else if (target != null) {
                            playSpearHitSoundLocked();
                            damageUnitLocked(target, dealt, playerSide, DamageType.PIERCE,
                                    rollCriticalLocked(unit, playerSide));
                        } else if (mayStrikeStatue) {
                            playSpearHitSoundLocked();
                            damageBaseLocked(playerSide, dealt);
                        }
                    } else if (target != null) {
                        unit.rangedAttack = false;
                        playSwordSoundLocked(unit.hero || unit.boss ? 1.12f : 0.82f);
                        damageUnitLocked(target, dealt, playerSide, DamageType.CUT,
                                rollCriticalLocked(unit, playerSide));
                    } else if (mayStrikeStatue) {
                        unit.rangedAttack = false;
                        playSwordSoundLocked(0.86f);
                        damageBaseLocked(playerSide, dealt);
                    }
                }
            } else {
                moveUnitTowardLocked(unit, targetX, dt, playerSide);
            }
        }
    }

    private float spearMeleeRangeLocked(Unit unit) {
        return Math.max(62f * uiScale, unit.visualScale * 68f * uiScale);
    }

    private void moveUnitTowardLocked(Unit unit, float targetX, float dt, boolean playerSide) {
        float dx = targetX - unit.x;
        if (Math.abs(dx) <= 7f * uiScale) {
            unit.moving = false;
            return;
        }
        unit.moving = true;
        float direction = dx > 0f ? 1f : -1f;
        float speedBuff = playerSide && warCryTimer > 0f ? 1.22f : 1f;
        if (playerSide && !unit.hero && unit.type != UnitType.MINER && heroLeadershipLevel > 0) {
            Unit hero = livingPlayerHeroLocked();
            if (hero != null && Math.abs(unit.x - hero.x) <= (245f + heroLeadershipLevel * 22f) * uiScale) {
                speedBuff *= 1f + heroLeadershipLevel * 0.018f;
            }
        }
        if (playerSide && formationMode == FormationMode.SHIELD_WALL && (unit.type == UnitType.SWORD || unit.type == UnitType.SPEAR)) {
            speedBuff *= 0.86f;
        } else if (playerSide && formationMode == FormationMode.LINE) {
            speedBuff *= 1.05f;
        }
        speedBuff *= chapterMovementMultiplierLocked(playerSide);
        unit.x += direction * unit.speed * speedBuff * dt;
        unit.x = Math.max(combatLeftBound(), Math.min(combatRightBound(), unit.x));
        if (unit.dustClock >= 0.19f) {
            unit.dustClock = 0f;
            spawnDustLocked(unit.x - direction * 9f,
                    groundY + laneOffset(unit.lane) - 2f, playerSide);
            playFootstepSoundLocked(unit.visualScale, playerSide);
        }
    }

    private Unit nearestDefenseThreatLocked(Unit defender, List<Unit> opponents) {
        Unit best = null;
        float bestDistance = Float.MAX_VALUE;
        float threatBoundary = playerDefenseBoundaryLocked() + defender.range + 150f * uiScale;
        for (Unit candidate : opponents) {
            if (candidate.hp <= 0f || candidate.type == UnitType.MINER) continue;
            if (candidate.x > threatBoundary) continue;
            float distance = Math.abs(candidate.x - defender.x);
            if (distance < bestDistance) {
                bestDistance = distance;
                best = candidate;
            }
        }
        return best;
    }

    private float playerGuardXLocked(Unit unit) {
        float row = unit.lane + 1f;
        float slot = unit.formationSlot % 5;
        return playerBaseX() + (205f + slot * 42f + row * 12f) * uiScale;
    }

    private float playerDefenseBoundaryLocked() {
        return playerBaseX() + Math.min(width * 0.34f, 520f * uiScale);
    }

    private void updateMinerLocked(Unit unit, float dt) {
        if (unit.assignedMine < 0 || unit.assignedMine >= PLAYER_MINE_COUNT
                || playerMineGold[unit.assignedMine] <= 0.1f) {
            unit.assignedMine = findAvailableMineLocked(unit.formationSlot);
            if (unit.assignedMine < 0) unit.minerState = MINER_IDLE;
        }

        if (unit.minerState == MINER_IDLE) {
            unit.moving = false;
            if (unit.assignedMine >= 0) unit.minerState = MINER_TO_MINE;
            return;
        }

        float baseDepositX = playerBaseX() + 105f * uiScale;
        if (unit.minerState == MINER_TO_MINE) {
            float destination = playerMineXLocked(unit.assignedMine) - 22f * uiScale
                    + (unit.formationSlot % 2) * 25f * uiScale;
            if (Math.abs(destination - unit.x) <= 9f * uiScale) {
                unit.x = destination;
                unit.moving = false;
                unit.minerState = MINER_MINING;
                unit.workTimer = 0f;
            } else {
                moveUnitTowardLocked(unit, destination, dt, true);
            }
            return;
        }

        if (unit.minerState == MINER_MINING) {
            unit.moving = false;
            unit.workTimer += dt;
            if (unit.dustClock >= 0.32f) {
                unit.dustClock = 0f;
                float sparkX = playerMineXLocked(unit.assignedMine) - 4f * uiScale;
                float sparkY = groundY - 28f * uiScale;
                spawnHitParticlesLocked(sparkX, sparkY, GOLD_LIGHT, 3, 0.28f);
                playPickaxeSoundLocked(0.28f);
            }
            float miningTime = Math.max(1.25f, 2.35f - (minerUpgradeLevel - 1) * 0.18f);
            if (unit.workTimer >= miningTime) {
                unit.workTimer = 0f;
                float amount = Math.min(playerMineGold[unit.assignedMine], minerCarryAmountLocked());
                playerMineGold[unit.assignedMine] -= amount;
                unit.carriedGold = amount;
                unit.minerState = MINER_TO_BASE;
                if (amount <= 0f) unit.assignedMine = findAvailableMineLocked(unit.formationSlot + 1);
            }
            return;
        }

        if (unit.minerState == MINER_TO_BASE) {
            if (Math.abs(baseDepositX - unit.x) <= 9f * uiScale) {
                unit.x = baseDepositX;
                unit.moving = false;
                int deposited = Math.max(0, Math.round(unit.carriedGold));
                gold += unit.carriedGold;
                unit.carriedGold = 0f;
                if (deposited > 0) {
                    addFloatingTextLocked(baseDepositX, groundY - 105f * uiScale,
                            "+" + deposited + " ALTIN", GOLD_LIGHT);
                    showToastLocked("MADENCİ " + deposited + " ALTIN GETİRDİ");
                }
                unit.assignedMine = findAvailableMineLocked(unit.formationSlot);
                unit.minerState = unit.assignedMine >= 0 ? MINER_TO_MINE : MINER_IDLE;
            } else {
                moveUnitTowardLocked(unit, baseDepositX, dt, true);
            }
        }
    }

    private int findAvailableMineLocked(int preferred) {
        for (int offset = 0; offset < PLAYER_MINE_COUNT; offset++) {
            int index = Math.floorMod(preferred + offset, PLAYER_MINE_COUNT);
            if (playerMineGold[index] > 0.1f) return index;
        }
        return -1;
    }

    private float minerCarryAmountLocked() {
        return (34f + (minerUpgradeLevel - 1) * 9f) * (1f + diamondMinerBoost * 0.12f)
                * chapterMinerCarryMultiplierLocked();
    }

    private float playerMineXLocked(int index) {
        return playerBaseX() + (255f + index * 125f) * uiScale;
    }

    private void spawnArrowLocked(Unit attacker, Unit target, boolean playerSide, float damage) {
        Projectile projectile = new Projectile();
        projectile.kind = PROJECTILE_ARROW;
        projectile.playerSide = playerSide;
        projectile.target = target;
        projectile.targetsBase = target == null;
        projectile.damage = damage;
        projectile.damageType = DamageType.PIERCE;
        projectile.critical = rollCriticalLocked(attacker, playerSide);
        projectile.x = attacker.x + (playerSide ? 25f : -25f) * uiScale;
        projectile.y = groundY + laneOffset(attacker.lane) - 53f * uiScale;
        projectile.speed = 520f * uiScale;
        prepareProjectileArcLocked(projectile);
        projectiles.add(projectile);
        spawnBowReleaseLocked(projectile.x, projectile.y, playerSide);
    }

    private void spawnSpearLocked(Unit attacker, Unit target, boolean playerSide, float damage) {
        Projectile projectile = new Projectile();
        projectile.kind = PROJECTILE_SPEAR;
        projectile.playerSide = playerSide;
        projectile.target = target;
        projectile.targetsBase = target == null;
        projectile.damage = damage;
        projectile.damageType = DamageType.PIERCE;
        projectile.critical = rollCriticalLocked(attacker, playerSide);
        projectile.x = attacker.x + (playerSide ? 31f : -31f) * uiScale;
        projectile.y = groundY + laneOffset(attacker.lane) - 47f * uiScale;
        projectile.speed = 465f * uiScale;
        prepareProjectileArcLocked(projectile);
        projectiles.add(projectile);
        spawnBowReleaseLocked(projectile.x, projectile.y, playerSide);
    }

    private void prepareProjectileArcLocked(Projectile projectile) {
        float targetX;
        float targetY;
        if (!projectile.targetsBase && projectile.target != null && projectile.target.hp > 0f) {
            targetX = projectile.target.x;
            targetY = groundY + laneOffset(projectile.target.lane) - 48f * uiScale;
        } else {
            targetX = projectile.playerSide ? enemyStatueTargetX() : playerStatueTargetX();
            targetY = groundY - 76f * uiScale;
        }
        projectile.startX = projectile.x;
        projectile.startY = projectile.y;
        projectile.lastTargetX = targetX;
        projectile.lastTargetY = targetY;
        projectile.previousX = projectile.x;
        projectile.previousY = projectile.y;
        float dx = targetX - projectile.x;
        float dy = targetY - projectile.y;
        float distance = (float) Math.sqrt(dx * dx + dy * dy);
        projectile.travelDuration = Math.max(0.30f, Math.min(1.45f, distance / Math.max(1f, projectile.speed)));
        projectile.travelElapsed = 0f;
        float minArc = projectile.kind == PROJECTILE_SPEAR ? 56f : 72f;
        float maxArc = projectile.kind == PROJECTILE_SPEAR ? 138f : 178f;
        projectile.arcHeight = Math.max(minArc * uiScale,
                Math.min(maxArc * uiScale, distance * (projectile.kind == PROJECTILE_SPEAR ? 0.16f : 0.24f)));
        projectile.life = projectile.travelDuration + 0.55f;
    }

    private void damageUnitLocked(Unit target, float damage, boolean fromPlayer) {
        damageUnitLocked(target, damage, fromPlayer, DamageType.IMPACT, false);
    }

    private void damageUnitLocked(Unit target, float damage, boolean fromPlayer,
                                  DamageType damageType, boolean critical) {
        if (target.hp <= 0f) return;
        if (target.commander) damage *= 0.74f;

        float typeModifier = damageTypeModifierLocked(target, damageType);
        float armorReduction = armorReductionLocked(target, damageType);
        float finalDamage = damage * typeModifier * (1f - armorReduction);
        if (critical) finalDamage *= 1.72f;
        finalDamage = Math.max(1f, finalDamage);

        target.hp -= finalDamage;
        target.hitFlash = critical ? 0.34f : 0.24f;
        playInjurySoundLocked(finalDamage, target.hp <= 0f);
        target.hitRecoil = Math.max(target.hitRecoil,
                critical ? 0.25f : finalDamage >= 36f ? 0.18f : 0.11f);
        float y = groundY + laneOffset(target.lane) - 40f * uiScale;
        int hitColor = critical ? Color.rgb(255, 218, 104)
                : fromPlayer ? GOLD_LIGHT : RED;
        addImpactLocked(target.x, y, hitColor);

        if (critical) {
            addFloatingTextLocked(target.x, y - 34f * uiScale, "KRİTİK", Color.rgb(255, 222, 112));
            spawnHitParticlesLocked(target.x, y, Color.rgb(255, 213, 91), 16, 1.10f);
            triggerCombatFeelLocked(Color.rgb(255, 211, 92), 0.18f, 6.6f, 0.035f, true);
        } else if (finalDamage >= 26f) {
            int pulseColor = fromPlayer ? Color.rgb(255, 189, 74) : Color.rgb(255, 118, 97);
            triggerCombatFeelLocked(pulseColor, finalDamage >= 48f ? 0.14f : 0.08f,
                    finalDamage >= 48f ? 4.9f : 2.9f,
                    finalDamage >= 48f ? 0.026f : 0.012f,
                    finalDamage >= 40f || target.hp <= 0f);
        }
        screenShake = Math.max(screenShake, critical ? 6.2f
                : finalDamage >= 32f ? 3.8f : 2.3f);
        addFloatingTextLocked(target.x, y - 8f,
                "-" + Math.max(1, Math.round(finalDamage)),
                critical ? Color.rgb(255, 232, 132)
                        : fromPlayer ? GOLD_LIGHT : Color.rgb(255, 125, 105));
    }

    private boolean rollCriticalLocked(Unit attacker, boolean playerSide) {
        if (attacker == null) return false;
        float chance = attacker.criticalChance;
        if (attacker.type == UnitType.ARCHER) chance += 0.025f;
        else if (attacker.type == UnitType.SPEAR) chance += 0.018f;
        if (attacker.commander) chance += 0.035f;
        if (attacker.hero) chance += 0.055f;
        if (attacker.boss) chance += 0.045f;
        if (playerSide && warCryTimer > 0f) chance += 0.08f;
        if (!playerSide) chance = Math.max(0.025f, chance - 0.015f);
        return random.nextFloat() < Math.min(0.42f, chance);
    }

    private float armorReductionLocked(Unit target, DamageType damageType) {
        float effectiveArmor = Math.max(0f, target.armor);
        if (damageType == DamageType.CUT && target.type == UnitType.SWORD) {
            effectiveArmor *= 1.24f;
        } else if (damageType == DamageType.PIERCE && target.type == UnitType.SPEAR) {
            effectiveArmor *= 1.30f;
        } else if (damageType == DamageType.PIERCE && target.type == UnitType.SWORD) {
            effectiveArmor *= 0.68f;
        } else if (damageType == DamageType.IMPACT) {
            effectiveArmor *= 0.48f;
        }
        return Math.min(0.56f, effectiveArmor / (effectiveArmor + 118f));
    }

    private float damageTypeModifierLocked(Unit target, DamageType damageType) {
        if (damageType == DamageType.CUT && target.type == UnitType.ARCHER) return 1.14f;
        if (damageType == DamageType.PIERCE && target.type == UnitType.SWORD) return 1.12f;
        if (damageType == DamageType.PIERCE && target.type == UnitType.SPEAR) return 0.88f;
        if (damageType == DamageType.IMPACT && target.armor >= 24f) return 1.16f;
        return 1f;
    }

    private void damageBaseLocked(boolean playerAttacking, float damage) {
        if (playerAttacking) {
            if (arenaMode) {
                enemyBaseHp = 9999999f;
                enemyBaseFlash = 0.08f;
                addImpactLocked(enemyBaseX(), groundY - 78f * uiScale, Color.rgb(163, 126, 255));
                return;
            }
            if (isBossBattleLocked() && !bossDefeated) {
                enemyBaseHp = Math.max(1f, enemyBaseHp);
                enemyBaseFlash = 0.10f;
                if (bossShieldToastCooldown <= 0f) {
                    bossShieldToastCooldown = 1.6f;
                    showToastLocked("BOSS KALKANI • ÖNCE BOSSU YEN");
                }
                addImpactLocked(enemyBaseX(), groundY - 78f * uiScale, Color.rgb(255, 92, 78));
                return;
            }
            enemyBaseHp -= damage;
            enemyBaseFlash = 0.22f;
            addImpactLocked(enemyBaseX(), groundY - 78f * uiScale, GOLD_LIGHT);
            spawnBaseDebrisLocked(enemyBaseX(), groundY - 80f * uiScale, GOLD_LIGHT, 13);
            playBaseHitSoundLocked();
            screenShake = Math.max(screenShake, 8f);
            addFloatingTextLocked(enemyBaseX(), groundY - 150f * uiScale,
                    "-" + Math.max(1, Math.round(damage)), GOLD_LIGHT);
        } else if (!godMode) {
            float shieldMultiplier = statueShieldTimer > 0f ? 0.35f : 1f;
            damage *= shieldMultiplier;
            playerBaseHp -= damage;
            playerBaseFlash = 0.22f;
            addImpactLocked(playerBaseX(), groundY - 78f * uiScale, Color.rgb(255, 120, 100));
            spawnBaseDebrisLocked(playerBaseX(), groundY - 80f * uiScale, Color.rgb(255, 108, 87), 13);
            playBaseHitSoundLocked();
            screenShake = Math.max(screenShake, 8f);
            addFloatingTextLocked(playerBaseX(), groundY - 150f * uiScale,
                    "-" + Math.max(1, Math.round(damage)), Color.rgb(255, 125, 105));
        }
    }

    private void updateProjectilesLocked(float dt) {
        Iterator<Projectile> iterator = projectiles.iterator();
        while (iterator.hasNext()) {
            Projectile projectile = iterator.next();
            projectile.life -= dt;
            float targetX;
            float targetY;
            if (!projectile.targetsBase && projectile.target != null && projectile.target.hp > 0f) {
                targetX = projectile.target.x;
                targetY = groundY + laneOffset(projectile.target.lane) - 48f * uiScale;
                projectile.lastTargetX = targetX;
                projectile.lastTargetY = targetY;
            } else if (projectile.targetsBase) {
                targetX = projectile.playerSide ? enemyStatueTargetX() : playerStatueTargetX();
                targetY = groundY - 76f * uiScale;
                projectile.lastTargetX = targetX;
                projectile.lastTargetY = targetY;
            } else {
                targetX = projectile.lastTargetX;
                targetY = projectile.lastTargetY;
            }

            if (projectile.travelDuration <= 0f) prepareProjectileArcLocked(projectile);
            projectile.travelElapsed += dt;
            float t = Math.max(0f, Math.min(1f,
                    projectile.travelElapsed / Math.max(0.01f, projectile.travelDuration)));
            projectile.previousX = projectile.x;
            projectile.previousY = projectile.y;
            projectile.x = projectile.startX + (targetX - projectile.startX) * t;
            float linearY = projectile.startY + (targetY - projectile.startY) * t;
            projectile.y = linearY - 4f * projectile.arcHeight * t * (1f - t);
            float vx = projectile.x - projectile.previousX;
            float vy = projectile.y - projectile.previousY;
            float vectorLength = (float) Math.sqrt(vx * vx + vy * vy);
            if (vectorLength > 0.001f) {
                projectile.angleX = vx / vectorLength;
                projectile.angleY = vy / vectorLength;
            }

            if (t >= 1f || projectile.life <= 0f) {
                if (projectile.kind == PROJECTILE_SPEAR) {
                    playSpearHitSoundLocked();
                    spawnHitParticlesLocked(projectile.x, projectile.y,
                            projectile.playerSide ? GOLD_LIGHT : Color.rgb(255, 126, 98), 8, 0.60f);
                }
                if (!projectile.targetsBase && projectile.target != null && projectile.target.hp > 0f) {
                    damageUnitLocked(projectile.target, projectile.damage, projectile.playerSide,
                            projectile.damageType == null ? DamageType.PIERCE : projectile.damageType,
                            projectile.critical);
                } else if (projectile.targetsBase) {
                    damageBaseLocked(projectile.playerSide, projectile.damage);
                }
                iterator.remove();
            }
        }
    }

    private void updateEffectsLocked(float dt) {
        Iterator<Impact> impactIterator = impacts.iterator();
        while (impactIterator.hasNext()) {
            Impact impact = impactIterator.next();
            impact.life -= dt;
            if (impact.life <= 0f) impactIterator.remove();
        }
        Iterator<FloatingText> textIterator = floatingTexts.iterator();
        while (textIterator.hasNext()) {
            FloatingText text = textIterator.next();
            text.life -= dt;
            text.y -= 26f * dt;
            if (text.life <= 0f) textIterator.remove();
        }
    }

    private void updateParticlesLocked(float dt) {
        Iterator<Particle> iterator = particles.iterator();
        while (iterator.hasNext()) {
            Particle particle = iterator.next();
            particle.life -= dt;
            particle.vy += particle.gravity * dt;
            particle.x += particle.vx * dt;
            particle.y += particle.vy * dt;
            particle.rotation += particle.spin * dt;
            if (particle.life <= 0f) iterator.remove();
        }
        while (particles.size() > 150) particles.remove(0);
    }

    private void updateDeathEffectsLocked(float dt) {
        Iterator<DeathEffect> iterator = deathEffects.iterator();
        while (iterator.hasNext()) {
            DeathEffect effect = iterator.next();
            effect.life -= dt;
            effect.vy += 260f * uiScale * dt;
            effect.x += effect.vx * dt;
            effect.y += effect.vy * dt;
            effect.rotation += effect.rotationSpeed * dt;
            if (effect.y >= effect.groundY) {
                effect.y = effect.groundY;
                if (!effect.bounced && Math.abs(effect.vy) > 22f * uiScale) {
                    effect.vy *= -0.24f;
                    effect.vx *= 0.48f;
                    effect.rotationSpeed *= 0.42f;
                    effect.bounced = true;
                } else {
                    effect.vy = 0f;
                    effect.vx *= 0.90f;
                    effect.rotationSpeed *= 0.88f;
                }
            }
            if (effect.life <= 0f) iterator.remove();
        }
        while (deathEffects.size() > 24) deathEffects.remove(0);
    }

    private void updateBaseAtmosphereLocked() {
        if (baseParticleClock < 0.18f) return;
        baseParticleClock = 0f;
        float playerRatio = playerBaseHp / playerStatueMaxHp();
        float enemyRatio = enemyBaseHp / enemyStatueMaxHp();
        if (playerRatio < 0.68f) {
            spawnSmokeLocked(playerBaseX() + random.nextFloat() * 52f * uiScale - 26f * uiScale,
                    groundY - 126f - random.nextFloat() * 44f,
                    playerRatio < 0.32f ? 1.25f : 0.85f);
        }
        if (enemyRatio < 0.68f) {
            spawnSmokeLocked(enemyBaseX() + random.nextFloat() * 52f * uiScale - 26f * uiScale,
                    groundY - 126f - random.nextFloat() * 44f,
                    enemyRatio < 0.32f ? 1.25f : 0.85f);
        }
    }

    private void spawnDustLocked(float x, float y, boolean playerSide) {
        if (particles.size() > 135) return;
        Particle particle = new Particle();
        particle.x = x;
        particle.y = y;
        particle.vx = (playerSide ? -1f : 1f) * (12f + random.nextFloat() * 18f);
        particle.vy = -8f - random.nextFloat() * 12f;
        particle.gravity = -1f;
        particle.size = 5f + random.nextFloat() * 7f;
        particle.life = 0.48f + random.nextFloat() * 0.25f;
        particle.maxLife = particle.life;
        particle.color = Color.rgb(121, 105, 84);
        particle.kind = Particle.KIND_DUST;
        particles.add(particle);
    }

    private void spawnBowReleaseLocked(float x, float y, boolean playerSide) {
        int color = playerSide ? Color.rgb(115, 187, 255) : Color.rgb(255, 112, 98);
        for (int i = 0; i < 4; i++) {
            Particle particle = new Particle();
            particle.x = x;
            particle.y = y;
            particle.vx = (playerSide ? -1f : 1f) * (12f + random.nextFloat() * 20f);
            particle.vy = -20f + random.nextFloat() * 40f;
            particle.gravity = 8f;
            particle.size = 2f + random.nextFloat() * 2f;
            particle.life = 0.22f + random.nextFloat() * 0.18f;
            particle.maxLife = particle.life;
            particle.color = color;
            particle.kind = Particle.KIND_SPARK;
            particles.add(particle);
        }
    }

    private void spawnHitParticlesLocked(float x, float y, int color, int count, float force) {
        for (int i = 0; i < count; i++) {
            double angle = random.nextDouble() * Math.PI * 2.0;
            float speed = (42f + random.nextFloat() * 85f) * force;
            Particle particle = new Particle();
            particle.x = x;
            particle.y = y;
            particle.vx = (float) Math.cos(angle) * speed;
            particle.vy = (float) Math.sin(angle) * speed - 35f;
            particle.gravity = 145f;
            particle.size = 2f + random.nextFloat() * 3.4f;
            particle.life = 0.32f + random.nextFloat() * 0.32f;
            particle.maxLife = particle.life;
            particle.color = color;
            particle.spin = -160f + random.nextFloat() * 320f;
            particle.kind = Particle.KIND_SPARK;
            particles.add(particle);
        }
    }

    private void spawnBaseDebrisLocked(float x, float y, int accent, int count) {
        spawnHitParticlesLocked(x, y, accent, Math.max(4, count / 3), 1.1f);
        for (int i = 0; i < count; i++) {
            Particle particle = new Particle();
            particle.x = x + random.nextFloat() * 36f - 18f;
            particle.y = y + random.nextFloat() * 28f - 14f;
            particle.vx = random.nextFloat() * 170f - 85f;
            particle.vy = -65f - random.nextFloat() * 125f;
            particle.gravity = 245f;
            particle.size = 4f + random.nextFloat() * 7f;
            particle.life = 0.65f + random.nextFloat() * 0.55f;
            particle.maxLife = particle.life;
            particle.color = Color.rgb(98 + random.nextInt(34), 91 + random.nextInt(26), 82 + random.nextInt(22));
            particle.rotation = random.nextFloat() * 360f;
            particle.spin = -250f + random.nextFloat() * 500f;
            particle.kind = Particle.KIND_DEBRIS;
            particles.add(particle);
        }
    }

    private void spawnSmokeLocked(float x, float y, float scale) {
        if (particles.size() > 140) return;
        Particle particle = new Particle();
        particle.x = x;
        particle.y = y;
        particle.vx = -7f + random.nextFloat() * 14f;
        particle.vy = -18f - random.nextFloat() * 16f;
        particle.gravity = -2f;
        particle.size = (10f + random.nextFloat() * 14f) * scale;
        particle.life = 1.25f + random.nextFloat() * 0.75f;
        particle.maxLife = particle.life;
        particle.color = Color.rgb(55, 59, 65);
        particle.kind = Particle.KIND_SMOKE;
        particles.add(particle);
    }

    private void addImpactLocked(float x, float y, int color) {
        Impact impact = new Impact();
        impact.x = x;
        impact.y = y;
        impact.color = color;
        impact.life = 0.28f;
        impact.maxLife = impact.life;
        impacts.add(impact);
    }

    private void addFloatingTextLocked(float x, float y, String value, int color) {
        FloatingText text = new FloatingText();
        text.x = x;
        text.y = y;
        text.value = value;
        text.color = color;
        text.life = 0.85f;
        text.maxLife = text.life;
        floatingTexts.add(text);
    }

    private void resolveUnitSpacingLocked(List<Unit> units, boolean playerSide) {
        final float minSpacing = (tabletLayout ? 76f : 64f) * uiScale;
        for (int pass = 0; pass < 2; pass++) {
            for (int i = 0; i < units.size(); i++) {
                Unit a = units.get(i);
                if (a.hp <= 0f || a.type == UnitType.MINER) continue;
                for (int j = i + 1; j < units.size(); j++) {
                    Unit b = units.get(j);
                    if (b.hp <= 0f || b.type == UnitType.MINER || a.lane != b.lane) continue;
                    float dx = b.x - a.x;
                    float distance = Math.abs(dx);
                    float requiredSpacing = minSpacing * ((a.commander || b.commander) ? 1.34f : 1f);
                    if (distance >= requiredSpacing) continue;
                    float push = (requiredSpacing - distance) * 0.52f;
                    if (dx >= 0f) {
                        a.x -= push;
                        b.x += push;
                    } else {
                        a.x += push;
                        b.x -= push;
                    }
                }
                a.x = Math.max(combatLeftBound(), Math.min(combatRightBound(), a.x));
            }
        }
    }

    private float laneOffset(int lane) {
        return lane * Math.max(11f * uiScale, height * (tabletLayout ? 0.018f : 0.016f));
    }

    private Unit nearestTargetLocked(Unit attacker, List<Unit> opponents, boolean playerSide) {
        Unit best = null;
        float bestDistance = Float.MAX_VALUE;
        for (Unit candidate : opponents) {
            if (candidate.hp <= 0f || candidate.type == UnitType.MINER) continue;
            float directional = playerSide ? candidate.x - attacker.x : attacker.x - candidate.x;
            if (directional < -25f) continue;
            float distance = Math.abs(candidate.x - attacker.x);
            if (distance < bestDistance) {
                bestDistance = distance;
                best = candidate;
            }
        }
        return best;
    }

    private void cleanDeadUnitsLocked(List<Unit> units, boolean playerSide) {
        Iterator<Unit> iterator = units.iterator();
        while (iterator.hasNext()) {
            Unit unit = iterator.next();
            if (unit.hp <= 0f) {
                if (!playerSide && unit.type != UnitType.MINER) {
                    ensureDailyMissionsLocked();
                    dailyKills++;
                    lifetimeKills++;
                    if (arenaMode) arenaKillsThisRun++;
                    profileXp += unit.boss ? 12 : unit.commander ? 6 : 1;
                    addHeroXpLocked(unit.boss ? 20 : unit.commander ? 8 : 1);
                }
                DeathEffect effect = new DeathEffect();
                effect.x = unit.x;
                effect.y = groundY + laneOffset(unit.lane) - 10f;
                effect.lane = unit.lane;
                effect.type = unit.type;
                effect.playerSide = playerSide;
                effect.life = 1.15f;
                effect.maxLife = effect.life;
                effect.rotation = playerSide ? -8f : 8f;
                effect.rotationSpeed = playerSide ? -82f : 82f;
                effect.fallSpeed = 9f;
                effect.vx = (playerSide ? -1f : 1f) * (32f + random.nextFloat() * 28f) * uiScale;
                effect.vy = -(76f + random.nextFloat() * 48f) * uiScale;
                effect.groundY = groundY + laneOffset(unit.lane) - 3f * uiScale;
                deathEffects.add(effect);
                spawnHitParticlesLocked(unit.x, effect.y - 38f,
                        playerSide ? BLUE : RED, unit.commander ? 24 : 10, unit.commander ? 1.35f : 0.85f);
                if (!playerSide && unit.boss) {
                    bossDefeated = true;
                    if (arenaMode) {
                        bossSpawned = false;
                        arenaChampionsThisRun++;
                        profileXp += 18;
                        addHeroXpLocked(12);
                        showToastLocked("ARENA ŞAMPİYONU YENİLDİ");
                    } else {
                        bossesDefeated++;
                        boolean firstBossReward = battleLevel >= 1 && battleLevel < bossRewardClaimed.length
                                && !bossRewardClaimed[battleLevel];
                        int bossDiamonds = firstBossReward ? 3 : 1;
                        diamonds += bossDiamonds;
                        if (firstBossReward) {
                            bossRewardClaimed[battleLevel] = true;
                            campaignRecordsDirty = true;
                            upgradePoints += 1;
                        }
                        saveProgressLocked();
                        invalidateMenuCacheLocked();
                        showToastLocked(firstBossReward
                                ? "BOSS YENİLDİ • +3 ELMAS • +1 PUAN"
                                : "BOSS YENİLDİ • +1 ELMAS");
                    }
                } else if (!playerSide && unit.commander) {
                    if (arenaMode) {
                        showToastLocked("ARENA ELİTİ YENİLDİ");
                    } else {
                        commandersDefeated++;
                        diamonds += 1;
                        if (commandersDefeated % 3 == 0) upgradePoints += 1;
                        saveProgressLocked();
                        invalidateMenuCacheLocked();
                        showToastLocked(commandersDefeated % 3 == 0
                                ? "KOMUTAN YENİLDİ • +1 ELMAS • +1 PUAN"
                                : "KOMUTAN YENİLDİ • +1 ELMAS");
                    }
                }
                iterator.remove();
            }
        }
    }

    private void updateResponsiveMetricsLocked() {
        float shortestDp = Math.min(width, height) / density;
        tabletLayout = shortestDp >= 600f;
        float designW = tabletLayout ? 1600f : 1280f;
        float designH = tabletLayout ? 1000f : 720f;
        float maxScale = tabletLayout ? 1.65f : 1.28f;
        uiScale = Math.max(0.82f, Math.min(maxScale, Math.min(width / designW, height / designH)));
        safePadding = Math.max(12f, Math.min(width, height) * (tabletLayout ? 0.020f : 0.016f));
        baseInset = Math.max(122f * uiScale, Math.min(width * (tabletLayout ? 0.105f : 0.075f), 205f * uiScale));
        groundY = height * (tabletLayout ? 0.705f : 0.72f);
        // Savaş dünyası ekrandan daha uzun tutulur; kamera cepheyi yumuşak biçimde takip eder.
        if (arenaMode) {
            worldWidth = Math.max(width * (tabletLayout ? 1.08f : 1.10f), width + 180f * uiScale);
        } else {
            worldWidth = Math.max(width * (tabletLayout ? 1.46f : 1.58f), width + 640f * uiScale);
        }
        cameraX = Math.max(0f, Math.min(Math.max(0f, worldWidth - width), cameraX));
    }

    private float playerBaseX() {
        if (arenaMode) return worldWidth * 0.24f;
        return baseInset;
    }

    private float enemyBaseX() {
        if (arenaMode) return worldWidth * 0.76f;
        return worldWidth - baseInset;
    }

    private float playerStatueTargetX() {
        return playerBaseX() + 96f * uiScale;
    }

    private float enemyStatueTargetX() {
        return enemyBaseX() - 96f * uiScale;
    }

    private float combatLeftBound() {
        return playerStatueTargetX();
    }

    private float combatRightBound() {
        return enemyStatueTargetX();
    }

    private float arenaPlayerHoldXLocked() {
        return worldWidth * 0.46f;
    }

    private float arenaCameraFocusLocked() {
        return worldWidth * 0.52f;
    }

    private void updateCameraLocked(float dt) {
        if (manualCameraHoldTimer > 0f || cameraDragging) return;
        if (arenaMode) {
            float maxCameraArena = Math.max(0f, worldWidth - width);
            float focusArena = arenaCameraFocusLocked();
            Unit playerFrontArena = null;
            Unit enemyFrontArena = null;
            for (Unit unit : playerUnits) {
                if (unit.hp <= 0f || unit.type == UnitType.MINER) continue;
                if (playerFrontArena == null || unit.x > playerFrontArena.x) playerFrontArena = unit;
            }
            for (Unit unit : enemyUnits) {
                if (unit.hp <= 0f || unit.type == UnitType.MINER) continue;
                if (enemyFrontArena == null || unit.x < enemyFrontArena.x) enemyFrontArena = unit;
            }
            if (playerFrontArena != null && enemyFrontArena != null) {
                focusArena = (playerFrontArena.x + enemyFrontArena.x) * 0.5f;
            } else if (enemyFrontArena != null) {
                focusArena = Math.min(arenaCameraFocusLocked() + width * 0.10f, enemyFrontArena.x - width * 0.10f);
            } else if (playerFrontArena != null) {
                focusArena = Math.max(arenaCameraFocusLocked() - width * 0.06f, playerFrontArena.x + width * 0.06f);
            }
            float arenaTarget = Math.max(0f, Math.min(maxCameraArena, focusArena - width * 0.50f));
            float arenaSmoothing = Math.min(1f, dt * 3.0f);
            cameraX += (arenaTarget - cameraX) * arenaSmoothing;
            return;
        }
        float focusX = playerBaseX() + width * 0.42f;
        Unit playerFront = null;
        Unit enemyFront = null;
        for (Unit unit : playerUnits) {
            if (unit.hp <= 0f || unit.type == UnitType.MINER) continue;
            if (playerFront == null || unit.x > playerFront.x) playerFront = unit;
        }
        for (Unit unit : enemyUnits) {
            if (unit.hp <= 0f || unit.type == UnitType.MINER) continue;
            if (enemyFront == null || unit.x < enemyFront.x) enemyFront = unit;
        }

        if (commandMode == CommandMode.DEFEND) {
            focusX = playerBaseX() + width * 0.42f;
            if (enemyFront != null && enemyFront.x < playerDefenseBoundaryLocked() + width * 0.40f) {
                focusX = (playerDefenseBoundaryLocked() + enemyFront.x) * 0.5f;
            }
        } else if (playerFront != null && enemyFront != null) {
            float gap = enemyFront.x - playerFront.x;
            focusX = gap < width * 0.78f ? (playerFront.x + enemyFront.x) * 0.5f
                    : playerFront.x + width * 0.20f;
        } else if (playerFront != null) {
            focusX = playerFront.x + width * 0.22f;
        } else if (enemyFront != null && enemyFront.x < width * 0.95f) {
            focusX = enemyFront.x - width * 0.18f;
        }

        float maxCamera = Math.max(0f, worldWidth - width);
        float target = Math.max(0f, Math.min(maxCamera, focusX - width * 0.50f));
        float smoothing = Math.min(1f, dt * 2.6f);
        cameraX += (target - cameraX) * smoothing;
    }

    private void layoutButtonsLocked() {
        float bottom = height - safePadding;
        float buttonH = Math.max(52f * uiScale, height * (tabletLayout ? 0.078f : 0.092f));
        buttonH = Math.min(buttonH, height * 0.112f);
        float y = bottom - buttonH;
        float gap = Math.max(7f * uiScale, width * 0.0055f);

        float toggleW = Math.max(112f * uiScale, Math.min(158f * uiScale, width * 0.105f));
        float devW = Math.max(92f * uiScale, Math.min(132f * uiScale, width * 0.082f));
        float quickW = Math.min(width * 0.38f, tabletLayout ? 480f * uiScale : 360f * uiScale);
        float barW = toggleW + quickW + devW + gap * 2f;
        float barLeft = Math.max(safePadding, (width - barW) * 0.5f);
        unitMenuToggleButton.set(barLeft, y, barLeft + toggleW, bottom);
        quickUnitButton.set(unitMenuToggleButton.right + gap, y,
                unitMenuToggleButton.right + gap + quickW, bottom);
        devButton.set(quickUnitButton.right + gap, y,
                Math.min(width - safePadding, quickUnitButton.right + gap + devW), bottom);

        float menuGap = Math.max(7f * uiScale, width * 0.005f);
        float menuW = Math.min(width - safePadding * 2f, tabletLayout ? 980f * uiScale : 760f * uiScale);
        float menuCardH = Math.max(62f * uiScale, height * (tabletLayout ? 0.088f : 0.104f));
        float menuCardW = (menuW - menuGap * 3f) / 4f;
        float menuLeft = (width - menuW) * 0.5f;
        float menuTop = y - menuCardH - 9f * uiScale;
        minerButton.set(menuLeft, menuTop, menuLeft + menuCardW, menuTop + menuCardH);
        swordButton.set(minerButton.right + menuGap, menuTop,
                minerButton.right + menuGap + menuCardW, menuTop + menuCardH);
        spearButton.set(swordButton.right + menuGap, menuTop,
                swordButton.right + menuGap + menuCardW, menuTop + menuCardH);
        archerButton.set(spearButton.right + menuGap, menuTop,
                spearButton.right + menuGap + menuCardW, menuTop + menuCardH);

        float commandH = Math.max(34f * uiScale, height * 0.048f);
        float commandW = Math.max(102f * uiScale, Math.min(156f * uiScale, width * 0.105f));
        float commandTop = Math.max(safePadding + 70f * uiScale, height * (tabletLayout ? 0.105f : 0.12f));
        attackButton.set(safePadding, commandTop, safePadding + commandW, commandTop + commandH);
        defendButton.set(attackButton.right + 8f * uiScale, commandTop,
                attackButton.right + 8f * uiScale + commandW, commandTop + commandH);
        float pauseW = Math.max(82f * uiScale, Math.min(116f * uiScale, width * 0.075f));
        pauseButton.set(width - safePadding - pauseW, commandTop,
                width - safePadding, commandTop + commandH);
        float speedHudW = Math.max(66f * uiScale, Math.min(88f * uiScale, width * 0.056f));
        speedHudButton.set(pauseButton.left - 7f * uiScale - speedHudW, commandTop,
                pauseButton.left - 7f * uiScale, commandTop + commandH);
        float tacticalW = Math.max(84f * uiScale, Math.min(126f * uiScale, width * 0.082f));
        tacticalButton.set(speedHudButton.left - 7f * uiScale - tacticalW, commandTop,
                speedHudButton.left - 7f * uiScale, commandTop + commandH);

        float skillGap = Math.max(7f * uiScale, width * 0.005f);
        float skillH = Math.max(37f * uiScale, height * (tabletLayout ? 0.047f : 0.052f));
        float skillAreaW = Math.min(width * 0.47f, tabletLayout ? 760f * uiScale : 590f * uiScale);
        float skillW = (skillAreaW - skillGap * 2f) / 3f;
        float skillLeft = (width - skillAreaW) / 2f;
        float skillTop = commandTop + commandH + 7f * uiScale;
        warCryButton.set(skillLeft, skillTop, skillLeft + skillW, skillTop + skillH);
        statueShieldButton.set(warCryButton.right + skillGap, skillTop,
                warCryButton.right + skillGap + skillW, skillTop + skillH);
        arrowRainButton.set(statueShieldButton.right + skillGap, skillTop,
                statueShieldButton.right + skillGap + skillW, skillTop + skillH);

        float tacticalPanelW = Math.min(width * 0.48f, tabletLayout ? 720f * uiScale : 560f * uiScale);
        float tacticalPanelLeft = width - safePadding - tacticalPanelW;
        float tacticalTop = skillTop + skillH + 8f * uiScale;
        float tacticalGap = 7f * uiScale;
        float tacticalItemW = (tacticalPanelW - tacticalGap * 2f) / 3f;
        float tacticalItemH = Math.max(58f * uiScale, height * 0.075f);
        formationButton.set(tacticalPanelLeft, tacticalTop,
                tacticalPanelLeft + tacticalItemW, tacticalTop + tacticalItemH);
        barricadeButton.set(formationButton.right + tacticalGap, tacticalTop,
                formationButton.right + tacticalGap + tacticalItemW, tacticalTop + tacticalItemH);
        towerButton.set(barricadeButton.right + tacticalGap, tacticalTop,
                barricadeButton.right + tacticalGap + tacticalItemW, tacticalTop + tacticalItemH);

        float panelW = Math.min(width - safePadding * 2f, tabletLayout ? 760f * uiScale : 520f);
        panelW = Math.max(tabletLayout ? 560f : 390f, panelW);
        float panelLeft = width - panelW - safePadding;
        float py = Math.max(74f * uiScale, height * 0.12f);
        float panelGap = 10f * uiScale;
        float dbw = (panelW - panelGap) / 2f;
        float dbh = Math.max(52f * uiScale, height * (tabletLayout ? 0.070f : 0.083f));

        addGoldButton.set(panelLeft, py + 44f * uiScale, panelLeft + dbw, py + 44f * uiScale + dbh);
        damageButton.set(panelLeft + dbw + panelGap, py + 44f * uiScale, panelLeft + dbw * 2f + panelGap, py + 44f * uiScale + dbh);
        godButton.set(panelLeft, addGoldButton.bottom + panelGap, panelLeft + dbw, addGoldButton.bottom + panelGap + dbh);
        speedButton.set(panelLeft + dbw + panelGap, damageButton.bottom + panelGap,
                panelLeft + dbw * 2f + panelGap, damageButton.bottom + panelGap + dbh);

        // v0.2.8: Ana menü dört başlık altında sadeleştirildi.
        float sw = Math.min(width * 0.54f, tabletLayout ? 720f * uiScale : 520f * uiScale);
        sw = Math.max(340f, sw);
        float sh = Math.max(74f * uiScale, height * (tabletLayout ? 0.096f : 0.104f));
        float sy = height * (tabletLayout ? 0.472f : 0.468f);
        startButton.set((width - sw) / 2f, sy, (width + sw) / 2f, sy + sh);

        float categoryGap = Math.max(14f * uiScale, width * 0.012f);
        float categoryRowGap = Math.max(12f * uiScale, height * 0.016f);
        float categoryArea = Math.min(width - safePadding * 2f,
                tabletLayout ? 860f * uiScale : 720f * uiScale);
        float categoryW = (categoryArea - categoryGap) / 2f;
        float categoryH = Math.max(76f * uiScale, height * (tabletLayout ? 0.092f : 0.096f));
        float categoryLeft = (width - categoryArea) / 2f;
        float categoryTop = startButton.bottom + Math.max(16f * uiScale, height * 0.022f);
        categoryBattleButton.set(categoryLeft, categoryTop,
                categoryLeft + categoryW, categoryTop + categoryH);
        categoryProgressButton.set(categoryBattleButton.right + categoryGap, categoryTop,
                categoryBattleButton.right + categoryGap + categoryW, categoryTop + categoryH);
        categoryEconomyButton.set(categoryLeft, categoryTop + categoryH + categoryRowGap,
                categoryLeft + categoryW, categoryTop + categoryH + categoryRowGap + categoryH);
        categorySystemButton.set(categoryProgressButton.left, categoryTop + categoryH + categoryRowGap,
                categoryProgressButton.right, categoryTop + categoryH + categoryRowGap + categoryH);

        // Alt ekranlarda kullanılan üç eylem kartı.
        float hubPrimaryW = Math.min(width * 0.56f, tabletLayout ? 760f * uiScale : 560f * uiScale);
        float hubPrimaryH = Math.max(76f * uiScale, height * 0.10f);
        float hubPrimaryTop = height * 0.34f;
        hubPrimaryButton.set((width - hubPrimaryW) / 2f, hubPrimaryTop,
                (width + hubPrimaryW) / 2f, hubPrimaryTop + hubPrimaryH);
        float hubSecondaryGap = Math.max(14f * uiScale, width * 0.012f);
        float hubSecondaryArea = Math.min(width - safePadding * 2f,
                tabletLayout ? 920f * uiScale : 760f * uiScale);
        float hubSecondaryW = (hubSecondaryArea - hubSecondaryGap) / 2f;
        float hubSecondaryH = Math.max(74f * uiScale, height * 0.094f);
        float hubSecondaryLeft = (width - hubSecondaryArea) / 2f;
        float hubSecondaryTop = hubPrimaryButton.bottom + Math.max(16f * uiScale, height * 0.022f);
        hubSecondaryButton.set(hubSecondaryLeft, hubSecondaryTop,
                hubSecondaryLeft + hubSecondaryW, hubSecondaryTop + hubSecondaryH);
        hubTertiaryButton.set(hubSecondaryButton.right + hubSecondaryGap, hubSecondaryTop,
                hubSecondaryButton.right + hubSecondaryGap + hubSecondaryW, hubSecondaryTop + hubSecondaryH);

        // Eski düğmeler diğer ekranlar için ayrık tutuluyor.
        mapMenuButton.set(hubSecondaryLeft, hubSecondaryTop,
                hubSecondaryLeft + hubSecondaryW, hubSecondaryTop + hubSecondaryH);
        arenaMenuButton.set(hubSecondaryButton.right + hubSecondaryGap, hubSecondaryTop,
                hubSecondaryButton.right + hubSecondaryGap + hubSecondaryW, hubSecondaryTop + hubSecondaryH);
        mineMenuButton.set(hubSecondaryLeft, hubSecondaryTop,
                hubSecondaryLeft + hubSecondaryW, hubSecondaryTop + hubSecondaryH);
        missionsButton.set(hubSecondaryButton.right + hubSecondaryGap, hubSecondaryTop,
                hubSecondaryButton.right + hubSecondaryGap + hubSecondaryW, hubSecondaryTop + hubSecondaryH);
        heroMenuButton.set(hubPrimaryButton.left, hubPrimaryButton.top, hubPrimaryButton.right, hubPrimaryButton.bottom);
        upgradesButton.set(hubSecondaryLeft, hubSecondaryTop,
                hubSecondaryLeft + hubSecondaryW, hubSecondaryTop + hubSecondaryH);
        shopButton.set(hubSecondaryButton.right + hubSecondaryGap, hubSecondaryTop,
                hubSecondaryButton.right + hubSecondaryGap + hubSecondaryW, hubSecondaryTop + hubSecondaryH);
        settingsButton.set(hubPrimaryButton.left, hubPrimaryButton.top, hubPrimaryButton.right, hubPrimaryButton.bottom);

        float arenaStartW = Math.min(width * 0.54f, tabletLayout ? 720f * uiScale : 520f * uiScale);
        float arenaStartH = Math.max(66f * uiScale, height * 0.092f);
        arenaStartButton.set((width - arenaStartW) / 2f, height - safePadding - arenaStartH,
                (width + arenaStartW) / 2f, height - safePadding);

        float heroAreaW = Math.min(width - safePadding * 2f, tabletLayout ? 1420f * uiScale : 1080f * uiScale);
        float heroGap = Math.max(14f * uiScale, width * 0.012f);
        float heroCardW = (heroAreaW - heroGap * 2f) / 3f;
        float heroCardH = Math.max(165f * uiScale, height * 0.31f);
        float heroLeft = (width - heroAreaW) / 2f;
        float heroTop = height * 0.52f;
        heroPowerButton.set(heroLeft, heroTop, heroLeft + heroCardW, heroTop + heroCardH);
        heroArmorButton.set(heroPowerButton.right + heroGap, heroTop,
                heroPowerButton.right + heroGap + heroCardW, heroTop + heroCardH);
        heroLeadershipButton.set(heroArmorButton.right + heroGap, heroTop,
                heroArmorButton.right + heroGap + heroCardW, heroTop + heroCardH);

        float missionTabGap = 12f * uiScale;
        float missionTabW = Math.min(310f * uiScale, width * 0.25f);
        float missionTabH = Math.max(48f * uiScale, height * 0.067f);
        float missionTabsLeft = width * 0.5f - missionTabW - missionTabGap * 0.5f;
        float missionTabsTop = height * 0.205f;
        missionDailyTabButton.set(missionTabsLeft, missionTabsTop,
                missionTabsLeft + missionTabW, missionTabsTop + missionTabH);
        missionAchievementTabButton.set(missionDailyTabButton.right + missionTabGap, missionTabsTop,
                missionDailyTabButton.right + missionTabGap + missionTabW, missionTabsTop + missionTabH);

        float missionAreaW = Math.min(width - safePadding * 2f, tabletLayout ? 1450f * uiScale : 1160f * uiScale);
        float missionGap = Math.max(12f * uiScale, width * 0.009f);
        float missionTop = height * 0.31f;
        float missionCardW = (missionAreaW - missionGap * 2f) / 3f;
        float missionCardH = Math.max(145f * uiScale, height * 0.30f);
        float missionLeft = (width - missionAreaW) / 2f;
        dailyWinButton.set(missionLeft, missionTop, missionLeft + missionCardW, missionTop + missionCardH);
        dailyMineButton.set(dailyWinButton.right + missionGap, missionTop,
                dailyWinButton.right + missionGap + missionCardW, missionTop + missionCardH);
        dailyKillButton.set(dailyMineButton.right + missionGap, missionTop,
                dailyMineButton.right + missionGap + missionCardW, missionTop + missionCardH);
        float chestTop = dailyWinButton.bottom + missionGap;
        float chestH = Math.max(70f * uiScale, height * 0.125f);
        float chestW = (missionAreaW - missionGap) / 2f;
        dailyChestButton.set(missionLeft, chestTop, missionLeft + chestW, chestTop + chestH);
        battleChestButton.set(dailyChestButton.right + missionGap, chestTop,
                dailyChestButton.right + missionGap + chestW, chestTop + chestH);

        int achievementColumns = 3;
        float achievementW = (missionAreaW - missionGap * (achievementColumns - 1)) / achievementColumns;
        float achievementH = Math.max(120f * uiScale, height * 0.215f);
        for (int index = 0; index < achievementButtons.length; index++) {
            int row = index / achievementColumns;
            int column = index % achievementColumns;
            float itemLeft = missionLeft + column * (achievementW + missionGap);
            if (row == 1 && index >= 3) itemLeft += (achievementW + missionGap) * 0.5f;
            float itemTop = missionTop + row * (achievementH + missionGap);
            achievementButtons[index].set(itemLeft, itemTop, itemLeft + achievementW, itemTop + achievementH);
        }

        // v0.3.3: Kart ızgarası yerine iki satırlı kıvrımlı sefer yolu.
        float mapAreaW = Math.min(width - safePadding * 3.2f,
                tabletLayout ? 1390f * uiScale : 1120f * uiScale);
        float mapLeft = (width - mapAreaW) / 2f;
        float nodeW = Math.max(118f * uiScale, Math.min(176f * uiScale, mapAreaW * 0.125f));
        float nodeH = Math.max(78f * uiScale, height * 0.112f);
        float routeTop = height * (tabletLayout ? 0.305f : 0.295f);
        float routeBottom = height * (tabletLayout ? 0.555f : 0.565f);
        float stepX = (mapAreaW - nodeW) / 4f;
        for (int index = 0; index < mapLevelButtons.length; index++) {
            int row = index / 5;
            int column = index % 5;
            int visualColumn = row == 0 ? column : 4 - column;
            float wave = (float) Math.sin((visualColumn + row * 0.65f) * 1.35f) * 13f * uiScale;
            float nodeLeft = mapLeft + visualColumn * stepX;
            float nodeTop = (row == 0 ? routeTop : routeBottom) + wave;
            mapLevelButtons[index].set(nodeLeft, nodeTop, nodeLeft + nodeW, nodeTop + nodeH);
        }

        float mapNavW = Math.max(145f * uiScale,
                Math.min(230f * uiScale, width * 0.155f));
        float mapNavH = Math.max(58f * uiScale, height * 0.078f);
        float mapNavTop = height * 0.165f;
        mapPrevButton.set(safePadding + 10f * uiScale, mapNavTop,
                safePadding + 10f * uiScale + mapNavW, mapNavTop + mapNavH);
        mapNextButton.set(width - safePadding - 10f * uiScale - mapNavW, mapNavTop,
                width - safePadding - 10f * uiScale, mapNavTop + mapNavH);

        float mapStartW = Math.min(width * 0.31f,
                tabletLayout ? 500f * uiScale : 410f * uiScale);
        float mapStartH = Math.max(72f * uiScale, height * 0.098f);
        float detailTop = height * 0.705f;
        float detailBottom = height - safePadding - 8f * uiScale;
        mapStartButton.set(width - safePadding - mapStartW - 24f * uiScale,
                detailTop + (detailBottom - detailTop - mapStartH) * 0.5f,
                width - safePadding - 24f * uiScale,
                detailTop + (detailBottom - detailTop + mapStartH) * 0.5f);

        float backW = Math.max(150f * uiScale, Math.min(230f * uiScale, width * 0.165f));
        float backH = Math.max(58f * uiScale, height * 0.078f);
        backButton.set(safePadding, safePadding, safePadding + backW, safePadding + backH);

        float mineW = Math.min(width * 0.48f, tabletLayout ? 620f * uiScale : 460f * uiScale);
        float mineH = Math.max(62f * uiScale, height * 0.09f);
        mineDigButton.set((width - mineW) / 2f, height - safePadding - mineH,
                (width + mineW) / 2f, height - safePadding);

        float overlayW = Math.min(width * 0.56f, tabletLayout ? 700f * uiScale : 520f * uiScale);
        float overlayH = Math.max(58f * uiScale, height * 0.082f);
        float overlayLeft = (width - overlayW) / 2f;
        float overlayTop = height * 0.40f;
        pauseContinueButton.set(overlayLeft, overlayTop, overlayLeft + overlayW, overlayTop + overlayH);
        pauseRestartButton.set(overlayLeft, pauseContinueButton.bottom + 12f * uiScale,
                overlayLeft + overlayW, pauseContinueButton.bottom + 12f * uiScale + overlayH);
        pauseMenuButton.set(overlayLeft, pauseRestartButton.bottom + 12f * uiScale,
                overlayLeft + overlayW, pauseRestartButton.bottom + 12f * uiScale + overlayH);

        float settingsAreaW = Math.min(width * 0.78f,
                tabletLayout ? 1120f * uiScale : 860f * uiScale);
        settingsAreaW = Math.max(580f, settingsAreaW);
        float settingsGap = Math.max(10f * uiScale, width * 0.009f);
        float settingsCardW = (settingsAreaW - settingsGap) / 2f;
        float settingsCardH = Math.max(58f * uiScale, height * 0.082f);
        float settingsLeft = (width - settingsAreaW) / 2f;
        float settingsTop = height * 0.315f;
        musicToggleButton.set(settingsLeft, settingsTop,
                settingsLeft + settingsCardW, settingsTop + settingsCardH);
        effectsToggleButton.set(musicToggleButton.right + settingsGap, settingsTop,
                musicToggleButton.right + settingsGap + settingsCardW, settingsTop + settingsCardH);
        musicVolumeButton.set(settingsLeft, musicToggleButton.bottom + settingsGap,
                settingsLeft + settingsCardW, musicToggleButton.bottom + settingsGap + settingsCardH);
        effectsVolumeButton.set(effectsToggleButton.left, effectsToggleButton.bottom + settingsGap,
                effectsToggleButton.right, effectsToggleButton.bottom + settingsGap + settingsCardH);
        float resetH = Math.max(58f * uiScale, height * 0.082f);
        resetLevelButton.set(settingsLeft, musicVolumeButton.bottom + settingsGap,
                settingsLeft + settingsAreaW, musicVolumeButton.bottom + settingsGap + resetH);
        resetProgressButton.set(settingsLeft, resetLevelButton.bottom + settingsGap,
                settingsLeft + settingsAreaW, resetLevelButton.bottom + settingsGap + resetH);

        float upgradeGap = Math.max(10f * uiScale, width * 0.009f);
        float upgradeAreaW = Math.min(width - safePadding * 2f,
                tabletLayout ? 1540f * uiScale : 1160f * uiScale);
        int columns = tabletLayout ? 5 : 3;
        float upgradeCardW = (upgradeAreaW - upgradeGap * (columns - 1)) / columns;
        float upgradeCardH = Math.max(116f * uiScale, height * (tabletLayout ? 0.205f : 0.215f));
        float upgradeLeft = (width - upgradeAreaW) / 2f;
        float upgradeTop = height * (tabletLayout ? 0.34f : 0.30f);
        RectF[] cards = new RectF[]{upgradeStatueButton, upgradeMinerButton, upgradeSwordButton,
                upgradeSpearCard, upgradeArcherButton};
        for (int i = 0; i < cards.length; i++) {
            int row = i / columns;
            int col = i % columns;
            float rowCount = Math.min(columns, cards.length - row * columns);
            float rowWidth = rowCount * upgradeCardW + Math.max(0f, rowCount - 1f) * upgradeGap;
            float rowLeft = row == 0 ? upgradeLeft : (width - rowWidth) * 0.5f;
            float leftX = rowLeft + col * (upgradeCardW + upgradeGap);
            float topY = upgradeTop + row * (upgradeCardH + upgradeGap);
            cards[i].set(leftX, topY, leftX + upgradeCardW, topY + upgradeCardH);
        }
        float spearPad = Math.max(7f * uiScale, upgradeSpearCard.width() * 0.035f);
        float spearButtonTop = upgradeSpearCard.top + upgradeSpearCard.height() * 0.72f;
        float spearInnerGap = Math.max(6f * uiScale, upgradeSpearCard.width() * 0.025f);
        float spearInnerW = (upgradeSpearCard.width() - spearPad * 2f - spearInnerGap) * 0.5f;
        upgradeSpearPowerButton.set(upgradeSpearCard.left + spearPad, spearButtonTop,
                upgradeSpearCard.left + spearPad + spearInnerW, upgradeSpearCard.bottom - spearPad);
        upgradeSpearRangeButton.set(upgradeSpearPowerButton.right + spearInnerGap, spearButtonTop,
                upgradeSpearCard.right - spearPad, upgradeSpearCard.bottom - spearPad);

        float shopTabGap = 12f * uiScale;
        float shopTabW = Math.min(300f * uiScale, width * 0.22f);
        float shopTabH = Math.max(48f * uiScale, height * 0.067f);
        float shopTabsLeft = width * 0.5f - shopTabW - shopTabGap * 0.5f;
        float shopTabsTop = height * 0.205f;
        shopOutfitsTabButton.set(shopTabsLeft, shopTabsTop,
                shopTabsLeft + shopTabW, shopTabsTop + shopTabH);
        shopPowersTabButton.set(shopOutfitsTabButton.right + shopTabGap, shopTabsTop,
                shopOutfitsTabButton.right + shopTabGap + shopTabW, shopTabsTop + shopTabH);

        float shopAreaW = Math.min(width - safePadding * 2f, tabletLayout ? 1450f * uiScale : 1160f * uiScale);
        float shopGap = Math.max(12f * uiScale, width * 0.009f);
        float shopTop = height * 0.31f;
        float outfitCardW = (shopAreaW - shopGap * 3f) / 4f;
        float outfitCardH = Math.min(height * 0.53f, Math.max(240f * uiScale, height * 0.46f));
        float shopLeft = (width - shopAreaW) / 2f;
        shopMinerOutfitButton.set(shopLeft, shopTop, shopLeft + outfitCardW, shopTop + outfitCardH);
        shopSwordOutfitButton.set(shopMinerOutfitButton.right + shopGap, shopTop,
                shopMinerOutfitButton.right + shopGap + outfitCardW, shopTop + outfitCardH);
        shopSpearOutfitButton.set(shopSwordOutfitButton.right + shopGap, shopTop,
                shopSwordOutfitButton.right + shopGap + outfitCardW, shopTop + outfitCardH);
        shopArcherOutfitButton.set(shopSpearOutfitButton.right + shopGap, shopTop,
                shopSpearOutfitButton.right + shopGap + outfitCardW, shopTop + outfitCardH);
        float buyH = Math.max(48f * uiScale, outfitCardH * 0.19f);
        shopMinerBuyButton.set(shopMinerOutfitButton.left + 8f * uiScale,
                shopMinerOutfitButton.bottom - buyH - 8f * uiScale,
                shopMinerOutfitButton.right - 8f * uiScale, shopMinerOutfitButton.bottom - 8f * uiScale);
        shopSwordBuyButton.set(shopSwordOutfitButton.left + 8f * uiScale,
                shopSwordOutfitButton.bottom - buyH - 8f * uiScale,
                shopSwordOutfitButton.right - 8f * uiScale, shopSwordOutfitButton.bottom - 8f * uiScale);
        shopSpearBuyButton.set(shopSpearOutfitButton.left + 8f * uiScale,
                shopSpearOutfitButton.bottom - buyH - 8f * uiScale,
                shopSpearOutfitButton.right - 8f * uiScale, shopSpearOutfitButton.bottom - 8f * uiScale);
        shopArcherBuyButton.set(shopArcherOutfitButton.left + 8f * uiScale,
                shopArcherOutfitButton.bottom - buyH - 8f * uiScale,
                shopArcherOutfitButton.right - 8f * uiScale, shopArcherOutfitButton.bottom - 8f * uiScale);

        float powerCardW = (shopAreaW - shopGap * 3f) / 4f;
        float powerCardH = Math.min(height * 0.49f, Math.max(230f * uiScale, height * 0.43f));
        shopStatuePowerButton.set(shopLeft, shopTop, shopLeft + powerCardW, shopTop + powerCardH);
        shopMinerPowerButton.set(shopStatuePowerButton.right + shopGap, shopTop,
                shopStatuePowerButton.right + shopGap + powerCardW, shopTop + powerCardH);
        shopSwordPowerButton.set(shopMinerPowerButton.right + shopGap, shopTop,
                shopMinerPowerButton.right + shopGap + powerCardW, shopTop + powerCardH);
        shopArcherPowerButton.set(shopSwordPowerButton.right + shopGap, shopTop,
                shopSwordPowerButton.right + shopGap + powerCardW, shopTop + powerCardH);
    }

    private void drawGameLocked(Canvas canvas) {
        width = Math.max(1f, canvas.getWidth());
        height = Math.max(1f, canvas.getHeight());
        updateResponsiveMetricsLocked();
        layoutButtonsLocked();

        if (screen == Screen.MENU) {
            drawCachedMenu(canvas);
        } else if (screen == Screen.HUB_BATTLE) {
            drawBackground(canvas);
            drawBattleHub(canvas);
        } else if (screen == Screen.HUB_PROGRESS) {
            drawBackground(canvas);
            drawProgressHub(canvas);
        } else if (screen == Screen.HUB_ECONOMY) {
            drawBackground(canvas);
            drawEconomyHub(canvas);
        } else if (screen == Screen.HUB_SYSTEM) {
            drawBackground(canvas);
            drawSystemHub(canvas);
        } else if (screen == Screen.MAP) {
            drawBackground(canvas);
            drawCampaignMap(canvas);
        } else if (screen == Screen.ARENA) {
            drawBackground(canvas);
            drawArenaScreen(canvas);
        } else if (screen == Screen.MISSIONS) {
            drawBackground(canvas);
            drawMissionsScreen(canvas);
        } else if (screen == Screen.HERO) {
            drawBackground(canvas);
            drawHeroScreen(canvas);
        } else if (screen == Screen.UPGRADES) {
            drawBackground(canvas);
            drawUpgradeScreen(canvas);
        } else if (screen == Screen.SHOP) {
            drawBackground(canvas);
            drawShopScreen(canvas);
        } else if (screen == Screen.MINE) {
            drawBackground(canvas);
            drawMineScreen(canvas);
        } else if (screen == Screen.SETTINGS) {
            drawBackground(canvas);
            drawSettingsScreen(canvas);
        } else {
            drawBackground(canvas);
            drawBattlefield(canvas);
            drawHud(canvas);
            if (chapterBannerTimer > 0f && screen == Screen.PLAYING) drawChapterBanner(canvas);
            if (waveBannerTimer > 0f && screen == Screen.PLAYING) drawWaveBanner(canvas);
            if (commanderBannerTimer > 0f && screen == Screen.PLAYING) drawCommanderBanner(canvas);
            if (bossBannerTimer > 0f && screen == Screen.PLAYING) drawBossBanner(canvas);
            if (tacticalPanel && screen == Screen.PLAYING) drawTacticalPanel(canvas);
            if (developerPanel && screen == Screen.PLAYING) drawDeveloperPanel(canvas);
            if (screen == Screen.PLAYING || screen == Screen.WIN || screen == Screen.LOSE) drawCombatFeelOverlay(canvas);
            if (screen == Screen.PAUSED) drawPauseOverlay(canvas);
            if (screen == Screen.WIN || screen == Screen.LOSE) drawResult(canvas);
        }
        if (toastTimer > 0f) drawToast(canvas);
    }

    private void drawFatalError(Canvas canvas, Throwable error) {
        canvas.drawColor(Color.rgb(15, 23, 42));
        paint.setColor(Color.WHITE);
        paint.setTextAlign(Paint.Align.LEFT);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(26f);
        canvas.drawText("UYGAR WARS HATA EKRANI", 28f, 54f, paint);
        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(17f);
        String detail = error.getClass().getSimpleName() + ": " + String.valueOf(error.getMessage());
        canvas.drawText(trimText(detail, 100), 28f, 92f, paint);
        canvas.drawText("Bu ekranın fotoğrafını gönder.", 28f, 128f, paint);
    }

    private String trimText(String text, int max) {
        if (text == null) return "Bilinmeyen hata";
        return text.length() <= max ? text : text.substring(0, max);
    }

    private void invalidateSceneCachesLocked() {
        if (backgroundCache != null) {
            backgroundCache.recycle();
            backgroundCache = null;
        }
        if (menuCache != null) {
            menuCache.recycle();
            menuCache = null;
        }
        cacheWidth = -1;
        cacheHeight = -1;
        cacheThemeKey = -1;
        menuCacheWins = -1;
        menuCacheProgressHash = -1;
    }

    private void ensureBackgroundCacheLocked() {
        int targetWidth = Math.max(1, Math.round(width));
        int targetHeight = Math.max(1, Math.round(height));
        int themeKey = backgroundThemeKeyLocked();
        if (backgroundCache != null && !backgroundCache.isRecycled()
                && cacheWidth == targetWidth && cacheHeight == targetHeight
                && cacheThemeKey == themeKey) {
            return;
        }
        invalidateSceneCachesLocked();
        cacheWidth = targetWidth;
        cacheHeight = targetHeight;
        cacheThemeKey = themeKey;

        // İki ARGB tamponun düşük bellekli telefonlarda süreci kapatmasını önlemek
        // için önbellek boyutu güvenli bir üst sınırda tutulur.
        cacheRenderScale = Math.min(1f, Math.min(1280f / targetWidth, 800f / targetHeight));
        int bitmapW = Math.max(1, Math.round(targetWidth * cacheRenderScale));
        int bitmapH = Math.max(1, Math.round(targetHeight * cacheRenderScale));
        try {
            backgroundCache = Bitmap.createBitmap(bitmapW, bitmapH, Bitmap.Config.ARGB_8888);
            Canvas cacheCanvas = new Canvas(backgroundCache);
            cacheCanvas.scale(cacheRenderScale, cacheRenderScale);
            renderBackground(cacheCanvas);
            cacheDisabled = false;
        } catch (Throwable allocationError) {
            if (backgroundCache != null) {
                backgroundCache.recycle();
                backgroundCache = null;
            }
            cacheDisabled = true;
        }
    }

    private void drawCachedMenu(Canvas canvas) {
        ensureBackgroundCacheLocked();
        if (cacheDisabled || backgroundCache == null || backgroundCache.isRecycled()) {
            renderBackground(canvas);
            drawMenuScenery(canvas);
            drawMenu(canvas);
            return;
        }

        int bitmapW = backgroundCache.getWidth();
        int bitmapH = backgroundCache.getHeight();
        int progressHash = menuProgressHashLocked();
        if (menuCache == null || menuCache.isRecycled() || menuCacheWins != wins
                || menuCacheProgressHash != progressHash
                || menuCache.getWidth() != bitmapW || menuCache.getHeight() != bitmapH) {
            if (menuCache != null) {
                menuCache.recycle();
                menuCache = null;
            }
            try {
                menuCache = Bitmap.createBitmap(bitmapW, bitmapH, Bitmap.Config.ARGB_8888);
                Canvas menuCanvas = new Canvas(menuCache);
                paint.setShader(null);
                paint.setColor(Color.WHITE);
                paint.setFilterBitmap(true);
                menuCanvas.drawBitmap(backgroundCache, 0f, 0f, paint);
                paint.setFilterBitmap(false);
                menuCanvas.save();
                menuCanvas.scale(cacheRenderScale, cacheRenderScale);
                drawMenuScenery(menuCanvas);
                drawMenu(menuCanvas);
                menuCanvas.restore();
                menuCacheWins = wins;
                menuCacheProgressHash = progressHash;
            } catch (Throwable allocationError) {
                if (menuCache != null) {
                    menuCache.recycle();
                    menuCache = null;
                }
                cacheDisabled = true;
                renderBackground(canvas);
                drawMenuScenery(canvas);
                drawMenu(canvas);
                return;
            }
        }
        paint.setShader(null);
        paint.setColor(Color.WHITE);
        paint.setFilterBitmap(true);
        canvas.drawBitmap(menuCache, null, new RectF(0f, 0f, width, height), paint);
        paint.setFilterBitmap(false);
    }

    private void drawBackground(Canvas canvas) {
        ensureBackgroundCacheLocked();
        if (backgroundCache != null && !backgroundCache.isRecycled()) {
            paint.setShader(null);
            paint.setColor(Color.WHITE);
            paint.setFilterBitmap(true);
            canvas.drawBitmap(backgroundCache, null, new RectF(0f, 0f, width, height), paint);
            paint.setFilterBitmap(false);
        } else {
            renderBackground(canvas);
        }
    }

    private void renderBackground(Canvas canvas) {
        int theme = backgroundThemeKeyLocked();
        int[] sky;
        int mountainFar;
        int mountainNear;
        int hillColor;
        int groundTop;
        int groundBottom;
        int edgeColor;

        if (theme == 2) {
            sky = new int[]{Color.rgb(36, 19, 28), Color.rgb(137, 59, 44), Color.rgb(210, 116, 58), Color.rgb(98, 58, 37)};
            mountainFar = Color.rgb(96, 50, 43);
            mountainNear = Color.rgb(112, 61, 46);
            hillColor = Color.rgb(91, 58, 43);
            groundTop = Color.rgb(127, 78, 44);
            groundBottom = Color.rgb(49, 31, 25);
            edgeColor = Color.rgb(245, 153, 68);
        } else if (theme == 3) {
            sky = new int[]{Color.rgb(7, 20, 38), Color.rgb(26, 64, 91), Color.rgb(102, 143, 158), Color.rgb(73, 91, 98)};
            mountainFar = Color.rgb(56, 83, 103);
            mountainNear = Color.rgb(69, 94, 108);
            hillColor = Color.rgb(75, 96, 103);
            groundTop = Color.rgb(97, 116, 121);
            groundBottom = Color.rgb(35, 48, 56);
            edgeColor = Color.rgb(174, 231, 255);
        } else if (theme == 4) {
            sky = new int[]{Color.rgb(16, 10, 18), Color.rgb(74, 30, 34), Color.rgb(128, 55, 40), Color.rgb(52, 33, 29)};
            mountainFar = Color.rgb(58, 42, 47);
            mountainNear = Color.rgb(71, 47, 44);
            hillColor = Color.rgb(59, 47, 43);
            groundTop = Color.rgb(71, 51, 42);
            groundBottom = Color.rgb(25, 21, 22);
            edgeColor = Color.rgb(255, 103, 55);
        } else if (theme == 5) {
            sky = new int[]{Color.rgb(4, 7, 17), Color.rgb(22, 20, 48), Color.rgb(54, 48, 78), Color.rgb(38, 33, 48)};
            mountainFar = Color.rgb(31, 31, 56);
            mountainNear = Color.rgb(42, 39, 65);
            hillColor = Color.rgb(39, 39, 54);
            groundTop = Color.rgb(48, 43, 58);
            groundBottom = Color.rgb(18, 18, 27);
            edgeColor = Color.rgb(173, 115, 255);
        } else if (theme == 6) {
            sky = new int[]{Color.rgb(8, 5, 22), Color.rgb(34, 18, 62), Color.rgb(87, 48, 108), Color.rgb(47, 33, 58)};
            mountainFar = Color.rgb(42, 30, 69);
            mountainNear = Color.rgb(56, 38, 79);
            hillColor = Color.rgb(48, 37, 65);
            groundTop = Color.rgb(61, 43, 69);
            groundBottom = Color.rgb(21, 17, 29);
            edgeColor = Color.rgb(191, 127, 255);
        } else {
            sky = new int[]{Color.rgb(5, 13, 28), Color.rgb(16, 35, 62), Color.rgb(62, 69, 78), Color.rgb(52, 43, 35)};
            mountainFar = Color.rgb(28, 42, 61);
            mountainNear = Color.rgb(35, 45, 54);
            hillColor = Color.rgb(43, 47, 47);
            groundTop = Color.rgb(58, 50, 40);
            groundBottom = Color.rgb(25, 23, 21);
            edgeColor = Color.rgb(235, 169, 68);
        }

        paint.setShader(new LinearGradient(0f, 0f, 0f, height, sky,
                new float[]{0f, 0.42f, 0.69f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRect(0f, 0f, width, height, paint);
        paint.setShader(null);

        if (theme == 2) drawDesertSun(canvas);
        else if (theme == 3) drawAurora(canvas);
        else if (theme == 4) drawAshSky(canvas);
        else if (theme == 5) drawShadowEclipse(canvas);
        else if (theme == 6) drawArenaRift(canvas);
        else {
            drawStars(canvas);
            drawMoon(canvas);
        }

        drawCloudBands(canvas);
        drawMountainLayer(canvas, height * 0.43f, height * 0.70f, mountainFar, 0.03f);
        drawMountainLayer(canvas, height * 0.51f, height * 0.72f, mountainNear, 0.11f);
        drawHillLayerThemed(canvas, hillColor);
        drawDistantLights(canvas);
        drawGroundThemed(canvas, groundTop, groundBottom, edgeColor);
        drawThemeParticles(canvas, theme);
    }

    private int backgroundThemeKeyLocked() {
        if (screen == Screen.ARENA || arenaMode) return 6;
        if (screen == Screen.MAP) return Math.max(1, Math.min(5, mapPage + 1));
        if (screen == Screen.PLAYING || screen == Screen.PAUSED
                || screen == Screen.WIN || screen == Screen.LOSE) {
            return chapterForLevelLocked(battleLevel);
        }
        return 1;
    }

    private void drawDesertSun(Canvas canvas) {
        float x = width * 0.78f;
        float y = height * 0.19f;
        float r = Math.max(38f, height * 0.095f);
        paint.setShader(new RadialGradient(x, y, r * 2.1f,
                new int[]{Color.argb(220, 255, 225, 151), Color.argb(70, 255, 143, 64), Color.TRANSPARENT},
                new float[]{0f, 0.46f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawCircle(x, y, r * 2.1f, paint);
        paint.setShader(null);
        paint.setColor(Color.rgb(255, 218, 146));
        canvas.drawCircle(x, y, r, paint);
    }

    private void drawAurora(Canvas canvas) {
        drawStars(canvas);
        paint.setShader(new LinearGradient(0f, height * 0.06f, width, height * 0.36f,
                new int[]{Color.TRANSPARENT, Color.argb(92, 97, 255, 208), Color.argb(76, 103, 178, 255), Color.TRANSPARENT},
                null, Shader.TileMode.CLAMP));
        Path aurora = new Path();
        aurora.moveTo(-width * 0.08f, height * 0.18f);
        aurora.cubicTo(width * 0.24f, height * 0.02f, width * 0.43f, height * 0.33f, width * 0.72f, height * 0.11f);
        aurora.cubicTo(width * 0.88f, height * 0.03f, width * 1.02f, height * 0.18f, width * 1.10f, height * 0.08f);
        aurora.lineTo(width * 1.10f, height * 0.31f);
        aurora.cubicTo(width * 0.78f, height * 0.42f, width * 0.53f, height * 0.21f, width * 0.25f, height * 0.39f);
        aurora.lineTo(-width * 0.08f, height * 0.36f);
        aurora.close();
        canvas.drawPath(aurora, paint);
        paint.setShader(null);
        drawMoon(canvas);
    }

    private void drawAshSky(Canvas canvas) {
        paint.setShader(new RadialGradient(width * 0.22f, height * 0.40f, height * 0.44f,
                new int[]{Color.argb(150, 255, 83, 35), Color.argb(38, 182, 43, 29), Color.TRANSPARENT},
                new float[]{0f, 0.52f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRect(0f, 0f, width, height, paint);
        paint.setShader(null);
        for (int i = 0; i < 28; i++) {
            float x = ((i * 181) % 997) / 997f * width;
            float y = height * (0.06f + (((i * 59) % 431) / 431f) * 0.50f);
            paint.setColor(Color.argb(80 + (i % 4) * 24, 255, 104, 48));
            canvas.drawCircle(x, y, 1.2f + (i % 3) * 0.8f, paint);
        }
    }

    private void drawShadowEclipse(Canvas canvas) {
        drawStars(canvas);
        float x = width * 0.79f;
        float y = height * 0.18f;
        float r = Math.max(36f, height * 0.09f);
        paint.setShader(new RadialGradient(x, y, r * 1.65f,
                new int[]{Color.argb(180, 191, 127, 255), Color.argb(45, 120, 74, 190), Color.TRANSPARENT},
                new float[]{0.35f, 0.62f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawCircle(x, y, r * 1.65f, paint);
        paint.setShader(null);
        paint.setColor(Color.rgb(9, 9, 18));
        canvas.drawCircle(x, y, r, paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3f * uiScale);
        stroke.setColor(Color.argb(210, 201, 155, 255));
        canvas.drawCircle(x, y, r + 4f * uiScale, stroke);
    }

    private void drawArenaRift(Canvas canvas) {
        drawStars(canvas);
        float x = width * 0.50f;
        float y = height * 0.19f;
        paint.setShader(new RadialGradient(x, y, height * 0.28f,
                new int[]{Color.argb(175, 198, 121, 255), Color.argb(60, 95, 54, 164), Color.TRANSPARENT},
                new float[]{0f, 0.46f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawOval(new RectF(x - width * 0.14f, y - height * 0.05f,
                x + width * 0.14f, y + height * 0.05f), paint);
        paint.setShader(null);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3.2f * uiScale);
        stroke.setColor(Color.argb(205, 209, 158, 255));
        canvas.drawOval(new RectF(x - width * 0.11f, y - height * 0.035f,
                x + width * 0.11f, y + height * 0.035f), stroke);
    }

    private void drawHillLayerThemed(Canvas canvas, int hillColor) {
        Path hills = new Path();
        hills.moveTo(0f, groundY);
        hills.cubicTo(width * 0.18f, height * 0.55f, width * 0.27f, height * 0.67f, width * 0.43f, groundY);
        hills.cubicTo(width * 0.62f, height * 0.55f, width * 0.79f, height * 0.59f, width, groundY);
        hills.close();
        paint.setColor(hillColor);
        canvas.drawPath(hills, paint);
        paint.setShader(new LinearGradient(0f, groundY - height * 0.15f, 0f, groundY,
                Color.argb(68, 205, 216, 220), Color.TRANSPARENT, Shader.TileMode.CLAMP));
        canvas.drawPath(hills, paint);
        paint.setShader(null);
    }

    private void drawGroundThemed(Canvas canvas, int topColor, int bottomColor, int edgeColor) {
        paint.setShader(new LinearGradient(0f, groundY, 0f, height,
                topColor, bottomColor, Shader.TileMode.CLAMP));
        canvas.drawRect(0f, groundY, width, height, paint);
        paint.setShader(null);
        paint.setColor(edgeColor);
        canvas.drawRect(0f, groundY, width, groundY + 4f, paint);
        paint.setColor(Color.argb(90, Color.red(edgeColor), Color.green(edgeColor), Color.blue(edgeColor)));
        canvas.drawRect(0f, groundY + 4f, width, groundY + 6f, paint);
        for (int i = 0; i < 42; i++) {
            float x = ((i * 157) % 983) / 983f * width;
            float y = groundY + 10f + (((i * 83) % 367) / 367f) * Math.max(20f, height - groundY - 16f);
            float rw = 4f + (i % 5) * 3f;
            paint.setColor(Color.argb(90 + (i % 3) * 25, 74, 65, 55));
            canvas.drawOval(new RectF(x, y, x + rw, y + Math.max(2f, rw * 0.38f)), paint);
        }
    }

    private void drawThemeParticles(Canvas canvas, int theme) {
        if (theme == 3) {
            paint.setColor(Color.argb(120, 224, 246, 255));
            for (int i = 0; i < 36; i++) {
                float x = ((i * 137) % 991) / 991f * width;
                float y = ((i * 89) % 647) / 647f * height;
                canvas.drawCircle(x, y, 1f + (i % 3) * 0.55f, paint);
            }
        } else if (theme == 4) {
            for (int i = 0; i < 24; i++) {
                float x = ((i * 211) % 983) / 983f * width;
                float y = height * (0.20f + (((i * 67) % 499) / 499f) * 0.58f);
                paint.setColor(Color.argb(70 + (i % 4) * 28, 255, 97, 45));
                canvas.drawCircle(x, y, 1.2f + (i % 3) * 0.6f, paint);
            }
        } else if (theme == 5 || theme == 6) {
            for (int i = 0; i < 18; i++) {
                float x = ((i * 173) % 997) / 997f * width;
                float y = height * (0.10f + (((i * 73) % 431) / 431f) * 0.55f);
                paint.setColor(Color.argb(58 + (i % 3) * 24, 188, 128, 255));
                canvas.drawCircle(x, y, 1.6f + (i % 2), paint);
            }
        }
    }

    private void drawCloudBands(Canvas canvas) {
        int theme = backgroundThemeKeyLocked();
        for (int i = 0; i < 5; i++) {
            float cx = width * (0.12f + i * 0.21f);
            float cy = height * (0.16f + (i % 3) * 0.075f);
            float cw = width * (tabletLayout ? 0.19f : 0.16f);
            float ch = height * 0.036f;
            int cr = theme == 2 ? 255 : theme == 4 ? 126 : theme >= 5 ? 151 : 155;
            int cg = theme == 2 ? 184 : theme == 4 ? 91 : theme >= 5 ? 125 : 176;
            int cb = theme == 2 ? 127 : theme == 4 ? 88 : theme >= 5 ? 190 : 204;
            paint.setColor(Color.argb(15 + i * 3, cr, cg, cb));
            canvas.drawOval(new RectF(cx - cw, cy - ch, cx + cw, cy + ch), paint);
            canvas.drawOval(new RectF(cx - cw * 0.55f, cy - ch * 1.45f,
                    cx + cw * 0.55f, cy + ch * 0.55f), paint);
        }
    }

    private void drawDistantLights(Canvas canvas) {
        int theme = backgroundThemeKeyLocked();
        for (int i = 0; i < 34; i++) {
            float x = width * (0.09f + (((i * 83) % 907) / 907f) * 0.82f);
            float y = groundY - height * (0.035f + (((i * 47) % 131) / 131f) * 0.095f);
            float r = 0.9f + (i % 3) * 0.45f;
            int lr = theme == 3 ? 173 : theme >= 5 ? 190 : 255;
            int lg = theme == 3 ? 231 : theme >= 5 ? 130 : 176;
            int lb = theme == 3 ? 255 : theme >= 5 ? 255 : 77;
            paint.setColor(Color.argb(78 + (i % 4) * 18, lr, lg, lb));
            canvas.drawCircle(x, y, r, paint);
        }
    }

    private void drawStars(Canvas canvas) {
        for (int i = 0; i < 46; i++) {
            float x = ((i * 193) % 997) / 997f * width;
            float y = (0.035f + (((i * 71) % 419) / 419f) * 0.40f) * height;
            float r = 0.7f + (i % 3) * 0.45f;
            paint.setColor(Color.argb(80 + (i % 4) * 35, 220, 233, 255));
            canvas.drawCircle(x, y, r, paint);
        }
    }

    private void drawMoon(Canvas canvas) {
        float moonX = width * 0.80f;
        float moonY = height * 0.18f;
        float radius = Math.max(32f, height * 0.085f);
        paint.setShader(new RadialGradient(moonX, moonY, radius * 1.7f,
                new int[]{Color.argb(180, 223, 232, 235), Color.argb(42, 197, 214, 228), Color.TRANSPARENT},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawCircle(moonX, moonY, radius * 1.7f, paint);
        paint.setShader(null);
        paint.setColor(Color.rgb(216, 220, 207));
        canvas.drawCircle(moonX, moonY, radius, paint);
        paint.setColor(Color.argb(34, 65, 74, 84));
        canvas.drawCircle(moonX - radius * 0.28f, moonY - radius * 0.13f, radius * 0.18f, paint);
        canvas.drawCircle(moonX + radius * 0.18f, moonY + radius * 0.25f, radius * 0.12f, paint);
        canvas.drawCircle(moonX + radius * 0.34f, moonY - radius * 0.26f, radius * 0.10f, paint);
    }

    private void drawMountainLayer(Canvas canvas, float topY, float bottomY, int color, float offset) {
        Path path = new Path();
        path.moveTo(0f, bottomY);
        path.lineTo(width * (0.08f + offset), topY + height * 0.09f);
        path.lineTo(width * (0.18f + offset), topY - height * 0.02f);
        path.lineTo(width * (0.30f + offset), topY + height * 0.12f);
        path.lineTo(width * (0.44f + offset), topY + height * 0.01f);
        path.lineTo(width * (0.58f + offset), topY + height * 0.12f);
        path.lineTo(width * (0.72f + offset), topY + height * 0.03f);
        path.lineTo(width * (0.86f + offset), topY + height * 0.10f);
        path.lineTo(width, topY + height * 0.02f);
        path.lineTo(width, bottomY);
        path.close();
        paint.setColor(color);
        canvas.drawPath(path, paint);

        paint.setColor(Color.argb(44, 208, 223, 232));
        stroke.setColor(Color.argb(38, 225, 235, 245));
        stroke.setStrokeWidth(1.5f);
        stroke.setStyle(Paint.Style.STROKE);
        canvas.drawPath(path, stroke);
    }

    private void drawHillLayer(Canvas canvas) {
        Path hills = new Path();
        hills.moveTo(0f, groundY);
        hills.cubicTo(width * 0.18f, height * 0.55f, width * 0.27f, height * 0.67f, width * 0.43f, groundY);
        hills.cubicTo(width * 0.62f, height * 0.55f, width * 0.79f, height * 0.59f, width, groundY);
        hills.close();
        paint.setColor(Color.rgb(43, 47, 47));
        canvas.drawPath(hills, paint);

        paint.setShader(new LinearGradient(0f, groundY - height * 0.15f, 0f, groundY,
                Color.argb(76, 154, 166, 168), Color.TRANSPARENT, Shader.TileMode.CLAMP));
        canvas.drawPath(hills, paint);
        paint.setShader(null);
    }

    private void drawGround(Canvas canvas) {
        paint.setShader(new LinearGradient(0f, groundY, 0f, height,
                Color.rgb(58, 50, 40), Color.rgb(25, 23, 21), Shader.TileMode.CLAMP));
        canvas.drawRect(0f, groundY, width, height, paint);
        paint.setShader(null);

        paint.setColor(Color.rgb(133, 91, 48));
        canvas.drawRect(0f, groundY, width, groundY + 4f, paint);
        paint.setColor(Color.argb(90, 235, 169, 68));
        canvas.drawRect(0f, groundY + 4f, width, groundY + 6f, paint);

        for (int i = 0; i < 42; i++) {
            float x = ((i * 157) % 983) / 983f * width;
            float y = groundY + 10f + (((i * 83) % 367) / 367f) * Math.max(20f, height - groundY - 16f);
            float rw = 4f + (i % 5) * 3f;
            paint.setColor(Color.argb(90 + (i % 3) * 25, 74, 65, 55));
            canvas.drawOval(new RectF(x, y, x + rw, y + Math.max(2f, rw * 0.38f)), paint);
        }
    }

    private void drawMenuScenery(Canvas canvas) {
        drawDistantStatue(canvas, width * 0.12f, groundY - height * 0.06f, 0.72f, BLUE, true);
        drawDistantStatue(canvas, width * 0.88f, groundY - height * 0.03f, 0.56f, RED, false);

        paint.setColor(Color.argb(56, 231, 156, 62));
        for (int i = 0; i < 16; i++) {
            float x = ((i * 149) % 887) / 887f * width;
            float y = groundY + 8f + (i % 5) * 7f;
            canvas.drawCircle(x, y, 1.3f + (i % 2), paint);
        }
    }

    private void drawDistantStatue(Canvas canvas, float x, float baseY, float scale, int accent, boolean player) {
        float dir = player ? 1f : -1f;
        paint.setColor(Color.argb(220, 30, 35, 43));
        canvas.drawRect(x - 48f * scale, baseY - 24f * scale, x + 48f * scale, baseY, paint);
        paint.setColor(Color.argb(230, 89, 95, 105));
        canvas.drawRoundRect(new RectF(x - 16f * scale, baseY - 103f * scale,
                x + 16f * scale, baseY - 25f * scale), 7f * scale, 7f * scale, paint);
        canvas.drawCircle(x, baseY - 124f * scale, 18f * scale, paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeWidth(7f * scale);
        stroke.setColor(Color.argb(230, 100, 106, 116));
        canvas.drawLine(x + dir * 10f * scale, baseY - 91f * scale,
                x + dir * 39f * scale, baseY - 146f * scale, stroke);
        stroke.setStrokeWidth(4f * scale);
        stroke.setColor(Color.argb(230, 199, 205, 215));
        canvas.drawLine(x + dir * 37f * scale, baseY - 145f * scale,
                x + dir * 56f * scale, baseY - 177f * scale, stroke);
        paint.setColor(Color.argb(205, Color.red(accent), Color.green(accent), Color.blue(accent)));
        canvas.drawOval(new RectF(x - dir * 35f * scale - 15f * scale, baseY - 84f * scale,
                x - dir * 35f * scale + 15f * scale, baseY - 44f * scale), paint);
    }

    private void drawDistantCastle(Canvas canvas, float x, float baseY, float scale, int accent) {
        float towerW = 42f * scale;
        float bodyW = 112f * scale;
        float bodyH = 98f * scale;
        paint.setColor(Color.argb(235, 23, 29, 35));
        canvas.drawRect(x - bodyW / 2f, baseY - bodyH, x + bodyW / 2f, baseY, paint);
        canvas.drawRect(x - bodyW / 2f - towerW * 0.45f, baseY - bodyH * 1.28f,
                x - bodyW / 2f + towerW * 0.55f, baseY, paint);
        canvas.drawRect(x + bodyW / 2f - towerW * 0.55f, baseY - bodyH * 1.18f,
                x + bodyW / 2f + towerW * 0.45f, baseY, paint);
        drawBattlements(canvas, x - bodyW / 2f, x + bodyW / 2f, baseY - bodyH, scale, Color.rgb(23, 29, 35));
        paint.setColor(Color.argb(180, Color.red(accent), Color.green(accent), Color.blue(accent)));
        canvas.drawRect(x - 5f * scale, baseY - bodyH * 0.58f, x + 5f * scale, baseY, paint);
        paint.setColor(Color.argb(150, 244, 166, 68));
        canvas.drawCircle(x - bodyW * 0.22f, baseY - bodyH * 0.55f, 3f * scale, paint);
        canvas.drawCircle(x + bodyW * 0.22f, baseY - bodyH * 0.55f, 3f * scale, paint);
    }

    private void drawMenu(Canvas canvas) {
        float centerX = width / 2f;
        float titleY = height * (tabletLayout ? 0.245f : 0.245f);
        drawScreenFrame(canvas, true);

        float crestSize = Math.max(34f, height * (tabletLayout ? 0.068f : 0.062f));
        drawCrest(canvas, centerX, height * 0.082f, crestSize, GOLD);

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(Math.min(tabletLayout ? 132f : 98f,
                Math.min(width * 0.082f, height * 0.14f)));
        paint.setShadowLayer(10f * uiScale, 0f, 5f * uiScale, Color.BLACK);
        paint.setColor(GOLD_LIGHT);
        canvas.drawText("UYGAR WARS", centerX, titleY, paint);
        paint.clearShadowLayer();

        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(Math.max(1.5f, 2f * uiScale));
        stroke.setColor(Color.argb(180, 226, 173, 62));
        float ornamentW = Math.min(width * 0.24f, 390f * uiScale);
        float ornamentY = titleY + 22f * uiScale;
        canvas.drawLine(centerX - ornamentW, ornamentY, centerX - 32f * uiScale, ornamentY, stroke);
        canvas.drawLine(centerX + 32f * uiScale, ornamentY, centerX + ornamentW, ornamentY, stroke);
        drawDiamondIcon(canvas, centerX, ornamentY, 11f * uiScale, GOLD_LIGHT);

        paint.setTypeface(Typeface.DEFAULT);
        paint.setColor(Color.rgb(232, 236, 242));
        paint.setTextSize(Math.max(17f, Math.min(tabletLayout ? 34f : 27f, width * 0.022f)));
        canvas.drawText("Ordunu yönet. Madene in. Uygarlığını güçlendir.", centerX, height * 0.365f, paint);

        paint.setTextSize(Math.max(11f, 14f * uiScale));
        paint.setColor(Color.rgb(177, 190, 210));
        canvas.drawText("ÇEVRİMDIŞI  •  TAKTİK SAVAŞ  •  KATMANLI ELMAS MADENİ", centerX, height * 0.407f, paint);

        float badgeW = Math.min(width * 0.52f, Math.max(300f, (tabletLayout ? 620f : 470f) * uiScale));
        float badgeH = Math.max(54f * uiScale, height * 0.072f);
        float badgeTop = height * 0.435f;
        RectF badge = new RectF(centerX - badgeW / 2f, badgeTop, centerX + badgeW / 2f, badgeTop + badgeH);
        drawPanel(canvas, badge, 18f * uiScale, true);
        drawCrown(canvas, badge.left + 34f * uiScale, badge.centerY() + 1f, 15f * uiScale, GOLD_LIGHT);
        drawDiamondIcon(canvas, badge.right - 54f * uiScale, badge.centerY(), 14f * uiScale, Color.rgb(105, 231, 255));
        paint.setTextSize(Math.max(15f, 18f * uiScale));
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setColor(Color.WHITE);
        canvas.drawText("BÖLÜM " + campaignLevel + "  •  PUAN " + upgradePoints
                        + "  •  ELMAS " + diamonds,
                badge.centerX(), badge.centerY() + paint.getTextSize() * 0.34f, paint);

        drawMainButton(canvas, startButton, "BÖLÜM " + campaignLevel + " BAŞLA", difficultyLabelLocked());
        drawButton(canvas, categoryBattleButton, "SAVAŞ", "Kampanya • Harita • Arena", true);
        drawButton(canvas, categoryProgressButton, "GELİŞİM", "Komutan • Görev • Puan", true);
        drawButton(canvas, categoryEconomyButton, "EKONOMİ", "Maden • Mağaza • Elmas", true);
        drawButton(canvas, categorySystemButton, "AYARLAR", "Sıfırla • Ses • Oyun", true);

        paint.setTypeface(Typeface.DEFAULT);
        paint.setColor(Color.argb(205, 235, 238, 242));
        paint.setTextSize(Math.max(12f, 13f * uiScale));
        canvas.drawText("Ana menü 4 başlık altında toplandı • v0.4.2", centerX, height - safePadding, paint);
    }

    private void drawHubHeader(Canvas canvas, String title, String subtitle, String meta, int accent) {
        drawScreenFrame(canvas, true);
        drawButton(canvas, backButton, "GERİ", "Ana menü", true);
        float centerX = width * 0.5f;

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(Math.max(34f * uiScale, Math.min(82f * uiScale, width * 0.058f)));
        paint.setColor(accent);
        paint.setShadowLayer(9f * uiScale, 0f, 4f * uiScale, Color.BLACK);
        canvas.drawText(title, centerX, height * 0.15f, paint);
        paint.clearShadowLayer();

        paint.setTypeface(Typeface.DEFAULT);
        paint.setColor(Color.rgb(226, 231, 240));
        paint.setTextSize(Math.max(15f, 18f * uiScale));
        canvas.drawText(subtitle, centerX, height * 0.215f, paint);

        RectF metaPanel = new RectF(width * 0.5f - Math.min(width * 0.28f, 320f * uiScale), height * 0.245f,
                width * 0.5f + Math.min(width * 0.28f, 320f * uiScale), height * 0.245f + Math.max(44f * uiScale, height * 0.06f));
        drawPanel(canvas, metaPanel, 16f * uiScale, true);
        paint.setColor(Color.WHITE);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(13f, 15f * uiScale));
        canvas.drawText(meta, metaPanel.centerX(), metaPanel.centerY() + paint.getTextSize() * 0.32f, paint);
    }

    private void drawBattleHub(Canvas canvas) {
        drawHubHeader(canvas, "SAVAŞ", "Kampanyaya gir, haritadan bölüm seç veya Arena'ya geç.",
                "Bölüm " + campaignLevel + " • Arena Rekoru " + arenaBestWave, GOLD_LIGHT);
        drawMainButton(canvas, hubPrimaryButton, "HIZLI BAŞLA", "Mevcut bölüm • " + difficultyLabelLocked());
        drawButton(canvas, hubSecondaryButton, "HARİTA", "Yıldızlar ve boss savaşları", true);
        drawButton(canvas, hubTertiaryButton, "ARENA", "Rekor " + arenaBestWave + " • sonsuz dalga", true);
    }

    private void drawProgressHub(Canvas canvas) {
        drawHubHeader(canvas, "GELİŞİM", "Komutanını büyüt, puanlarını harca ve ödüllerini topla.",
                "Komutan Sv " + heroLevel + " • Puan " + upgradePoints, GOLD_LIGHT);
        drawMainButton(canvas, hubPrimaryButton, "KOMUTAN", heroUnlockedLocked() ? "Liderlik ve aura" : "Bölüm 4'te açılır");
        drawButton(canvas, hubSecondaryButton, "GELİŞTİR", "Birlik ve heykel puan sistemi", true);
        drawButton(canvas, hubTertiaryButton, "GÖREVLER",
                missionRewardReadyLocked() ? "ÖDÜL HAZIR" : "Profil, sandık ve başarımlar", true);
    }

    private void drawEconomyHub(Canvas canvas) {
        drawHubHeader(canvas, "EKONOMİ", "Maden kaz, elmas topla ve mağazada görünüm/güç aç.",
                "Elmas " + diamonds + " • Maden Katman " + (mineDepth + 1), Color.rgb(105, 231, 255));
        drawMainButton(canvas, hubPrimaryButton, "MADEN", "Katman " + (mineDepth + 1) + " • Elmas madeni");
        drawButton(canvas, hubSecondaryButton, "KIYAFET MAĞAZASI", "Görünüm ve birlik kartları", true);
        drawButton(canvas, hubTertiaryButton, "ELMAS GÜÇLERİ", "Kalıcı güçlendirmeler", true);
    }

    private void drawSystemHub(Canvas canvas) {
        drawHubHeader(canvas, "AYARLAR", "Oyun ayarları ve kayıt yönetimini burada toparladım.",
                "Sürüm v0.2.8 • Kayıt yönetimi tek yerde", GOLD_LIGHT);
        drawMainButton(canvas, hubPrimaryButton, "OYUN AYARLARI", "Ses, sıfırlama ve oyun seçenekleri");
        drawButton(canvas, hubSecondaryButton, "KAYIT / SIFIRLAMA", "Bölüm ve tüm ilerleme sıfırla", true);
        drawButton(canvas, hubTertiaryButton, "SÜRÜM BİLGİSİ", "Bu yapıyı sadeleştirilmiş ana menü kullanır", true);
    }

    private void drawArenaScreen(Canvas canvas) {
        drawScreenFrame(canvas, true);
        drawButton(canvas, backButton, "GERİ", "Ana menü", true);

        float centerX = width * 0.5f;
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(Math.max(34f * uiScale, Math.min(78f * uiScale, width * 0.056f)));
        paint.setColor(Color.rgb(206, 165, 255));
        paint.setShadowLayer(10f * uiScale, 0f, 5f * uiScale, Color.BLACK);
        canvas.drawText("SONSUZ ARENA", centerX, height * 0.14f, paint);
        paint.clearShadowLayer();

        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(Math.max(15f, 19f * uiScale));
        paint.setColor(Color.rgb(220, 226, 238));
        canvas.drawText("Heykelini koru, dalgaları aş ve kendi rekorunu kır.", centerX, height * 0.205f, paint);

        float panelW = Math.min(width * 0.80f, tabletLayout ? 1120f * uiScale : 850f * uiScale);
        float panelH = Math.max(270f * uiScale, height * 0.43f);
        RectF panel = new RectF(centerX - panelW * 0.5f, height * 0.27f,
                centerX + panelW * 0.5f, height * 0.27f + panelH);
        drawPanel(canvas, panel, 24f * uiScale, true);

        float third = panel.width() / 3f;
        drawArenaStat(canvas, panel.left + third * 0.5f, panel.top + panel.height() * 0.34f,
                "EN YÜKSEK DALGA", Integer.toString(arenaBestWave), Color.rgb(206, 165, 255));
        drawArenaStat(canvas, panel.left + third * 1.5f, panel.top + panel.height() * 0.34f,
                "EN FAZLA YENİLEN", Integer.toString(arenaBestKills), Color.rgb(255, 126, 103));
        drawArenaStat(canvas, panel.left + third * 2.5f, panel.top + panel.height() * 0.34f,
                "ARENA KOŞUSU", Integer.toString(arenaRuns), Color.rgb(105, 231, 255));

        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(16f, 19f * uiScale));
        paint.setColor(GOLD_LIGHT);
        canvas.drawText("ÖDÜL DÜZENİ", centerX, panel.top + panel.height() * 0.66f, paint);
        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(Math.max(13f, 16f * uiScale));
        paint.setColor(Color.rgb(205, 214, 228));
        canvas.drawText("Her 3 dalgada +1 elmas  •  Her 5 dalgada arena şampiyonu",
                centerX, panel.top + panel.height() * 0.77f, paint);
        canvas.drawText("10. dalgadan sonra koşu sonu bonus elması ve profil XP'si",
                centerX, panel.top + panel.height() * 0.87f, paint);

        drawMainButton(canvas, arenaStartButton, "ARENA BAŞLAT",
                "Sonsuz dalga • Zorluk sürekli artar");
    }

    private void drawArenaStat(Canvas canvas, float x, float y, String title, String value, int accent) {
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(13f, 16f * uiScale));
        paint.setColor(Color.rgb(185, 196, 214));
        canvas.drawText(title, x, y - 18f * uiScale, paint);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(Math.max(38f, 56f * uiScale));
        paint.setColor(accent);
        paint.setShadowLayer(7f * uiScale, 0f, 3f * uiScale, Color.BLACK);
        canvas.drawText(value, x, y + 45f * uiScale, paint);
        paint.clearShadowLayer();
    }

    private void drawHeroScreen(Canvas canvas) {
        drawScreenFrame(canvas, true);
        drawButton(canvas, backButton, "GERİ", "Ana menü", true);
        float centerX = width * 0.5f;

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(Math.max(32f * uiScale, Math.min(72f * uiScale, width * 0.050f)));
        paint.setColor(GOLD_LIGHT);
        canvas.drawText("UYGAR KOMUTANI", centerX, height * 0.12f, paint);

        if (!heroUnlockedLocked()) {
            RectF locked = new RectF(width * 0.20f, height * 0.28f, width * 0.80f, height * 0.72f);
            drawPanel(canvas, locked, 22f * uiScale, false);
            drawShield(canvas, centerX, locked.top + locked.height() * 0.28f, 58f * uiScale, GOLD);
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            paint.setTextSize(Math.max(25f * uiScale, 38f * uiScale));
            paint.setColor(Color.WHITE);
            canvas.drawText("KOMUTAN KİLİTLİ", centerX, locked.centerY(), paint);
            paint.setTypeface(Typeface.DEFAULT);
            paint.setTextSize(Math.max(17f * uiScale, 22f * uiScale));
            paint.setColor(Color.rgb(190, 202, 220));
            canvas.drawText("Bölüm 4'e ulaşınca komutan orduna katılır.",
                    centerX, locked.centerY() + 46f * uiScale, paint);
            return;
        }

        RectF profile = new RectF(width * 0.12f, height * 0.18f, width * 0.88f, height * 0.46f);
        drawPanel(canvas, profile, 22f * uiScale, true);
        float portraitX = profile.left + profile.width() * 0.18f;
        float portraitY = profile.bottom - 28f * uiScale;
        drawHeroPortrait(canvas, portraitX, portraitY, Math.max(1.15f, uiScale * 1.25f));

        paint.setTextAlign(Paint.Align.LEFT);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(24f * uiScale, 34f * uiScale));
        paint.setColor(Color.WHITE);
        canvas.drawText("ALTIN MUHAFIZ", profile.left + profile.width() * 0.35f, profile.top + 58f * uiScale, paint);
        paint.setTextSize(Math.max(17f * uiScale, 22f * uiScale));
        paint.setColor(GOLD_LIGHT);
        canvas.drawText("KOMUTAN SEVİYESİ " + heroLevel,
                profile.left + profile.width() * 0.35f, profile.top + 94f * uiScale, paint);

        float xpRatio = heroLevel >= 15 ? 1f : heroXp / (float) Math.max(1, heroXpNeededLocked());
        float barLeft = profile.left + profile.width() * 0.35f;
        float barTop = profile.top + 118f * uiScale;
        float barWidth = profile.width() * 0.52f;
        drawHealthBar(canvas, barLeft, barTop, barWidth, xpRatio, Color.rgb(116, 204, 255), true);
        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(Math.max(14f * uiScale, 17f * uiScale));
        paint.setColor(Color.rgb(205, 216, 231));
        canvas.drawText(heroLevel >= 15 ? "AZAMİ SEVİYE" : heroXp + " / " + heroXpNeededLocked() + " KOMUTAN XP",
                barLeft, barTop + 34f * uiScale, paint);

        paint.setTextSize(Math.max(14f * uiScale, 18f * uiScale));
        paint.setColor(Color.WHITE);
        canvas.drawText("CAN: " + Math.round((390f + heroLevel * 46f) * (1f + heroArmorLevel * 0.12f))
                        + "   •   HASAR: " + Math.round((58f + heroLevel * 6.2f) * (1f + heroPowerLevel * 0.10f))
                        + "   •   ELMAS: " + diamonds,
                barLeft, profile.bottom - 26f * uiScale, paint);

        drawHeroTraitCard(canvas, heroPowerButton, "SAVAŞ USTALIĞI", heroPowerLevel,
                "+%10 komutan hasarı / seviye", Color.rgb(255, 109, 79));
        drawHeroTraitCard(canvas, heroArmorButton, "ZIRH USTALIĞI", heroArmorLevel,
                "+%12 komutan canı / seviye", Color.rgb(105, 190, 255));
        drawHeroTraitCard(canvas, heroLeadershipButton, "LİDERLİK AURASI", heroLeadershipLevel,
                "Yakın birliklere hasar ve hız", Color.rgb(255, 205, 91));
    }

    private void drawHeroTraitCard(Canvas canvas, RectF rect, String title, int level,
                                   String description, int accent) {
        drawPanel(canvas, rect, 18f * uiScale, level < 5);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(17f * uiScale, 22f * uiScale));
        paint.setColor(accent);
        canvas.drawText(title, rect.centerX(), rect.top + 42f * uiScale, paint);
        drawShield(canvas, rect.centerX(), rect.top + rect.height() * 0.39f, 28f * uiScale, accent);
        paint.setTextSize(Math.max(14f * uiScale, 18f * uiScale));
        paint.setColor(Color.WHITE);
        canvas.drawText("SEVİYE " + level + " / 5", rect.centerX(), rect.top + rect.height() * 0.62f, paint);
        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(Math.max(11f * uiScale, 14f * uiScale));
        paint.setColor(Color.rgb(190, 202, 220));
        canvas.drawText(description, rect.centerX(), rect.top + rect.height() * 0.75f, paint);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(13f * uiScale, 16f * uiScale));
        paint.setColor(level >= 5 ? GOLD_LIGHT : Color.rgb(115, 230, 255));
        canvas.drawText(level >= 5 ? "AZAMİ SEVİYE"
                        : "GELİŞTİR • " + heroTraitCostLocked(level) + " ELMAS",
                rect.centerX(), rect.bottom - 22f * uiScale, paint);
    }

    private void drawHeroPortrait(Canvas canvas, float x, float y, float scale) {
        paint.setColor(Color.argb(65, 255, 196, 76));
        canvas.drawCircle(x, y - 75f * scale, 58f * scale, paint);
        paint.setColor(Color.rgb(38, 48, 69));
        Path cape = new Path();
        cape.moveTo(x - 13f * scale, y - 78f * scale);
        cape.lineTo(x - 48f * scale, y - 5f * scale);
        cape.lineTo(x + 32f * scale, y - 12f * scale);
        cape.close();
        canvas.drawPath(cape, paint);
        paint.setColor(Color.rgb(70, 82, 105));
        canvas.drawRoundRect(new RectF(x - 22f * scale, y - 88f * scale,
                x + 22f * scale, y - 18f * scale), 10f * scale, 10f * scale, paint);
        paint.setColor(GOLD);
        canvas.drawRect(x - 22f * scale, y - 66f * scale, x + 22f * scale, y - 51f * scale, paint);
        paint.setColor(Color.rgb(183, 191, 204));
        canvas.drawCircle(x, y - 111f * scale, 23f * scale, paint);
        paint.setColor(Color.rgb(53, 61, 76));
        canvas.drawArc(new RectF(x - 28f * scale, y - 138f * scale,
                x + 28f * scale, y - 98f * scale), 180f, 180f, true, paint);
        drawCrown(canvas, x, y - 143f * scale, 14f * scale, GOLD_LIGHT);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeWidth(7f * scale);
        stroke.setColor(Color.rgb(44, 50, 62));
        canvas.drawLine(x - 8f * scale, y - 20f * scale, x - 24f * scale, y, stroke);
        canvas.drawLine(x + 8f * scale, y - 20f * scale, x + 24f * scale, y, stroke);
        stroke.setColor(Color.rgb(229, 232, 238));
        stroke.setStrokeWidth(5f * scale);
        canvas.drawLine(x + 16f * scale, y - 62f * scale, x + 61f * scale, y - 124f * scale, stroke);
        paint.setColor(BLUE);
        RectF shield = new RectF(x - 58f * scale, y - 81f * scale, x - 20f * scale, y - 26f * scale);
        canvas.drawOval(shield, paint);
        stroke.setColor(GOLD_LIGHT);
        stroke.setStrokeWidth(3f * scale);
        canvas.drawOval(shield, stroke);
    }

    private int currentDailyDayKeyLocked() {
        Calendar calendar = Calendar.getInstance();
        return calendar.get(Calendar.YEAR) * 1000 + calendar.get(Calendar.DAY_OF_YEAR);
    }

    private void ensureDailyMissionsLocked() {
        int currentKey = currentDailyDayKeyLocked();
        if (dailyDayKey == currentKey) return;
        dailyDayKey = currentKey;
        dailyWins = 0;
        dailyMineLayers = 0;
        dailyKills = 0;
        dailyWinClaimed = false;
        dailyMineClaimed = false;
        dailyKillClaimed = false;
        dailyChestClaimed = false;
        saveProgressLocked();
        invalidateMenuCacheLocked();
    }

    private int profileLevelLocked() {
        return 1 + Math.max(0, (int) Math.floor(Math.sqrt(profileXp / 70f)));
    }

    private int profileLevelStartXpLocked(int level) {
        int base = Math.max(0, level - 1);
        return base * base * 70;
    }

    private String profileRankLocked() {
        int level = profileLevelLocked();
        if (level >= 16) return "EFSANE";
        if (level >= 11) return "GENERAL";
        if (level >= 7) return "KOMUTAN";
        if (level >= 3) return "SAVAŞÇI";
        return "ACEMİ";
    }

    private boolean allDailyMissionsClaimedLocked() {
        return dailyWinClaimed && dailyMineClaimed && dailyKillClaimed;
    }

    private boolean missionRewardReadyLocked() {
        ensureDailyMissionsLocked();
        return (!dailyWinClaimed && dailyWins >= 1)
                || (!dailyMineClaimed && dailyMineLayers >= 2)
                || (!dailyKillClaimed && dailyKills >= 20)
                || (!dailyChestClaimed && allDailyMissionsClaimedLocked())
                || battleChestProgress >= 3
                || anyAchievementReadyLocked();
    }

    private void claimDailyMissionLocked(int type) {
        ensureDailyMissionsLocked();
        boolean complete;
        boolean claimed;
        if (type == 0) {
            complete = dailyWins >= 1;
            claimed = dailyWinClaimed;
        } else if (type == 1) {
            complete = dailyMineLayers >= 2;
            claimed = dailyMineClaimed;
        } else {
            complete = dailyKills >= 20;
            claimed = dailyKillClaimed;
        }
        if (claimed) {
            showToastLocked("BU GÖREV ÖDÜLÜ ALINDI");
            return;
        }
        if (!complete) {
            showToastLocked("GÖREV HENÜZ TAMAMLANMADI");
            return;
        }
        if (type == 0) dailyWinClaimed = true;
        else if (type == 1) dailyMineClaimed = true;
        else dailyKillClaimed = true;
        diamonds += 2;
        profileXp += 12;
        saveProgressLocked();
        invalidateMenuCacheLocked();
        showToastLocked("GÜNLÜK GÖREV • +2 ELMAS");
    }

    private void claimDailyChestLocked() {
        ensureDailyMissionsLocked();
        if (dailyChestClaimed) {
            showToastLocked("GÜNLÜK SANDIK ALINDI");
            return;
        }
        if (!allDailyMissionsClaimedLocked()) {
            showToastLocked("ÖNCE ÜÇ GÖREV ÖDÜLÜNÜ AL");
            return;
        }
        dailyChestClaimed = true;
        diamonds += 5;
        upgradePoints += 1;
        profileXp += 28;
        saveProgressLocked();
        invalidateMenuCacheLocked();
        showToastLocked("GÜNLÜK SANDIK • +5 ELMAS • +1 PUAN");
    }

    private void claimBattleChestLocked() {
        if (battleChestProgress < 3) {
            showToastLocked("SANDIK İÇİN 3 SAVAŞ KAZAN");
            return;
        }
        battleChestProgress = 0;
        battleChestsOpened++;
        int reward = 3 + random.nextInt(3);
        diamonds += reward;
        profileXp += 22;
        boolean pointReward = battleChestsOpened % 3 == 0;
        if (pointReward) upgradePoints += 1;
        saveProgressLocked();
        invalidateMenuCacheLocked();
        showToastLocked(pointReward
                ? "SAVAŞ SANDIĞI • +" + reward + " ELMAS • +1 PUAN"
                : "SAVAŞ SANDIĞI • +" + reward + " ELMAS");
    }

    private boolean achievementCompleteLocked(int index) {
        if (index == 0) return lifetimeWins >= 1;
        if (index == 1) return lifetimeWins >= 10;
        if (index == 2) return lifetimeMineLayers >= 25;
        if (index == 3) return bossesDefeated >= 5;
        return lifetimeKills >= 100;
    }

    private boolean anyAchievementReadyLocked() {
        for (int index = 0; index < achievementClaimed.length; index++) {
            if (!achievementClaimed[index] && achievementCompleteLocked(index)) return true;
        }
        return false;
    }

    private String achievementTitleLocked(int index) {
        if (index == 0) return "İLK ZAFER";
        if (index == 1) return "TECRÜBELİ KOMUTAN";
        if (index == 2) return "DERİN KAZICI";
        if (index == 3) return "BOSS AVCISI";
        return "ORDU BOZGUNU";
    }

    private String achievementProgressLocked(int index) {
        if (index == 0) return Math.min(1, lifetimeWins) + " / 1 zafer";
        if (index == 1) return Math.min(10, lifetimeWins) + " / 10 zafer";
        if (index == 2) return Math.min(25, lifetimeMineLayers) + " / 25 katman";
        if (index == 3) return Math.min(5, bossesDefeated) + " / 5 boss";
        return Math.min(100, lifetimeKills) + " / 100 düşman";
    }

    private String achievementRewardLocked(int index) {
        if (index == 0) return "+2 elmas";
        if (index == 1) return "+8 elmas";
        if (index == 2) return "+5 elmas • +1 puan";
        if (index == 3) return "+10 elmas • +2 puan";
        return "+8 elmas • +1 puan";
    }

    private void claimAchievementLocked(int index) {
        if (index < 0 || index >= achievementClaimed.length) return;
        if (achievementClaimed[index]) {
            showToastLocked("BAŞARIM ÖDÜLÜ ALINDI");
            return;
        }
        if (!achievementCompleteLocked(index)) {
            showToastLocked("BAŞARIM HENÜZ TAMAMLANMADI");
            return;
        }
        achievementClaimed[index] = true;
        if (index == 0) diamonds += 2;
        else if (index == 1) diamonds += 8;
        else if (index == 2) {
            diamonds += 5;
            upgradePoints += 1;
        } else if (index == 3) {
            diamonds += 10;
            upgradePoints += 2;
        } else {
            diamonds += 8;
            upgradePoints += 1;
        }
        profileXp += 35;
        saveProgressLocked();
        invalidateMenuCacheLocked();
        showToastLocked("BAŞARIM ÖDÜLÜ ALINDI");
    }

    private void drawMissionsScreen(Canvas canvas) {
        ensureDailyMissionsLocked();
        drawScreenFrame(canvas, true);
        drawButton(canvas, backButton, "‹ ANA MENÜ", "İlerleme kaydedilir", true);

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(Math.min(tabletLayout ? 74f : 56f, width * 0.052f));
        paint.setColor(GOLD_LIGHT);
        paint.setShadowLayer(8f, 0f, 4f, Color.BLACK);
        canvas.drawText("KOMUTA MERKEZİ", width * 0.5f, height * 0.125f, paint);
        paint.clearShadowLayer();

        int level = profileLevelLocked();
        int levelStart = profileLevelStartXpLocked(level);
        int levelEnd = profileLevelStartXpLocked(level + 1);
        float profileRatio = (profileXp - levelStart) / (float) Math.max(1, levelEnd - levelStart);
        float profileW = Math.min(width * 0.66f, 900f * uiScale);
        RectF profile = new RectF(width * 0.5f - profileW * 0.5f, height * 0.145f,
                width * 0.5f + profileW * 0.5f, height * 0.195f);
        drawPanel(canvas, profile, 14f * uiScale, true);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(13f, 17f * uiScale));
        paint.setColor(Color.WHITE);
        canvas.drawText(profileRankLocked() + " • SEVİYE " + level + " • " + profileXp + " XP",
                profile.centerX(), profile.top + profile.height() * 0.44f, paint);
        float barLeft = profile.left + 28f * uiScale;
        float barRight = profile.right - 28f * uiScale;
        float barY = profile.bottom - 11f * uiScale;
        paint.setColor(Color.rgb(35, 45, 61));
        canvas.drawRoundRect(new RectF(barLeft, barY - 4f * uiScale, barRight, barY + 4f * uiScale),
                4f * uiScale, 4f * uiScale, paint);
        paint.setColor(GOLD_LIGHT);
        canvas.drawRoundRect(new RectF(barLeft, barY - 4f * uiScale,
                barLeft + (barRight - barLeft) * Math.max(0f, Math.min(1f, profileRatio)), barY + 4f * uiScale),
                4f * uiScale, 4f * uiScale, paint);

        drawButton(canvas, missionDailyTabButton, "GÜNLÜK GÖREVLER", "Her gün yenilenir", !missionsAchievementsPage);
        drawButton(canvas, missionAchievementTabButton, "BAŞARIMLAR", "Kalıcı hedefler", missionsAchievementsPage);

        if (!missionsAchievementsPage) drawDailyMissionsLocked(canvas);
        else drawAchievementsLocked(canvas);
    }

    private void drawDailyMissionsLocked(Canvas canvas) {
        drawMissionCardLocked(canvas, dailyWinButton, "ZAFER KAZAN", "1 savaş kazan",
                dailyWins, 1, dailyWinClaimed, "+2 elmas");
        drawMissionCardLocked(canvas, dailyMineButton, "MADENE İN", "2 katman tamamla",
                dailyMineLayers, 2, dailyMineClaimed, "+2 elmas");
        drawMissionCardLocked(canvas, dailyKillButton, "ORDUYU DURDUR", "20 düşman yen",
                dailyKills, 20, dailyKillClaimed, "+2 elmas");

        boolean dailyReady = allDailyMissionsClaimedLocked() && !dailyChestClaimed;
        drawButton(canvas, dailyChestButton,
                dailyChestClaimed ? "GÜNLÜK SANDIK ALINDI" : "GÜNLÜK SANDIK",
                dailyReady ? "+5 elmas • +1 geliştirme puanı" : "Üç görev ödülünü tamamla",
                dailyReady || dailyChestClaimed);
        drawButton(canvas, battleChestButton,
                battleChestProgress >= 3 ? "SAVAŞ SANDIĞINI AÇ" : "SAVAŞ SANDIĞI " + battleChestProgress + "/3",
                "Her 3 zaferde 3–5 elmas", battleChestProgress >= 3);
    }

    private void drawMissionCardLocked(Canvas canvas, RectF rect, String title, String detail,
                                       int progress, int target, boolean claimed, String reward) {
        boolean complete = progress >= target;
        drawPanel(canvas, rect, 16f * uiScale, complete || claimed);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(16f, rect.height() * 0.16f));
        paint.setColor(claimed ? Color.rgb(141, 222, 162) : complete ? GOLD_LIGHT : Color.WHITE);
        canvas.drawText(title, rect.centerX(), rect.top + rect.height() * 0.27f, paint);
        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(Math.max(11f, rect.height() * 0.11f));
        paint.setColor(Color.rgb(205, 214, 228));
        canvas.drawText(detail, rect.centerX(), rect.top + rect.height() * 0.43f, paint);
        float ratio = Math.max(0f, Math.min(1f, progress / (float) target));
        float barLeft = rect.left + rect.width() * 0.12f;
        float barRight = rect.right - rect.width() * 0.12f;
        float barY = rect.top + rect.height() * 0.58f;
        paint.setColor(Color.rgb(38, 47, 62));
        canvas.drawRoundRect(new RectF(barLeft, barY - 6f * uiScale, barRight, barY + 6f * uiScale),
                6f * uiScale, 6f * uiScale, paint);
        paint.setColor(complete ? Color.rgb(80, 190, 119) : GOLD);
        canvas.drawRoundRect(new RectF(barLeft, barY - 6f * uiScale,
                barLeft + (barRight - barLeft) * ratio, barY + 6f * uiScale),
                6f * uiScale, 6f * uiScale, paint);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(12f, rect.height() * 0.115f));
        paint.setColor(Color.WHITE);
        canvas.drawText(Math.min(progress, target) + " / " + target, rect.centerX(), rect.top + rect.height() * 0.72f, paint);
        paint.setTextSize(Math.max(11f, rect.height() * 0.10f));
        paint.setColor(claimed ? Color.rgb(141, 222, 162) : complete ? GOLD_LIGHT : Color.GRAY);
        canvas.drawText(claimed ? "ALINDI" : complete ? "DOKUN VE AL • " + reward : reward,
                rect.centerX(), rect.top + rect.height() * 0.88f, paint);
    }

    private void drawAchievementsLocked(Canvas canvas) {
        for (int index = 0; index < achievementButtons.length; index++) {
            RectF rect = achievementButtons[index];
            boolean complete = achievementCompleteLocked(index);
            boolean claimed = achievementClaimed[index];
            drawPanel(canvas, rect, 15f * uiScale, complete || claimed);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            paint.setTextSize(Math.max(14f, rect.height() * 0.16f));
            paint.setColor(claimed ? Color.rgb(141, 222, 162) : complete ? GOLD_LIGHT : Color.WHITE);
            canvas.drawText(achievementTitleLocked(index), rect.centerX(), rect.top + rect.height() * 0.28f, paint);
            paint.setTypeface(Typeface.DEFAULT);
            paint.setTextSize(Math.max(10f, rect.height() * 0.12f));
            paint.setColor(Color.rgb(207, 216, 229));
            canvas.drawText(achievementProgressLocked(index), rect.centerX(), rect.top + rect.height() * 0.50f, paint);
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            paint.setTextSize(Math.max(10f, rect.height() * 0.11f));
            paint.setColor(GOLD_LIGHT);
            canvas.drawText(achievementRewardLocked(index), rect.centerX(), rect.top + rect.height() * 0.68f, paint);
            paint.setColor(claimed ? Color.rgb(141, 222, 162) : complete ? Color.WHITE : Color.GRAY);
            canvas.drawText(claimed ? "ALINDI" : complete ? "DOKUN VE AL" : "DEVAM ET",
                    rect.centerX(), rect.top + rect.height() * 0.86f, paint);
        }
    }

    private void drawCampaignMap(Canvas canvas) {
        // v0.3.3: Krallık rotası, düğüm amblemleri ve profesyonel seçim paneli.
        drawScreenFrame(canvas, false);
        drawButton(canvas, backButton, "‹  GERİ", "Ana menü", true);

        float centerX = width * 0.5f;
        int pageStart = mapPage * 10 + 1;
        int pageEnd = Math.min(50, pageStart + 9);
        int chapter = mapPage + 1;
        int maxMapPage = Math.max(0, Math.min(4, (campaignLevel - 1) / 10));
        int chapterAccent = mapChapterAccentLocked(chapter);

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(Math.max(30f * uiScale, Math.min(54f * uiScale, height * 0.068f)));
        paint.setColor(GOLD_LIGHT);
        paint.setShadowLayer(8f * uiScale, 0f, 4f * uiScale, Color.BLACK);
        canvas.drawText("UYGARLIK SEFERİ", centerX, height * 0.090f, paint);
        paint.clearShadowLayer();

        float headerLeft = mapPrevButton.right + 18f * uiScale;
        float headerRight = mapNextButton.left - 18f * uiScale;
        RectF chapterHeader = new RectF(headerLeft, height * 0.138f,
                headerRight, height * 0.265f);
        drawPanel(canvas, chapterHeader, 20f * uiScale, true);
        paint.setShader(new LinearGradient(chapterHeader.left, chapterHeader.top,
                chapterHeader.right, chapterHeader.bottom,
                Color.argb(60, Color.red(chapterAccent), Color.green(chapterAccent), Color.blue(chapterAccent)),
                Color.TRANSPARENT, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(new RectF(chapterHeader.left + 3f * uiScale, chapterHeader.top + 3f * uiScale,
                chapterHeader.right - 3f * uiScale, chapterHeader.bottom - 3f * uiScale),
                17f * uiScale, 17f * uiScale, paint);
        paint.setShader(null);

        drawButton(canvas, mapPrevButton, "‹  ÖNCEKİ",
                mapPage > 0 ? chapterNameLocked(chapter - 1) : "İlk krallık", mapPage > 0);
        drawButton(canvas, mapNextButton, "SONRAKİ  ›",
                mapPage < maxMapPage ? chapterNameLocked(chapter + 1) : "Kilitli", mapPage < maxMapPage);

        drawMapChapterEmblem(canvas, chapterHeader.left + 48f * uiScale,
                chapterHeader.centerY(), 24f * uiScale, chapter, chapterAccent);

        paint.setTextAlign(Paint.Align.LEFT);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        float titleSize = fitTextSize(chapterNameLocked(chapter) + " • " + chapterFactionLocked(chapter),
                Math.max(18f, 25f * uiScale), Math.max(14f, 16f * uiScale),
                chapterHeader.width() * 0.68f);
        paint.setTextSize(titleSize);
        paint.setColor(Color.WHITE);
        canvas.drawText(chapterNameLocked(chapter) + " • " + chapterFactionLocked(chapter),
                chapterHeader.left + 88f * uiScale, chapterHeader.top + chapterHeader.height() * 0.40f, paint);

        int chapterStars = 0;
        int completedCount = 0;
        for (int level = pageStart; level <= pageEnd; level++) {
            chapterStars += levelStars[level];
            if (level < campaignLevel || levelStars[level] > 0) completedCount++;
        }
        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(Math.max(12f, 15f * uiScale));
        paint.setColor(Color.rgb(199, 210, 226));
        canvas.drawText("Bölümler " + pageStart + "–" + pageEnd + " • " + chapterEffectLocked(chapter),
                chapterHeader.left + 88f * uiScale, chapterHeader.top + chapterHeader.height() * 0.70f, paint);

        paint.setTextAlign(Paint.Align.RIGHT);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(12f, 15f * uiScale));
        paint.setColor(chapterAccent);
        canvas.drawText(completedCount + "/10 TAMAMLANDI • " + chapterStars + "/30 YILDIZ",
                chapterHeader.right - 24f * uiScale, chapterHeader.top + chapterHeader.height() * 0.54f, paint);

        // Önce sefer yolunu, sonra düğümleri çiz.
        for (int index = 1; index < mapLevelButtons.length; index++) {
            int level = pageStart + index;
            boolean unlocked = level <= campaignLevel;
            drawMapRouteConnection(canvas, mapLevelButtons[index - 1], mapLevelButtons[index], unlocked, chapterAccent);
        }

        for (int index = 0; index < mapLevelButtons.length; index++) {
            int level = pageStart + index;
            if (level > 50) continue;
            RectF node = mapLevelButtons[index];
            boolean unlocked = level <= campaignLevel;
            boolean completed = level < campaignLevel || levelStars[level] > 0;
            boolean selected = level == mapSelectedLevel;
            boolean boss = level % 5 == 0;
            drawMapLevelNode(canvas, node, level, unlocked, completed, selected, boss,
                    levelStars[level], chapterAccent);
        }

        RectF detail = new RectF(safePadding + 24f * uiScale, height * 0.700f,
                width - safePadding - 24f * uiScale, height - safePadding - 8f * uiScale);
        drawPanel(canvas, detail, 22f * uiScale, true);

        int selectedChapter = chapterForLevelLocked(mapSelectedLevel);
        int selectedAccent = mapChapterAccentLocked(selectedChapter);
        boolean selectedBoss = mapSelectedLevel % 5 == 0;
        int selectedStars = levelStars[mapSelectedLevel];
        float infoRight = mapStartButton.left - 28f * uiScale;

        paint.setShader(new LinearGradient(detail.left, detail.top, infoRight, detail.bottom,
                Color.argb(44, Color.red(selectedAccent), Color.green(selectedAccent), Color.blue(selectedAccent)),
                Color.TRANSPARENT, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(new RectF(detail.left + 3f * uiScale, detail.top + 3f * uiScale,
                infoRight, detail.bottom - 3f * uiScale), 18f * uiScale, 18f * uiScale, paint);
        paint.setShader(null);

        drawMapChapterEmblem(canvas, detail.left + 56f * uiScale, detail.centerY(),
                27f * uiScale, selectedChapter, selectedAccent);

        paint.setTextAlign(Paint.Align.LEFT);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(Math.max(22f, 29f * uiScale));
        paint.setColor(selectedBoss ? Color.rgb(255, 132, 102) : GOLD_LIGHT);
        canvas.drawText(selectedBoss ? "BOSS KALESİ • BÖLÜM " + mapSelectedLevel
                        : "SEFER NOKTASI • BÖLÜM " + mapSelectedLevel,
                detail.left + 102f * uiScale, detail.top + detail.height() * 0.30f, paint);

        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(13f, 17f * uiScale));
        paint.setColor(Color.WHITE);
        canvas.drawText(chapterNameLocked(selectedChapter) + " • " + chapterFactionLocked(selectedChapter),
                detail.left + 102f * uiScale, detail.top + detail.height() * 0.50f, paint);

        String difficulty = mapSelectedLevel <= 2 ? "KOLAY"
                : mapSelectedLevel <= 5 ? "ORTA"
                : mapSelectedLevel <= 8 ? "ZOR" : "EFSANE";
        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(Math.max(11f, 14f * uiScale));
        paint.setColor(Color.rgb(194, 207, 225));
        canvas.drawText("Zorluk " + difficulty + " • Yıldız " + selectedStars + "/3"
                        + (selectedBoss ? " • Büyük boss ödülü" : " • Bölge bonusu aktif"),
                detail.left + 102f * uiScale, detail.top + detail.height() * 0.69f, paint);
        canvas.drawText(chapterEffectLocked(selectedChapter),
                detail.left + 102f * uiScale, detail.top + detail.height() * 0.86f, paint);

        String subtitle = selectedBoss ? "Boss kalesine saldır • büyük ödül"
                : mapSelectedLevel < campaignLevel ? "Tekrar oyna • yıldızını yükselt"
                : "Yeni sefer noktasına ilerle";
        drawMainButton(canvas, mapStartButton, "BÖLÜM " + mapSelectedLevel + " BAŞLA", subtitle);
    }

    private int mapChapterAccentLocked(int chapter) {
        if (chapter == 2) return Color.rgb(244, 126, 68);
        if (chapter == 3) return Color.rgb(142, 224, 255);
        if (chapter == 4) return Color.rgb(255, 103, 55);
        if (chapter == 5) return Color.rgb(190, 126, 255);
        return GOLD_LIGHT;
    }

    private void drawMapRouteConnection(Canvas canvas, RectF from, RectF to,
                                        boolean unlocked, int accent) {
        float x1 = from.centerX();
        float y1 = from.centerY();
        float x2 = to.centerX();
        float y2 = to.centerY();
        float midX = (x1 + x2) * 0.5f;
        Path route = new Path();
        route.moveTo(x1, y1);
        route.cubicTo(midX, y1, midX, y2, x2, y2);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeWidth(8f * uiScale);
        stroke.setColor(Color.argb(115, 7, 11, 18));
        canvas.drawPath(route, stroke);
        stroke.setStrokeWidth(unlocked ? 3.5f * uiScale : 2.4f * uiScale);
        stroke.setColor(unlocked
                ? Color.argb(205, Color.red(accent), Color.green(accent), Color.blue(accent))
                : Color.argb(100, 82, 89, 102));
        canvas.drawPath(route, stroke);
        for (int dot = 1; dot <= 3; dot++) {
            float t = dot / 4f;
            float dx = x1 + (x2 - x1) * t;
            float dy = y1 + (y2 - y1) * t;
            paint.setColor(unlocked ? Color.argb(210, 255, 225, 145)
                    : Color.argb(105, 95, 101, 113));
            canvas.drawCircle(dx, dy, 3f * uiScale, paint);
        }
    }

    private void drawMapLevelNode(Canvas canvas, RectF node, int level,
                                  boolean unlocked, boolean completed, boolean selected,
                                  boolean boss, int stars, int accent) {
        float cx = node.centerX();
        float cy = node.centerY();
        float radius = Math.min(node.width(), node.height()) * (boss ? 0.43f : 0.37f);

        if (selected) {
            paint.setShader(new RadialGradient(cx, cy, radius * 1.85f,
                    new int[]{Color.argb(105, Color.red(accent), Color.green(accent), Color.blue(accent)),
                            Color.TRANSPARENT}, new float[]{0f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawCircle(cx, cy, radius * 1.85f, paint);
            paint.setShader(null);
        }

        paint.setColor(Color.argb(125, 0, 0, 0));
        canvas.drawOval(new RectF(cx - radius * 1.08f, cy + radius * 0.63f,
                cx + radius * 1.08f, cy + radius * 0.98f), paint);

        paint.setShader(new RadialGradient(cx - radius * 0.28f, cy - radius * 0.34f, radius * 1.30f,
                new int[]{unlocked ? Color.rgb(84, 92, 106) : Color.rgb(51, 56, 66),
                        boss && unlocked ? Color.rgb(83, 27, 36) : Color.rgb(17, 23, 34)},
                new float[]{0f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, radius, paint);
        paint.setShader(null);

        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(selected ? 4.5f * uiScale : 2.6f * uiScale);
        stroke.setColor(!unlocked ? Color.rgb(92, 99, 112)
                : boss ? Color.rgb(255, 111, 83)
                : selected ? GOLD_LIGHT : completed ? Color.rgb(105, 231, 205) : accent);
        canvas.drawCircle(cx, cy, radius, stroke);
        stroke.setStrokeWidth(1.2f * uiScale);
        stroke.setColor(Color.argb(140, 235, 238, 243));
        canvas.drawCircle(cx, cy, radius * 0.79f, stroke);

        if (boss) {
            drawCrown(canvas, cx, cy - radius * 0.48f, radius * 0.23f,
                    unlocked ? Color.rgb(255, 143, 93) : Color.rgb(112, 91, 91));
        } else {
            drawMapChapterEmblem(canvas, cx, cy - radius * 0.37f,
                    radius * 0.19f, chapterForLevelLocked(level), accent);
        }

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(Math.max(17f * uiScale, radius * 0.52f));
        paint.setColor(unlocked ? Color.WHITE : Color.rgb(112, 119, 132));
        canvas.drawText(Integer.toString(level), cx, cy + radius * 0.18f, paint);

        float starY = cy + radius * 0.58f;
        float starGap = radius * 0.38f;
        for (int star = 0; star < 3; star++) {
            drawMapStar(canvas, cx + (star - 1) * starGap, starY,
                    Math.max(4.5f * uiScale, radius * 0.12f), star < stars);
        }

        RectF label = new RectF(node.left + 3f * uiScale, node.bottom - 20f * uiScale,
                node.right - 3f * uiScale, node.bottom + 5f * uiScale);
        paint.setColor(Color.argb(210, 10, 15, 24));
        canvas.drawRoundRect(label, 8f * uiScale, 8f * uiScale, paint);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(8.5f * uiScale, 10f));
        paint.setColor(!unlocked ? Color.rgb(125, 132, 145)
                : boss ? Color.rgb(255, 166, 123)
                : completed ? Color.rgb(121, 231, 196) : GOLD_LIGHT);
        String state = !unlocked ? "KİLİTLİ" : boss ? "BOSS KALESİ"
                : completed ? "TAMAMLANDI" : "SIRADAKİ";
        canvas.drawText(state, label.centerX(), label.centerY() + paint.getTextSize() * 0.32f, paint);
    }

    private void drawMapChapterEmblem(Canvas canvas, float x, float y, float radius,
                                      int chapter, int accent) {
        paint.setColor(Color.argb(215, 13, 19, 30));
        canvas.drawCircle(x, y, radius, paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(2f * uiScale);
        stroke.setColor(accent);
        canvas.drawCircle(x, y, radius, stroke);
        paint.setColor(accent);
        if (chapter == 2) {
            Path flame = new Path();
            flame.moveTo(x, y - radius * 0.62f);
            flame.cubicTo(x + radius * 0.58f, y - radius * 0.10f,
                    x + radius * 0.35f, y + radius * 0.58f, x, y + radius * 0.62f);
            flame.cubicTo(x - radius * 0.48f, y + radius * 0.36f,
                    x - radius * 0.42f, y - radius * 0.18f, x, y - radius * 0.62f);
            flame.close();
            canvas.drawPath(flame, paint);
        } else if (chapter == 3) {
            for (int i = 0; i < 3; i++) {
                double a = i * Math.PI / 3d;
                canvas.drawLine(x - (float) Math.cos(a) * radius * 0.58f,
                        y - (float) Math.sin(a) * radius * 0.58f,
                        x + (float) Math.cos(a) * radius * 0.58f,
                        y + (float) Math.sin(a) * radius * 0.58f, stroke);
            }
        } else if (chapter == 4) {
            Path spike = new Path();
            spike.moveTo(x, y - radius * 0.65f);
            spike.lineTo(x + radius * 0.46f, y + radius * 0.56f);
            spike.lineTo(x, y + radius * 0.24f);
            spike.lineTo(x - radius * 0.46f, y + radius * 0.56f);
            spike.close();
            canvas.drawPath(spike, paint);
        } else if (chapter == 5) {
            canvas.drawCircle(x, y, radius * 0.45f, paint);
            paint.setColor(Color.rgb(13, 19, 30));
            canvas.drawCircle(x + radius * 0.18f, y - radius * 0.12f, radius * 0.38f, paint);
        } else {
            drawCrown(canvas, x, y, radius * 0.48f, accent);
        }
    }

    private void drawMapStar(Canvas canvas, float x, float y, float radius, boolean earned) {
        Path star = new Path();
        for (int point = 0; point < 10; point++) {
            double angle = -Math.PI / 2d + point * Math.PI / 5d;
            float r = point % 2 == 0 ? radius : radius * 0.45f;
            float px = x + (float) Math.cos(angle) * r;
            float py = y + (float) Math.sin(angle) * r;
            if (point == 0) star.moveTo(px, py); else star.lineTo(px, py);
        }
        star.close();
        paint.setColor(earned ? GOLD_LIGHT : Color.rgb(70, 77, 90));
        canvas.drawPath(star, paint);
    }

    private void drawMineScreen(Canvas canvas) {
        drawScreenFrame(canvas, false);
        drawButton(canvas, backButton, "GERİ", "Ana menü", true);

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(Math.max(30f * uiScale, Math.min(58f * uiScale, height * 0.075f)));
        paint.setColor(GOLD_LIGHT);
        canvas.drawText("ELMAS MADENİ", width * 0.5f, height * 0.105f, paint);

        float infoW = Math.min(width * 0.72f, 980f * uiScale);
        RectF info = new RectF((width - infoW) / 2f, height * 0.125f,
                (width + infoW) / 2f, height * 0.205f);
        drawPanel(canvas, info, 16f * uiScale, true);
        drawDiamondIcon(canvas, info.left + 42f * uiScale, info.centerY(), 15f * uiScale,
                Color.rgb(105, 231, 255));
        paint.setTextAlign(Paint.Align.LEFT);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(15f, 19f * uiScale));
        paint.setColor(Color.WHITE);
        canvas.drawText("ELMAS: " + diamonds, info.left + 72f * uiScale,
                info.centerY() + paint.getTextSize() * 0.34f, paint);
        paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText("KATMAN " + (mineDepth + 1) + "  •  MADENCİ " + diamondMinerCountLocked(),
                info.centerX(), info.centerY() + paint.getTextSize() * 0.34f, paint);
        paint.setTextAlign(Paint.Align.RIGHT);
        paint.setColor(Color.rgb(190, 207, 225));
        canvas.drawText("GÜÇ " + Math.round(diamondMiningPowerLocked()), info.right - 24f * uiScale,
                info.centerY() + paint.getTextSize() * 0.34f, paint);

        float shaftLeft = width * 0.16f;
        float shaftRight = width * 0.84f;
        float shaftTop = height * 0.235f;
        float shaftBottom = height * 0.745f;
        paint.setColor(Color.rgb(20, 22, 29));
        canvas.drawRoundRect(new RectF(shaftLeft, shaftTop, shaftRight, shaftBottom),
                18f * uiScale, 18f * uiScale, paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3f * uiScale);
        stroke.setColor(Color.rgb(118, 90, 55));
        canvas.drawRoundRect(new RectF(shaftLeft, shaftTop, shaftRight, shaftBottom),
                18f * uiScale, 18f * uiScale, stroke);

        int bands = 5;
        float bandH = (shaftBottom - shaftTop) / bands;
        for (int i = 0; i < bands; i++) {
            float top = shaftTop + i * bandH;
            paint.setColor(mineStoneColorLocked(i - 2));
            canvas.drawRect(shaftLeft + 4f, top, shaftRight - 4f, top + bandH + 1f, paint);
            paint.setColor(Color.argb(38, 255, 255, 255));
            canvas.drawRect(shaftLeft + 4f, top, shaftRight - 4f, top + 3f * uiScale, paint);
            for (int n = 0; n < 8; n++) {
                float rx = shaftLeft + 30f * uiScale + ((n * 137 + i * 71) % 800) / 800f
                        * Math.max(1f, shaftRight - shaftLeft - 60f * uiScale);
                float ry = top + 15f * uiScale + ((n * 47 + i * 29) % 100) / 100f
                        * Math.max(1f, bandH - 30f * uiScale);
                paint.setColor(Color.argb(85, 20, 23, 28));
                canvas.drawOval(new RectF(rx - 8f * uiScale, ry - 4f * uiScale,
                        rx + 9f * uiScale, ry + 5f * uiScale), paint);
            }
        }

        float workY = shaftTop + bandH * 2.52f;
        float blockCenterX = width * 0.58f;
        RectF activeBlock = new RectF(width * 0.48f, workY - bandH * 0.40f,
                width * 0.78f, workY + bandH * 0.40f);
        paint.setColor(Color.rgb(47, 51, 64));
        canvas.drawRoundRect(activeBlock, 12f * uiScale, 12f * uiScale, paint);
        stroke.setStrokeWidth(2.4f * uiScale);
        stroke.setColor(Color.rgb(116, 122, 139));
        canvas.drawRoundRect(activeBlock, 12f * uiScale, 12f * uiScale, stroke);

        float minedRatio = 1f - mineLayerHp / Math.max(1f, mineLayerMaxHp);
        for (int i = 0; i < 7; i++) {
            float cx = activeBlock.left + activeBlock.width() * (0.18f + (i % 4) * 0.20f);
            float cy = activeBlock.top + activeBlock.height() * (0.28f + (i / 4) * 0.42f);
            if ((i + mineDepth) % 3 == 0) {
                drawDiamondIcon(canvas, cx, cy, (7f + minedRatio * 5f) * uiScale,
                        Color.rgb(96, 225, 255));
            } else {
                paint.setColor(Color.rgb(98, 105, 119));
                canvas.drawCircle(cx, cy, 5f * uiScale, paint);
            }
        }

        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(2f * uiScale);
        stroke.setColor(Color.rgb(25, 28, 35));
        int crackCount = 2 + Math.round(minedRatio * 8f);
        for (int i = 0; i < crackCount; i++) {
            float sx = activeBlock.left + activeBlock.width() * (0.12f + (i * 0.11f) % 0.78f);
            float sy = activeBlock.top + activeBlock.height() * (0.25f + (i % 3) * 0.22f);
            Path crack = new Path();
            crack.moveTo(sx, sy);
            crack.lineTo(sx + 11f * uiScale, sy + 9f * uiScale);
            crack.lineTo(sx + 3f * uiScale, sy + 20f * uiScale);
            canvas.drawPath(crack, stroke);
        }

        for (int i = 0; i < diamondMinerCountLocked(); i++) {
            drawDiamondMiner(canvas, width * 0.28f + i * 66f * uiScale,
                    workY + (i % 2) * 13f * uiScale, i);
        }

        float progressW = Math.min(width * 0.60f, 820f * uiScale);
        float progressX = (width - progressW) / 2f;
        float progressY = height * 0.775f;
        drawHealthBar(canvas, progressX, progressY, progressW, minedRatio,
                Color.rgb(72, 210, 238), true);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(13f, 16f * uiScale));
        paint.setColor(Color.WHITE);
        canvas.drawText("KAZI İLERLEMESİ %" + Math.round(minedRatio * 100f), width * 0.5f,
                progressY - 10f * uiScale, paint);

        drawButton(canvas, mineDigButton, "KAZIYI HIZLANDIR", "Kazmaya dokun • otomatik madenciler çalışıyor", true);
    }

    private void drawDiamondMiner(Canvas canvas, float x, float y, int index) {
        float scale = Math.max(0.88f, Math.min(1.35f, uiScale));
        float swing = (float) Math.sin(mineClock * 7f + index * 1.7f);
        paint.setColor(Color.rgb(36, 45, 58));
        canvas.drawCircle(x, y - 42f * scale, 12f * scale, paint);
        paint.setColor(Color.rgb(226, 173, 62));
        canvas.drawRect(x - 14f * scale, y - 49f * scale, x + 14f * scale, y - 43f * scale, paint);
        paint.setColor(Color.rgb(72, 95, 119));
        canvas.drawRoundRect(new RectF(x - 14f * scale, y - 34f * scale,
                x + 14f * scale, y - 5f * scale), 5f * scale, 5f * scale, paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeWidth(5f * scale);
        stroke.setColor(Color.rgb(199, 205, 214));
        float toolX = x + 27f * scale;
        float toolY = y - 35f * scale + swing * 16f * scale;
        canvas.drawLine(x + 7f * scale, y - 27f * scale, toolX, toolY, stroke);
        stroke.setColor(Color.rgb(151, 105, 58));
        stroke.setStrokeWidth(4f * scale);
        canvas.drawLine(toolX - 7f * scale, toolY - 9f * scale,
                toolX + 12f * scale, toolY + 9f * scale, stroke);
        canvas.drawLine(toolX - 7f * scale, toolY - 9f * scale,
                toolX + 12f * scale, toolY - 13f * scale, stroke);
        stroke.setColor(Color.rgb(72, 95, 119));
        canvas.drawLine(x - 6f * scale, y - 5f * scale, x - 13f * scale, y + 10f * scale, stroke);
        canvas.drawLine(x + 6f * scale, y - 5f * scale, x + 13f * scale, y + 10f * scale, stroke);
    }

    private void drawDiamondIcon(Canvas canvas, float x, float y, float size, int color) {
        Path diamond = new Path();
        diamond.moveTo(x, y - size);
        diamond.lineTo(x + size * 0.82f, y - size * 0.20f);
        diamond.lineTo(x + size * 0.48f, y + size);
        diamond.lineTo(x - size * 0.48f, y + size);
        diamond.lineTo(x - size * 0.82f, y - size * 0.20f);
        diamond.close();
        paint.setShader(new LinearGradient(x - size, y - size, x + size, y + size,
                Color.WHITE, color, Shader.TileMode.CLAMP));
        canvas.drawPath(diamond, paint);
        paint.setShader(null);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(Math.max(1f, size * 0.11f));
        stroke.setColor(Color.argb(210, 22, 83, 111));
        canvas.drawPath(diamond, stroke);
        canvas.drawLine(x, y - size, x, y + size, stroke);
    }

    private void drawSettingsScreen(Canvas canvas) {
        drawScreenFrame(canvas, false);
        drawButton(canvas, backButton, "GERİ", "Ana menü", true);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(Math.max(32f * uiScale, Math.min(62f * uiScale, height * 0.082f)));
        paint.setColor(GOLD_LIGHT);
        canvas.drawText("SES VE OYUN AYARLARI", width * 0.5f, height * 0.18f, paint);

        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(Math.max(13f, 17f * uiScale));
        paint.setColor(Color.rgb(195, 205, 219));
        canvas.drawText("Müzik ve efekt kanalları ayrı yönetilir • Her krallığın özel savaş müziği vardır.",
                width * 0.5f, height * 0.235f, paint);
        canvas.drawText("Ses seviyesine dokunarak %25 • %50 • %75 • %100 arasında geçiş yap.",
                width * 0.5f, height * 0.275f, paint);

        drawButton(canvas, musicToggleButton,
                musicEnabled ? "MÜZİK: AÇIK" : "MÜZİK: KAPALI",
                musicEnabled ? musicTrackNameLocked() : "Arka plan müzikleri kapalı", true);
        drawButton(canvas, effectsToggleButton,
                effectsEnabled ? "EFEKTLER: AÇIK" : "EFEKTLER: KAPALI",
                effectsEnabled ? "Kılıç • ok • yetenek • boss" : "Savaş efektleri kapalı", true);
        drawButton(canvas, musicVolumeButton,
                "MÜZİK SEVİYESİ %" + musicVolumePercentLocked(),
                "Dokun: sonraki seviye", musicEnabled);
        drawButton(canvas, effectsVolumeButton,
                "EFEKT SEVİYESİ %" + effectsVolumePercentLocked(),
                "Dokun: sonraki seviye", effectsEnabled);
        drawButton(canvas, resetLevelButton, "BÖLÜMÜ 1'E SIFIRLA",
                "Elmas, maden derinliği ve geliştirmeler korunur", true);
        drawButton(canvas, resetProgressButton,
                fullResetArmed ? "EMİN MİSİN? TEKRAR DOKUN" : "TÜM İLERLEMEYİ SIFIRLA",
                fullResetArmed ? "5 saniye içinde onayla" : "Bölüm, geliştirme, elmas ve maden silinir",
                true);
    }

    private void drawArenaCenterDecor(Canvas canvas) {
        float centerX = arenaCameraFocusLocked();
        float centerY = groundY + 4f * uiScale;
        float pulse = 0.82f + 0.08f * (float) Math.sin(ambientClock * 2.3f);
        float radiusX = Math.min(width * 0.22f, 320f * uiScale);
        float radiusY = Math.max(28f * uiScale, 44f * uiScale * pulse);

        paint.setShader(new RadialGradient(centerX, centerY - 4f * uiScale, radiusX,
                new int[]{Color.argb(76, 158, 94, 238), Color.argb(24, 92, 49, 156), Color.TRANSPARENT},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawOval(new RectF(centerX - radiusX, centerY - radiusY,
                centerX + radiusX, centerY + radiusY), paint);
        paint.setShader(null);

        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3f * uiScale);
        stroke.setColor(Color.argb(185, 202, 157, 255));
        canvas.drawOval(new RectF(centerX - radiusX * 0.82f, centerY - radiusY * 0.74f,
                centerX + radiusX * 0.82f, centerY + radiusY * 0.74f), stroke);
        stroke.setStrokeWidth(1.4f * uiScale);
        stroke.setColor(Color.argb(120, 226, 195, 255));
        canvas.drawLine(centerX, groundY - 118f * uiScale, centerX, groundY + 10f * uiScale, stroke);
        canvas.drawLine(centerX - 90f * uiScale, centerY, centerX + 90f * uiScale, centerY, stroke);

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(10f * uiScale, 13f));
        paint.setColor(Color.argb(190, 230, 211, 255));
        canvas.drawText("ARENA MERKEZ HATTI", centerX, groundY - 126f * uiScale, paint);
    }

    private void drawArenaChampionEntryEffect(Canvas canvas) {
        float t = Math.max(0f, Math.min(1f, arenaChampionEntryTimer / 2.35f));
        float x = arenaChampionEntryX;
        float y = groundY - 86f * uiScale;
        float expand = 1f + (1f - t) * 0.85f;
        float radius = 120f * uiScale * expand;

        paint.setShader(new RadialGradient(x, y, radius,
                new int[]{Color.argb((int) (150f * t), 225, 173, 255),
                        Color.argb((int) (90f * t), 125, 58, 214), Color.TRANSPARENT},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawCircle(x, y, radius, paint);
        paint.setShader(null);

        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(5f * uiScale);
        stroke.setColor(Color.argb((int) (235f * t), 226, 178, 255));
        canvas.drawCircle(x, y, 58f * uiScale * expand, stroke);
        stroke.setStrokeWidth(2f * uiScale);
        for (int i = -2; i <= 2; i++) {
            float beamX = x + i * 26f * uiScale;
            canvas.drawLine(beamX, groundY - 235f * uiScale, beamX, groundY + 8f * uiScale, stroke);
        }
    }

    private void initializeAudioLocked(Context context) {
        try {
            AudioAttributes attributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            soundPool = new SoundPool.Builder()
                    .setMaxStreams(8)
                    .setAudioAttributes(attributes)
                    .build();
            sndSwordHit = soundPool.load(context, R.raw.sword_hit, 1);
            sndArrowShot = soundPool.load(context, R.raw.arrow_shot, 1);
            sndPickaxeHit = soundPool.load(context, R.raw.pickaxe_hit, 1);
            sndInjury = soundPool.load(context, R.raw.injury, 1);
            sndFootstep = soundPool.load(context, R.raw.footsteps, 1);
            sndSpearThrow = soundPool.load(context, R.raw.spear_throw, 1);
            sndSpearHit = soundPool.load(context, R.raw.spear_hit, 1);
            sndBaseHit = soundPool.load(context, R.raw.base_hit, 1);
            sndBossEntry = soundPool.load(context, R.raw.boss_entry, 1);
            sndWarCry = soundPool.load(context, R.raw.warcry, 1);
            sndShield = soundPool.load(context, R.raw.shield, 1);
            sndArrowRain = soundPool.load(context, R.raw.arrow_rain, 1);
            sndVictory = soundPool.load(context, R.raw.victory, 1);
            sndDefeat = soundPool.load(context, R.raw.defeat, 1);
        } catch (Throwable ignored) {
            soundPool = null;
        }
    }

    private int musicVolumePercentLocked() {
        return Math.max(1, Math.min(4, musicVolumeLevel)) * 25;
    }

    private int effectsVolumePercentLocked() {
        return Math.max(1, Math.min(4, effectsVolumeLevel)) * 25;
    }

    private float musicVolumeRatioLocked() {
        return musicVolumePercentLocked() / 100f;
    }

    private float effectsVolumeRatioLocked() {
        return effectsVolumePercentLocked() / 100f;
    }

    private String musicTrackNameLocked() {
        if (arenaMode) return "Arena: Sonsuz Yarık";
        int chapter = chapterForLevelLocked(Math.max(1, battleLevel));
        if (chapter == 2) return "Kızıl Çöl savaş müziği";
        if (chapter == 3) return "Buz Geçidi savaş müziği";
        if (chapter == 4) return "Kül Diyarı savaş müziği";
        if (chapter == 5) return "Gölge Hisarı savaş müziği";
        return "Ay Vadisi savaş müziği";
    }

    private void playSoundLocked(int soundId, float volume, float rate) {
        if (!effectsEnabled || soundPool == null || soundId == 0) return;
        float finalVolume = Math.max(0f, Math.min(1f, volume * effectsVolumeRatioLocked()));
        if (finalVolume <= 0f) return;
        try {
            soundPool.play(soundId, finalVolume, finalVolume, 1, 0,
                    Math.max(0.72f, Math.min(1.32f, rate)));
        } catch (Throwable ignored) {
            // Ses aygıtı hazır değilse oyun devam eder.
        }
    }

    private void playSwordSoundLocked(float volume) {
        if (swordSfxCooldown > 0f) return;
        swordSfxCooldown = 0.085f;
        playSoundLocked(sndSwordHit, volume, 0.92f + random.nextFloat() * 0.16f);
    }

    private void playArrowSoundLocked() {
        if (arrowSfxCooldown > 0f) return;
        arrowSfxCooldown = 0.10f;
        playSoundLocked(sndArrowShot, 0.55f, 0.94f + random.nextFloat() * 0.14f);
    }

    private void playPickaxeSoundLocked(float volume) {
        if (pickaxeSfxCooldown > 0f) return;
        pickaxeSfxCooldown = 0.16f;
        playSoundLocked(sndPickaxeHit, volume, 0.90f + random.nextFloat() * 0.15f);
    }

    private void playBaseHitSoundLocked() {
        if (baseSfxCooldown > 0f) return;
        baseSfxCooldown = 0.22f;
        playSoundLocked(sndBaseHit, 0.86f, 0.94f + random.nextFloat() * 0.08f);
    }

    private void playInjurySoundLocked(float damage, boolean fatal) {
        if (injurySfxCooldown > 0f) return;
        injurySfxCooldown = fatal ? 0.20f : 0.13f;
        float volume = fatal ? 0.66f : Math.min(0.54f, 0.28f + damage / 150f);
        playSoundLocked(sndInjury, volume, fatal ? 0.88f : 0.96f + random.nextFloat() * 0.10f);
    }

    private void playFootstepSoundLocked(float scale, boolean playerSide) {
        if (footstepSfxCooldown > 0f) return;
        footstepSfxCooldown = 0.11f;
        float volume = Math.min(0.30f, 0.14f + scale * 0.055f);
        playSoundLocked(sndFootstep, volume, (playerSide ? 1.01f : 0.94f) + random.nextFloat() * 0.08f);
    }

    private void playSpearThrowSoundLocked() {
        if (spearSfxCooldown > 0f) return;
        spearSfxCooldown = 0.12f;
        playSoundLocked(sndSpearThrow, 0.62f, 0.94f + random.nextFloat() * 0.12f);
    }

    private void playSpearHitSoundLocked() {
        if (spearSfxCooldown > 0f) return;
        spearSfxCooldown = 0.10f;
        playSoundLocked(sndSpearHit, 0.70f, 0.92f + random.nextFloat() * 0.12f);
    }

    private int musicResourceForTrackLocked(int track) {
        if (track == 6) return R.raw.arena_loop;
        if (track == 2) return R.raw.kingdom_desert;
        if (track == 3) return R.raw.kingdom_ice;
        if (track == 4) return R.raw.kingdom_ash;
        if (track == 5) return R.raw.kingdom_shadow;
        return R.raw.kingdom_moon;
    }

    private void applyMusicVolumeLocked() {
        if (musicPlayer == null) return;
        float baseVolume = currentMusicTrack == 6 ? 0.28f : 0.25f;
        float volume = baseVolume * musicVolumeRatioLocked();
        try {
            musicPlayer.setVolume(volume, volume);
        } catch (Throwable ignored) {
            // Medya oynatıcı kapanırken seviye ayarı yok sayılabilir.
        }
    }

    private void updateMusicForScreenLocked() {
        int targetTrack = 0;
        if (musicEnabled && (screen == Screen.PLAYING || screen == Screen.PAUSED
                || screen == Screen.WIN || screen == Screen.LOSE)) {
            targetTrack = arenaMode ? 6 : chapterForLevelLocked(Math.max(1, battleLevel));
        }
        if (targetTrack == 0) {
            stopMusicLocked();
            return;
        }
        if (currentMusicTrack != targetTrack || musicPlayer == null) {
            stopMusicLocked();
            try {
                musicPlayer = MediaPlayer.create(getContext(), musicResourceForTrackLocked(targetTrack));
                if (musicPlayer != null) {
                    currentMusicTrack = targetTrack;
                    musicPlayer.setLooping(true);
                    applyMusicVolumeLocked();
                    musicPlayer.start();
                }
            } catch (Throwable ignored) {
                musicPlayer = null;
                currentMusicTrack = 0;
            }
        } else {
            try {
                applyMusicVolumeLocked();
                if (!musicPlayer.isPlaying()) musicPlayer.start();
            } catch (Throwable ignored) {
                currentMusicTrack = -1;
            }
        }
    }

    private void pauseMusicLocked() {
        if (musicPlayer == null) return;
        try {
            if (musicPlayer.isPlaying()) musicPlayer.pause();
        } catch (Throwable ignored) {
            currentMusicTrack = -1;
        }
    }

    private void stopMusicLocked() {
        if (musicPlayer != null) {
            try {
                musicPlayer.stop();
            } catch (Throwable ignored) {
                // Hazırlanmamış oynatıcı stop çağrısını reddedebilir.
            }
            try {
                musicPlayer.release();
            } catch (Throwable ignored) {
                // Kaynak zaten serbest olabilir.
            }
            musicPlayer = null;
        }
        currentMusicTrack = 0;
    }

    private void releaseAudioLocked() {
        stopMusicLocked();
        if (soundPool != null) {
            try {
                soundPool.release();
            } catch (Throwable ignored) {
                // SoundPool zaten serbest olabilir.
            }
            soundPool = null;
        }
    }

    private void triggerCombatFeelLocked(int color, float pulseDuration, float shakeBoost,
                                         float hitStopDuration, boolean strongHaptic) {
        combatPulseColor = color;
        combatPulseTimer = Math.max(combatPulseTimer, pulseDuration);
        screenShake = Math.max(screenShake, shakeBoost);
        hitStopTimer = Math.max(hitStopTimer, hitStopDuration);
        triggerHapticPulse(strongHaptic);
    }

    private void triggerHapticPulse(final boolean strong) {
        post(new Runnable() {
            @Override
            public void run() {
                try {
                    performHapticFeedback(strong ? HapticFeedbackConstants.LONG_PRESS
                            : HapticFeedbackConstants.VIRTUAL_KEY);
                } catch (Throwable ignored) {
                    // Bazı cihazlar haptik desteğini yok sayabilir.
                }
            }
        });
    }

    private void drawCombatFeelOverlay(Canvas canvas) {
        if (combatPulseTimer > 0f) {
            float t = Math.max(0f, Math.min(1f, combatPulseTimer / 0.24f));
            int alpha = Math.min(115, (int) (86f * t));
            paint.setColor(Color.argb(alpha,
                    Color.red(combatPulseColor),
                    Color.green(combatPulseColor),
                    Color.blue(combatPulseColor)));
            canvas.drawRect(0f, 0f, width, height, paint);
        }
        if (resultPulseTimer > 0f) {
            float t = Math.max(0f, Math.min(1f, resultPulseTimer / 1.8f));
            int pulseColor = resultVictory ? Color.rgb(255, 211, 110) : Color.rgb(255, 118, 98);
            paint.setShader(new RadialGradient(width * 0.5f, height * 0.42f,
                    Math.max(width, height) * (0.30f + (1f - t) * 0.10f),
                    new int[]{Color.argb((int) (80f * t), Color.red(pulseColor), Color.green(pulseColor), Color.blue(pulseColor)),
                            Color.argb((int) (34f * t), Color.red(pulseColor), Color.green(pulseColor), Color.blue(pulseColor)),
                            Color.TRANSPARENT},
                    new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawRect(0f, 0f, width, height, paint);
            paint.setShader(null);
        }
    }

    private void drawPauseOverlay(Canvas canvas) {
        paint.setColor(Color.argb(195, 4, 7, 13));
        canvas.drawRect(0f, 0f, width, height, paint);
        float panelW = Math.min(width * 0.68f, 850f * uiScale);
        float panelH = height * 0.64f;
        RectF panel = new RectF((width - panelW) / 2f, height * 0.17f,
                (width + panelW) / 2f, height * 0.17f + panelH);
        drawPanel(canvas, panel, 24f * uiScale, true);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(Math.max(34f * uiScale, height * 0.072f));
        paint.setColor(GOLD_LIGHT);
        canvas.drawText("OYUN DURAKLATILDI", width * 0.5f, height * 0.31f, paint);
        drawButton(canvas, pauseContinueButton, "DEVAM ET", "Savaşa geri dön", true);
        drawButton(canvas, pauseRestartButton, "BÖLÜMÜ YENİDEN BAŞLAT", "Mevcut savaşı sıfırla", true);
        drawButton(canvas, pauseMenuButton, "ANA MENÜ", "İlerleme kaydedilir", true);
    }

    private void drawBattlefield(Canvas canvas) {
        canvas.save();
        if (screenShake > 0f) {
            float shakeX = (random.nextFloat() * 2f - 1f) * screenShake;
            float shakeY = (random.nextFloat() * 2f - 1f) * screenShake * 0.55f;
            canvas.translate(shakeX, shakeY);
        }
        canvas.translate(-cameraX, 0f);
        drawBattlefieldBackdropDepth(canvas);
        drawBattlefieldProps(canvas);
        if (arenaMode) drawArenaCenterDecor(canvas);
        drawGoldMines(canvas);
        drawDefenseStructures(canvas);
        drawParticles(canvas, true);
        drawDeathEffects(canvas);
        drawStatue(canvas, playerBaseX(), groundY, true, playerBaseHp);
        drawStatue(canvas, enemyBaseX(), groundY, false, enemyBaseHp);
        if (arenaMode && arenaChampionEntryTimer > 0f) drawArenaChampionEntryEffect(canvas);
        if (statueShieldTimer > 0f) drawStatueShieldEffect(canvas);
        if (arrowRainTimer > 0f) drawArrowRainEffect(canvas);
        for (int lane = -1; lane <= 1; lane++) {
            for (Unit unit : playerUnits) {
                if (unit.lane == lane) drawUnit(canvas, unit, true);
            }
            for (Unit unit : enemyUnits) {
                if (unit.lane == lane) drawUnit(canvas, unit, false);
            }
        }
        drawProjectiles(canvas);
        drawImpacts(canvas);
        drawParticles(canvas, false);
        drawFloatingTexts(canvas);
        canvas.restore();
        drawBattlefieldVignette(canvas);
        drawScreenFrame(canvas, false);
    }

    private void drawBattlefieldBackdropDepth(Canvas canvas) {
        // v0.3.0: savaş alanına derinlik, atmosfer ve zemin dokusu ekler.
        int theme = backgroundThemeKeyLocked();
        for (int i = 0; i < 5; i++) {
            float ridgeY = groundY - (160f + i * 26f) * uiScale;
            float alpha = 26f + i * 10f;
            Path ridge = new Path();
            ridge.moveTo(0f, groundY + 6f * uiScale);
            ridge.lineTo(0f, ridgeY);
            float step = Math.max(120f * uiScale, worldWidth / 8f);
            for (int p = 0; p <= 8; p++) {
                float px = p * step;
                float py = ridgeY + (((p + i) % 2 == 0) ? -28f : 22f) * uiScale - i * 4f * uiScale;
                ridge.lineTo(Math.min(worldWidth, px), py);
            }
            ridge.lineTo(worldWidth, groundY + 6f * uiScale);
            ridge.close();
            int c = theme == 2 ? Color.argb((int) alpha, 137, 92, 57)
                    : theme == 3 ? Color.argb((int) alpha, 110, 141, 156)
                    : theme == 4 ? Color.argb((int) alpha, 126, 73, 52)
                    : theme == 5 ? Color.argb((int) alpha, 92, 79, 130)
                    : theme == 6 ? Color.argb((int) alpha, 108, 69, 158)
                    : Color.argb((int) alpha, 110, 100, 89);
            paint.setColor(c);
            canvas.drawPath(ridge, paint);
        }

        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(Math.max(1.1f * uiScale, 1.8f));
        for (int i = 0; i < 12; i++) {
            float x = worldWidth * (0.02f + i * 0.085f);
            int a = 50 + (i % 3) * 16;
            int lineColor = theme == 3 ? Color.argb(a, 190, 228, 244)
                    : theme == 5 ? Color.argb(a, 132, 118, 210)
                    : theme == 4 ? Color.argb(a, 185, 100, 60)
                    : Color.argb(a, 212, 186, 142);
            stroke.setColor(lineColor);
            canvas.drawLine(x, groundY + 5f * uiScale, x + 48f * uiScale, groundY - 20f * uiScale, stroke);
            canvas.drawLine(x + 48f * uiScale, groundY - 20f * uiScale, x + 96f * uiScale, groundY + 5f * uiScale, stroke);
        }

        paint.setShader(new LinearGradient(0f, groundY - 135f * uiScale, 0f, groundY + 35f * uiScale,
                Color.argb(34, 255, 255, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP));
        canvas.drawRect(0f, groundY - 135f * uiScale, worldWidth, groundY + 35f * uiScale, paint);
        paint.setShader(null);
    }

    private void drawThemeForegroundProps(Canvas canvas) {
        int theme = backgroundThemeKeyLocked();
        if (theme == 2) {
            for (int i = 0; i < 7; i++) {
                float x = worldWidth * (0.10f + i * 0.12f);
                drawCactus(canvas, x, groundY + 4f * uiScale, 0.85f + (i % 3) * 0.10f);
            }
        } else if (theme == 3) {
            for (int i = 0; i < 8; i++) {
                float x = worldWidth * (0.08f + i * 0.11f);
                drawIceCrystal(canvas, x, groundY + 4f * uiScale, 0.82f + (i % 3) * 0.12f);
            }
        } else if (theme == 4) {
            for (int i = 0; i < 9; i++) {
                float x = worldWidth * (0.06f + i * 0.10f);
                drawLavaSpikes(canvas, x, groundY + 4f * uiScale, 0.86f + (i % 2) * 0.10f);
            }
        } else if (theme == 5 || theme == 6) {
            for (int i = 0; i < 8; i++) {
                float x = worldWidth * (0.07f + i * 0.11f);
                drawObsidianTotem(canvas, x, groundY + 5f * uiScale, 0.82f + (i % 2) * 0.12f, theme == 6);
            }
        } else {
            for (int i = 0; i < 8; i++) {
                float x = worldWidth * (0.09f + i * 0.11f);
                drawBattleBanner(canvas, x, groundY + 2f * uiScale, 0.80f + (i % 3) * 0.12f);
            }
        }
    }

    private void drawBattleBanner(Canvas canvas, float x, float y, float scale) {
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setColor(Color.rgb(79, 58, 36));
        stroke.setStrokeWidth(3.2f * scale * uiScale);
        canvas.drawLine(x, y - 72f * scale * uiScale, x, y + 4f * scale * uiScale, stroke);
        Path flag = new Path();
        flag.moveTo(x, y - 68f * scale * uiScale);
        flag.lineTo(x + 34f * scale * uiScale, y - 58f * scale * uiScale);
        flag.lineTo(x + 8f * scale * uiScale, y - 36f * scale * uiScale);
        flag.lineTo(x + 34f * scale * uiScale, y - 18f * scale * uiScale);
        flag.lineTo(x, y - 24f * scale * uiScale);
        flag.close();
        paint.setColor(Color.argb(220, 186, 139, 72));
        canvas.drawPath(flag, paint);
    }

    private void drawCactus(Canvas canvas, float x, float y, float scale) {
        paint.setColor(Color.rgb(63, 114, 69));
        canvas.drawRoundRect(new RectF(x - 7f * scale * uiScale, y - 54f * scale * uiScale,
                x + 7f * scale * uiScale, y), 6f * uiScale, 6f * uiScale, paint);
        canvas.drawRoundRect(new RectF(x - 18f * scale * uiScale, y - 38f * scale * uiScale,
                x - 6f * scale * uiScale, y - 18f * scale * uiScale), 6f * uiScale, 6f * uiScale, paint);
        canvas.drawRoundRect(new RectF(x + 6f * scale * uiScale, y - 46f * scale * uiScale,
                x + 18f * scale * uiScale, y - 26f * scale * uiScale), 6f * uiScale, 6f * uiScale, paint);
    }

    private void drawIceCrystal(Canvas canvas, float x, float y, float scale) {
        Path crystal = new Path();
        crystal.moveTo(x, y - 58f * scale * uiScale);
        crystal.lineTo(x + 14f * scale * uiScale, y - 22f * scale * uiScale);
        crystal.lineTo(x + 4f * scale * uiScale, y);
        crystal.lineTo(x - 10f * scale * uiScale, y - 16f * scale * uiScale);
        crystal.close();
        paint.setColor(Color.argb(220, 154, 227, 255));
        canvas.drawPath(crystal, paint);
        stroke.setColor(Color.argb(165, 240, 250, 255));
        stroke.setStrokeWidth(2f * uiScale);
        canvas.drawPath(crystal, stroke);
    }

    private void drawLavaSpikes(Canvas canvas, float x, float y, float scale) {
        Path spike = new Path();
        spike.moveTo(x - 12f * scale * uiScale, y);
        spike.lineTo(x, y - 60f * scale * uiScale);
        spike.lineTo(x + 11f * scale * uiScale, y);
        spike.close();
        paint.setColor(Color.rgb(72, 54, 49));
        canvas.drawPath(spike, paint);
        paint.setColor(Color.argb(170, 255, 112, 54));
        canvas.drawRect(x - 2f * scale * uiScale, y - 42f * scale * uiScale,
                x + 2f * scale * uiScale, y - 10f * scale * uiScale, paint);
    }

    private void drawObsidianTotem(Canvas canvas, float x, float y, float scale, boolean arena) {
        Path totem = new Path();
        totem.moveTo(x, y - 62f * scale * uiScale);
        totem.lineTo(x + 13f * scale * uiScale, y - 18f * scale * uiScale);
        totem.lineTo(x + 6f * scale * uiScale, y);
        totem.lineTo(x - 8f * scale * uiScale, y - 8f * scale * uiScale);
        totem.lineTo(x - 14f * scale * uiScale, y - 26f * scale * uiScale);
        totem.close();
        paint.setColor(arena ? Color.rgb(69, 53, 104) : Color.rgb(48, 42, 69));
        canvas.drawPath(totem, paint);
        paint.setColor(arena ? Color.argb(180, 206, 125, 255) : Color.argb(160, 150, 118, 242));
        canvas.drawCircle(x, y - 32f * scale * uiScale, 4.5f * scale * uiScale, paint);
    }

    private void drawBattlefieldVignette(Canvas canvas) {
        paint.setShader(new RadialGradient(width * 0.5f, height * 0.46f,
                Math.max(width, height) * 0.72f,
                new int[]{Color.TRANSPARENT, Color.argb(82, 0, 0, 0)},
                new float[]{0.52f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRect(0f, 0f, width, height, paint);
        paint.setShader(null);
    }

    private void drawScreenFrame(Canvas canvas, boolean menu) {
        float inset = Math.max(6f, safePadding * 0.46f);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(Math.max(1f, 1.5f * uiScale));
        stroke.setColor(Color.argb(menu ? 115 : 70, 226, 173, 62));
        canvas.drawRoundRect(new RectF(inset, inset, width - inset, height - inset),
                14f * uiScale, 14f * uiScale, stroke);
        float corner = 34f * uiScale;
        canvas.drawLine(inset, inset + corner, inset + corner, inset, stroke);
        canvas.drawLine(width - inset - corner, inset, width - inset, inset + corner, stroke);
        canvas.drawLine(inset, height - inset - corner, inset + corner, height - inset, stroke);
        canvas.drawLine(width - inset - corner, height - inset, width - inset, height - inset - corner, stroke);
    }

    private void drawBattlefieldProps(Canvas canvas) {
        // v0.3.0: Sis, çevre objeleri ve tema detaylarıyla daha profesyonel savaş alanı.
        for (int i = 0; i < 8; i++) {
            float fogX = ((ambientClock * (9f + i * 2.2f) + i * worldWidth * 0.19f) % (worldWidth + 320f)) - 160f;
            float fogY = groundY - 34f + (i % 4) * 16f;
            paint.setColor(Color.argb(15 + (i % 4) * 5, 178, 194, 205));
            canvas.drawOval(new RectF(fogX - 132f, fogY - 17f, fogX + 132f, fogY + 17f), paint);
        }
        for (int i = 0; i < 28; i++) {
            float x = worldWidth * (0.050f + i * 0.033f);
            float y = groundY + 12f + (i % 4) * 8f;
            paint.setColor(Color.argb(160, 41, 35, 30));
            canvas.drawOval(new RectF(x - 15f, y - 5f, x + 17f, y + 6f), paint);
            paint.setColor(Color.argb(140, 96, 79, 60));
            canvas.drawOval(new RectF(x - 9f, y - 8f, x + 9f, y + 2f), paint);
        }
        drawThemeForegroundProps(canvas);
        drawTorch(canvas, worldWidth * 0.17f, groundY - 4f, 1f);
        drawTorch(canvas, worldWidth * 0.39f, groundY - 4f, 0.9f);
        drawTorch(canvas, worldWidth * 0.61f, groundY - 4f, 0.9f);
        drawTorch(canvas, worldWidth * 0.83f, groundY - 4f, 1f);

        // Oyuncunun savunma sınırı, birliklerin SAVUN modunda koruduğu hattır.
        float defenseX = playerDefenseBoundaryLocked();
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(2.2f * uiScale);
        stroke.setColor(Color.argb(commandMode == CommandMode.DEFEND ? 210 : 85, 92, 174, 255));
        canvas.drawLine(defenseX, groundY - 116f * uiScale, defenseX, groundY + 20f * uiScale, stroke);
        paint.setColor(Color.argb(commandMode == CommandMode.DEFEND ? 220 : 100, 63, 142, 222));
        Path banner = new Path();
        banner.moveTo(defenseX, groundY - 116f * uiScale);
        banner.lineTo(defenseX + 54f * uiScale, groundY - 98f * uiScale);
        banner.lineTo(defenseX, groundY - 80f * uiScale);
        banner.close();
        canvas.drawPath(banner, paint);

        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3f);
        stroke.setColor(Color.rgb(83, 58, 39));
        for (int i = 0; i < 9; i++) {
            float x = worldWidth * (0.28f + i * 0.055f);
            canvas.drawLine(x - 10f, groundY + 14f, x + 11f, groundY - 10f, stroke);
        }
    }

    private void drawGoldMines(Canvas canvas) {
        for (int i = 0; i < PLAYER_MINE_COUNT; i++) {
            float x = playerMineXLocked(i);
            float reserveRatio = playerMineMaxGold[i] <= 0f ? 0f
                    : Math.max(0f, Math.min(1f, playerMineGold[i] / playerMineMaxGold[i]));
            float scale = (0.90f + i * 0.08f) * uiScale;

            paint.setColor(Color.argb(120, 0, 0, 0));
            canvas.drawOval(new RectF(x - 58f * scale, groundY - 7f * scale,
                    x + 58f * scale, groundY + 13f * scale), paint);
            paint.setShader(new LinearGradient(x, groundY - 82f * scale, x, groundY,
                    Color.rgb(86, 82, 78), Color.rgb(43, 42, 43), Shader.TileMode.CLAMP));
            Path rock = new Path();
            rock.moveTo(x - 56f * scale, groundY);
            rock.lineTo(x - 45f * scale, groundY - 44f * scale);
            rock.lineTo(x - 17f * scale, groundY - 71f * scale);
            rock.lineTo(x + 18f * scale, groundY - 78f * scale);
            rock.lineTo(x + 49f * scale, groundY - 48f * scale);
            rock.lineTo(x + 60f * scale, groundY);
            rock.close();
            canvas.drawPath(rock, paint);
            paint.setShader(null);

            int veins = reserveRatio <= 0f ? 0 : 3 + Math.round(reserveRatio * 4f);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeCap(Paint.Cap.ROUND);
            stroke.setStrokeWidth(4f * scale);
            stroke.setColor(Color.argb((int) (90 + reserveRatio * 165), 255, 205, 72));
            for (int vein = 0; vein < veins; vein++) {
                float vx = x - 30f * scale + vein * 10f * scale;
                float vy = groundY - (25f + (vein % 3) * 13f) * scale;
                canvas.drawLine(vx, vy, vx + 15f * scale, vy - 17f * scale, stroke);
            }
            paint.setColor(Color.argb((int) (70 + reserveRatio * 185), 255, 227, 126));
            canvas.drawCircle(x + 9f * scale, groundY - 46f * scale, 5f * scale, paint);

            float barW = 82f * scale;
            drawHealthBar(canvas, x - barW / 2f, groundY - 103f * scale,
                    barW, reserveRatio, GOLD, false);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            paint.setTextSize(11f * scale);
            paint.setColor(reserveRatio > 0f ? GOLD_LIGHT : Color.GRAY);
            canvas.drawText(reserveRatio > 0f ? "ALTIN " + Math.round(playerMineGold[i]) : "TÜKENDİ",
                    x, groundY - 111f * scale, paint);
        }
    }

    private void drawTorch(Canvas canvas, float x, float y, float scale) {
        float flicker = (float) Math.sin(ambientClock * 8.5f + x * 0.013f);
        float sway = (float) Math.sin(ambientClock * 6.2f + x * 0.021f) * 4f * scale;
        float flameScale = 1f + flicker * 0.08f;
        stroke.setColor(Color.rgb(92, 62, 38));
        stroke.setStrokeWidth(4f * scale);
        canvas.drawLine(x, y, x, y - 46f * scale, stroke);
        paint.setShader(new RadialGradient(x + sway * 0.3f, y - 52f * scale,
                28f * scale * flameScale,
                new int[]{Color.argb(210, 255, 184, 70), Color.argb(80, 255, 92, 25), Color.TRANSPARENT},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawCircle(x + sway * 0.3f, y - 52f * scale,
                28f * scale * flameScale, paint);
        paint.setShader(null);
        paint.setColor(Color.rgb(255, 178, 63));
        Path flame = new Path();
        flame.moveTo(x + sway, y - 70f * scale * flameScale);
        flame.cubicTo(x + 12f * scale + sway * 0.55f, y - 58f * scale,
                x + 8f * scale, y - 43f * scale, x, y - 40f * scale);
        flame.cubicTo(x - 9f * scale, y - 48f * scale,
                x - 8f * scale + sway * 0.35f, y - 59f * scale,
                x + sway, y - 70f * scale * flameScale);
        flame.close();
        canvas.drawPath(flame, paint);
        paint.setColor(Color.rgb(255, 232, 126));
        canvas.drawCircle(x + sway * 0.45f, y - 55f * scale,
                3.2f * scale * flameScale, paint);
    }

    private void drawProjectiles(Canvas canvas) {
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        for (Projectile projectile : projectiles) {
            float dirX = projectile.angleX == 0f ? (projectile.playerSide ? 1f : -1f) : projectile.angleX;
            float dirY = projectile.angleY;
            if (projectile.kind == PROJECTILE_SPEAR) {
                stroke.setStrokeWidth(7f * uiScale);
                stroke.setColor(Color.argb(46, 255, 206, 113));
                canvas.drawLine(projectile.previousX, projectile.previousY,
                        projectile.x, projectile.y, stroke);
                stroke.setStrokeWidth(3.8f * uiScale);
                stroke.setColor(Color.rgb(126, 83, 43));
                canvas.drawLine(projectile.x - dirX * 31f * uiScale,
                        projectile.y - dirY * 31f * uiScale,
                        projectile.x + dirX * 17f * uiScale,
                        projectile.y + dirY * 17f * uiScale, stroke);
                Path head = new Path();
                float tipX = projectile.x + dirX * 25f * uiScale;
                float tipY = projectile.y + dirY * 25f * uiScale;
                float sideX = -dirY * 7f * uiScale;
                float sideY = dirX * 7f * uiScale;
                head.moveTo(tipX, tipY);
                head.lineTo(projectile.x + dirX * 11f * uiScale + sideX,
                        projectile.y + dirY * 11f * uiScale + sideY);
                head.lineTo(projectile.x + dirX * 11f * uiScale - sideX,
                        projectile.y + dirY * 11f * uiScale - sideY);
                head.close();
                paint.setColor(Color.rgb(224, 229, 234));
                canvas.drawPath(head, paint);
            } else {
                stroke.setStrokeWidth(5.5f * uiScale);
                stroke.setColor(Color.argb(42,
                        projectile.playerSide ? 92 : 255,
                        projectile.playerSide ? 174 : 102,
                        projectile.playerSide ? 255 : 89));
                canvas.drawLine(projectile.previousX, projectile.previousY, projectile.x, projectile.y, stroke);
                stroke.setStrokeWidth(2.2f * uiScale);
                stroke.setColor(Color.rgb(221, 224, 226));
                canvas.drawLine(projectile.x - dirX * 16f * uiScale, projectile.y - dirY * 16f * uiScale,
                        projectile.x + dirX * 8f * uiScale, projectile.y + dirY * 8f * uiScale, stroke);
                stroke.setStrokeWidth(1.6f * uiScale);
                stroke.setColor(Color.rgb(145, 89, 43));
                canvas.drawLine(projectile.x - dirX * 20f * uiScale, projectile.y - dirY * 20f * uiScale,
                        projectile.x - dirX * 8f * uiScale, projectile.y - dirY * 8f * uiScale, stroke);
            }
        }
    }

    private void drawImpacts(Canvas canvas) {
        stroke.setStyle(Paint.Style.STROKE);
        for (Impact impact : impacts) {
            float progress = 1f - impact.life / impact.maxLife;
            int alpha = (int) (220f * (1f - progress));
            int color = Color.argb(Math.max(0, alpha), Color.red(impact.color), Color.green(impact.color), Color.blue(impact.color));
            stroke.setColor(color);
            stroke.setStrokeWidth(3f * (1f - progress * 0.5f));
            float radius = 7f + progress * 20f;
            canvas.drawCircle(impact.x, impact.y, radius, stroke);
            for (int i = 0; i < 6; i++) {
                double angle = i * Math.PI / 3.0;
                float sx = impact.x + (float) Math.cos(angle) * radius * 0.45f;
                float sy = impact.y + (float) Math.sin(angle) * radius * 0.45f;
                float ex = impact.x + (float) Math.cos(angle) * radius * 1.15f;
                float ey = impact.y + (float) Math.sin(angle) * radius * 1.15f;
                canvas.drawLine(sx, sy, ex, ey, stroke);
            }
        }
    }

    private void drawFloatingTexts(Canvas canvas) {
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(16f, height * 0.027f));
        for (FloatingText text : floatingTexts) {
            float ratio = Math.max(0f, text.life / text.maxLife);
            int alpha = (int) (255f * Math.min(1f, ratio * 1.5f));
            paint.setColor(Color.argb(alpha, Color.red(text.color), Color.green(text.color), Color.blue(text.color)));
            paint.setShadowLayer(4f, 0f, 2f, Color.BLACK);
            canvas.drawText(text.value, text.x, text.y, paint);
            paint.clearShadowLayer();
        }
    }

    private void drawParticles(Canvas canvas, boolean behindUnits) {
        for (Particle particle : particles) {
            boolean isBehind = particle.kind == Particle.KIND_DUST || particle.kind == Particle.KIND_SMOKE;
            if (isBehind != behindUnits) continue;
            float ratio = Math.max(0f, particle.life / particle.maxLife);
            int alpha;
            if (particle.kind == Particle.KIND_SMOKE) {
                alpha = (int) (105f * Math.min(1f, ratio * 1.4f));
            } else if (particle.kind == Particle.KIND_DUST) {
                alpha = (int) (95f * ratio);
            } else {
                alpha = (int) (235f * ratio);
            }
            int color = Color.argb(Math.max(0, Math.min(255, alpha)),
                    Color.red(particle.color), Color.green(particle.color), Color.blue(particle.color));
            paint.setColor(color);
            if (particle.kind == Particle.KIND_DEBRIS) {
                canvas.save();
                canvas.rotate(particle.rotation, particle.x, particle.y);
                float s = particle.size;
                canvas.drawRect(particle.x - s * 0.65f, particle.y - s * 0.35f,
                        particle.x + s * 0.65f, particle.y + s * 0.35f, paint);
                canvas.restore();
            } else if (particle.kind == Particle.KIND_SPARK) {
                stroke.setStyle(Paint.Style.STROKE);
                stroke.setStrokeCap(Paint.Cap.ROUND);
                stroke.setStrokeWidth(Math.max(1.4f, particle.size * 0.55f));
                stroke.setColor(color);
                canvas.drawLine(particle.x, particle.y,
                        particle.x - particle.vx * 0.035f,
                        particle.y - particle.vy * 0.035f, stroke);
            } else {
                canvas.drawCircle(particle.x, particle.y,
                        particle.size * (0.62f + (1f - ratio) * 0.48f), paint);
            }
        }
    }

    private void drawDeathEffects(Canvas canvas) {
        for (DeathEffect effect : deathEffects) {
            float ratio = Math.max(0f, effect.life / effect.maxLife);
            int alpha = (int) (210f * Math.min(1f, ratio * 1.35f));
            float scale = Math.max(0.78f, Math.min(1.18f, height / 620f));
            int enemyAccent = enemyAccentColorLocked();
            float teamR = effect.playerSide ? 63f : Color.red(enemyAccent);
            float teamG = effect.playerSide ? 142f : Color.green(enemyAccent);
            float teamB = effect.playerSide ? 222f : Color.blue(enemyAccent);
            int team = Color.argb(alpha, (int) teamR, (int) teamG, (int) teamB);
            int armor = Color.argb(alpha, 59, 64, 72);
            canvas.save();
            canvas.rotate(effect.rotation, effect.x, effect.y);
            paint.setColor(Color.argb((int) (70f * ratio), 0, 0, 0));
            canvas.drawOval(new RectF(effect.x - 30f * scale, effect.y - 4f,
                    effect.x + 30f * scale, effect.y + 7f), paint);
            paint.setColor(armor);
            canvas.drawRoundRect(new RectF(effect.x - 28f * scale, effect.y - 16f * scale,
                    effect.x + 20f * scale, effect.y + 1f * scale), 7f * scale, 7f * scale, paint);
            paint.setColor(team);
            canvas.drawRect(effect.x - 18f * scale, effect.y - 12f * scale,
                    effect.x + 10f * scale, effect.y - 6f * scale, paint);
            paint.setColor(Color.argb(alpha, 148, 153, 161));
            canvas.drawCircle(effect.x - 19f * scale, effect.y - 14f * scale, 8f * scale, paint);
            if (effect.type == UnitType.SWORD) {
                stroke.setStyle(Paint.Style.STROKE);
                stroke.setStrokeWidth(3f * scale);
                stroke.setColor(Color.argb(alpha, 221, 224, 229));
                canvas.drawLine(effect.x + 7f * scale, effect.y - 13f * scale,
                        effect.x + 39f * scale, effect.y - 2f * scale, stroke);
                paint.setColor(team);
                canvas.drawOval(new RectF(effect.x - 41f * scale, effect.y - 20f * scale,
                        effect.x - 21f * scale, effect.y + 5f * scale), paint);
            } else if (effect.type == UnitType.SPEAR) {
                stroke.setStyle(Paint.Style.STROKE);
                stroke.setStrokeWidth(3f * scale);
                stroke.setColor(Color.argb(alpha, 130, 87, 47));
                canvas.drawLine(effect.x - 18f * scale, effect.y - 18f * scale,
                        effect.x + 48f * scale, effect.y + 4f * scale, stroke);
                paint.setColor(Color.argb(alpha, 225, 230, 235));
                Path brokenSpearHead = new Path();
                brokenSpearHead.moveTo(effect.x + 54f * scale, effect.y + 6f * scale);
                brokenSpearHead.lineTo(effect.x + 41f * scale, effect.y - 2f * scale);
                brokenSpearHead.lineTo(effect.x + 43f * scale, effect.y + 10f * scale);
                brokenSpearHead.close();
                canvas.drawPath(brokenSpearHead, paint);
            } else if (effect.type == UnitType.ARCHER) {
                stroke.setStyle(Paint.Style.STROKE);
                stroke.setStrokeWidth(2.4f * scale);
                stroke.setColor(Color.argb(alpha, 178, 119, 60));
                canvas.drawArc(new RectF(effect.x + 5f * scale, effect.y - 24f * scale,
                        effect.x + 40f * scale, effect.y + 11f * scale), -70f, 145f, false, stroke);
            }
            canvas.restore();
            paint.setColor(Color.argb((int) (48f * ratio), 134, 116, 88));
            canvas.drawOval(new RectF(effect.x - 34f * scale, effect.groundY - 4f * scale,
                    effect.x + 34f * scale, effect.groundY + 6f * scale), paint);
        }
    }

    private void drawWaveBanner(Canvas canvas) {
        float progress = 1f - waveBannerTimer / 2.4f;
        float fadeIn = Math.min(1f, progress / 0.18f);
        float fadeOut = Math.min(1f, waveBannerTimer / 0.45f);
        float alpha = Math.max(0f, Math.min(fadeIn, fadeOut));
        float bannerW = Math.min(width * 0.46f, 520f);
        float bannerH = Math.max(62f, height * 0.105f);
        float y = height * 0.17f + (1f - fadeIn) * -22f;
        RectF banner = new RectF(width / 2f - bannerW / 2f, y,
                width / 2f + bannerW / 2f, y + bannerH);
        paint.setColor(Color.argb((int) (205f * alpha), 10, 17, 30));
        canvas.drawRoundRect(banner, 17f, 17f, paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(2.4f);
        stroke.setColor(Color.argb((int) (230f * alpha), 226, 173, 62));
        canvas.drawRoundRect(banner, 17f, 17f, stroke);
        drawCrossedSwords(canvas, banner.left + 42f, banner.centerY(), 18f,
                Color.argb((int) (255f * alpha), 226, 173, 62));
        drawCrossedSwords(canvas, banner.right - 42f, banner.centerY(), 18f,
                Color.argb((int) (255f * alpha), 226, 173, 62));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(Math.max(25f, bannerH * 0.47f));
        paint.setColor(Color.argb((int) (255f * alpha), 255, 216, 112));
        paint.setShadowLayer(6f, 0f, 3f, Color.BLACK);
        canvas.drawText("DALGA " + wave, banner.centerX(), banner.centerY() + paint.getTextSize() * 0.34f, paint);
        paint.clearShadowLayer();
    }

    private void drawStatue(Canvas canvas, float x, float y, boolean player, float hp) {
        // v0.3.1: Heykel ve üs tabanı daha anıtsal, daha gerçekçi ve hasarı daha okunaklı.
        int accent = player ? BLUE : enemyAccentColorLocked();
        float dir = player ? 1f : -1f;
        float scale = Math.max(1.13f, Math.min(tabletLayout ? 2.18f : 1.68f, height / 545f));
        float maxHp = player ? playerStatueMaxHp() : enemyStatueMaxHp();
        float hpRatio = Math.max(0f, Math.min(1f, hp / maxHp));
        int damageStage = hpRatio < 0.28f ? 3 : hpRatio < 0.55f ? 2 : hpRatio < 0.78f ? 1 : 0;
        boolean flashing = player ? playerBaseFlash > 0f : enemyBaseFlash > 0f;

        float pedestalW = 186f * scale;
        float pedestalH = 64f * scale;
        float bodyBaseY = y - pedestalH * 1.34f;
        float statueTop = bodyBaseY - 214f * scale;

        paint.setColor(Color.argb(118, 0, 0, 0));
        canvas.drawOval(new RectF(x - pedestalW * 0.76f, y - 12f,
                x + pedestalW * 0.76f, y + 14f), paint);

        // Alt üs kaya platformu.
        paint.setShader(new LinearGradient(x - pedestalW * 0.75f, y - pedestalH * 0.30f,
                x + pedestalW * 0.75f, y + 8f * scale,
                Color.rgb(78, 69, 61), Color.rgb(31, 28, 27), Shader.TileMode.CLAMP));
        RectF basePlatform = new RectF(x - pedestalW * 0.74f, y - pedestalH * 0.30f,
                x + pedestalW * 0.74f, y + 8f * scale);
        canvas.drawRoundRect(basePlatform, 10f * scale, 10f * scale, paint);
        paint.setShader(null);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(2.2f * scale);
        stroke.setColor(Color.argb(160, 32, 24, 16));
        canvas.drawRoundRect(basePlatform, 10f * scale, 10f * scale, stroke);

        // Ana taş kaide.
        paint.setShader(new LinearGradient(x - pedestalW / 2f, y - pedestalH,
                x + pedestalW / 2f, y,
                flashing ? Color.rgb(224, 219, 205) : Color.rgb(126, 129, 134),
                flashing ? Color.rgb(135, 124, 111) : Color.rgb(46, 50, 57), Shader.TileMode.CLAMP));
        RectF pedestal = new RectF(x - pedestalW / 2f, y - pedestalH,
                x + pedestalW / 2f, y);
        canvas.drawRoundRect(pedestal, 9f * scale, 9f * scale, paint);
        paint.setShader(null);
        paint.setColor(Color.rgb(74, 78, 85));
        canvas.drawRect(x - pedestalW * 0.63f, y - pedestalH * 1.39f,
                x + pedestalW * 0.63f, y - pedestalH, paint);
        paint.setColor(Color.rgb(36, 40, 46));
        canvas.drawRect(x - pedestalW * 0.73f, y - pedestalH * 0.22f,
                x + pedestalW * 0.73f, y + 2f * scale, paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(2.5f * scale);
        stroke.setColor(GOLD);
        canvas.drawRoundRect(pedestal, 9f * scale, 9f * scale, stroke);
        canvas.drawLine(x - pedestalW * 0.55f, y - pedestalH * 1.10f,
                x + pedestalW * 0.55f, y - pedestalH * 1.10f, stroke);
        canvas.drawLine(x - pedestalW * 0.55f, y - pedestalH * 0.42f,
                x + pedestalW * 0.55f, y - pedestalH * 0.42f, stroke);

        // Yan destek kuleleri.
        for (int side = -1; side <= 1; side += 2) {
            float sx = x + side * pedestalW * 0.62f;
            paint.setShader(new LinearGradient(sx - 12f * scale, y - pedestalH * 1.22f,
                    sx + 12f * scale, y - pedestalH * 0.10f,
                    Color.rgb(108, 112, 118), Color.rgb(50, 56, 64), Shader.TileMode.CLAMP));
            RectF pillar = new RectF(sx - 12f * scale, y - pedestalH * 1.22f,
                    sx + 12f * scale, y - pedestalH * 0.10f);
            canvas.drawRoundRect(pillar, 4f * scale, 4f * scale, paint);
            paint.setShader(null);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(1.6f * scale);
            stroke.setColor(Color.argb(120, 214, 181, 110));
            canvas.drawRoundRect(pillar, 4f * scale, 4f * scale, stroke);
            paint.setColor(Color.argb(190, Color.red(accent), Color.green(accent), Color.blue(accent)));
            canvas.drawCircle(sx, y - pedestalH * 0.90f, 4f * scale, paint);
        }

        int stoneLight = flashing ? Color.WHITE : Color.rgb(157, 160, 164);
        int stoneMid = flashing ? Color.rgb(228, 225, 214) : Color.rgb(111, 116, 123);
        int stoneDark = Color.rgb(58, 63, 72);
        int stoneDeep = Color.rgb(36, 40, 47);

        // Pelerin ve bacaklar heykelin siluetini ağırlaştırır.
        paint.setColor(stoneDeep);
        Path cape = new Path();
        cape.moveTo(x - dir * 12f * scale, bodyBaseY - 142f * scale);
        cape.lineTo(x - dir * 72f * scale, bodyBaseY - 22f * scale);
        cape.lineTo(x + dir * 34f * scale, bodyBaseY - 36f * scale);
        cape.lineTo(x + dir * 28f * scale, bodyBaseY - 132f * scale);
        cape.close();
        canvas.drawPath(cape, paint);
        paint.setColor(stoneMid);
        Path leftLeg = new Path();
        leftLeg.moveTo(x - 30f * scale, bodyBaseY - 66f * scale);
        leftLeg.lineTo(x - 7f * scale, bodyBaseY - 67f * scale);
        leftLeg.lineTo(x - 12f * scale, bodyBaseY + 2f * scale);
        leftLeg.lineTo(x - 43f * scale, bodyBaseY + 2f * scale);
        leftLeg.close();
        canvas.drawPath(leftLeg, paint);
        Path rightLeg = new Path();
        rightLeg.moveTo(x + 7f * scale, bodyBaseY - 67f * scale);
        rightLeg.lineTo(x + 31f * scale, bodyBaseY - 65f * scale);
        rightLeg.lineTo(x + 43f * scale, bodyBaseY + 2f * scale);
        rightLeg.lineTo(x + 12f * scale, bodyBaseY + 2f * scale);
        rightLeg.close();
        canvas.drawPath(rightLeg, paint);
        paint.setColor(stoneDark);
        canvas.drawRoundRect(new RectF(x - 49f * scale, bodyBaseY - 4f * scale,
                x - 8f * scale, bodyBaseY + 11f * scale), 5f * scale, 5f * scale, paint);
        canvas.drawRoundRect(new RectF(x + 8f * scale, bodyBaseY - 4f * scale,
                x + 49f * scale, bodyBaseY + 11f * scale), 5f * scale, 5f * scale, paint);

        // Göğüs zırhı, omuz plakaları ve oyma kemer.
        paint.setShader(new LinearGradient(x - 42f * scale, bodyBaseY - 150f * scale,
                x + 42f * scale, bodyBaseY - 55f * scale,
                stoneLight, stoneDark, Shader.TileMode.CLAMP));
        Path torso = new Path();
        torso.moveTo(x - 39f * scale, bodyBaseY - 151f * scale);
        torso.lineTo(x + 39f * scale, bodyBaseY - 151f * scale);
        torso.lineTo(x + 31f * scale, bodyBaseY - 67f * scale);
        torso.lineTo(x, bodyBaseY - 52f * scale);
        torso.lineTo(x - 31f * scale, bodyBaseY - 67f * scale);
        torso.close();
        canvas.drawPath(torso, paint);
        paint.setShader(null);
        paint.setColor(stoneLight);
        canvas.drawOval(new RectF(x - 55f * scale, bodyBaseY - 158f * scale,
                x - 20f * scale, bodyBaseY - 119f * scale), paint);
        canvas.drawOval(new RectF(x + 20f * scale, bodyBaseY - 158f * scale,
                x + 55f * scale, bodyBaseY - 119f * scale), paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3f * scale);
        stroke.setColor(stoneDark);
        canvas.drawLine(x, bodyBaseY - 145f * scale, x, bodyBaseY - 74f * scale, stroke);
        canvas.drawArc(new RectF(x - 27f * scale, bodyBaseY - 135f * scale,
                x + 27f * scale, bodyBaseY - 86f * scale), 200f, 140f, false, stroke);
        paint.setColor(accent);
        canvas.drawRect(x - 37f * scale, bodyBaseY - 77f * scale,
                x + 37f * scale, bodyBaseY - 66f * scale, paint);
        drawCrown(canvas, x, bodyBaseY - 110f * scale, 11f * scale, Color.argb(210, 226, 173, 62));

        // Boyun, yüz hatları ve sorguçlu miğfer.
        paint.setColor(stoneMid);
        canvas.drawRoundRect(new RectF(x - 15f * scale, bodyBaseY - 176f * scale,
                x + 15f * scale, bodyBaseY - 143f * scale), 5f * scale, 5f * scale, paint);
        paint.setColor(stoneLight);
        canvas.drawOval(new RectF(x - 31f * scale, bodyBaseY - 222f * scale,
                x + 31f * scale, bodyBaseY - 166f * scale), paint);
        paint.setColor(stoneDark);
        Path helmet = new Path();
        helmet.moveTo(x - 36f * scale, bodyBaseY - 195f * scale);
        helmet.cubicTo(x - 18f * scale, bodyBaseY - 242f * scale,
                x + 18f * scale, bodyBaseY - 242f * scale,
                x + 36f * scale, bodyBaseY - 195f * scale);
        helmet.lineTo(x + 29f * scale, bodyBaseY - 180f * scale);
        helmet.lineTo(x - 29f * scale, bodyBaseY - 180f * scale);
        helmet.close();
        canvas.drawPath(helmet, paint);
        paint.setColor(accent);
        canvas.drawRect(x - 31f * scale, bodyBaseY - 193f * scale,
                x + 31f * scale, bodyBaseY - 184f * scale, paint);
        paint.setColor(stoneDeep);
        canvas.drawRect(x - 20f * scale, bodyBaseY - 190f * scale,
                x + 20f * scale, bodyBaseY - 184f * scale, paint);
        canvas.drawRect(x - 4f * scale, bodyBaseY - 184f * scale,
                x + 4f * scale, bodyBaseY - 169f * scale, paint);
        paint.setColor(Color.rgb(34, 36, 41));
        canvas.drawCircle(x - 9f * scale, bodyBaseY - 177f * scale, 2.8f * scale, paint);
        canvas.drawCircle(x + 9f * scale, bodyBaseY - 177f * scale, 2.8f * scale, paint);
        stroke.setColor(stoneDark);
        stroke.setStrokeWidth(2f * scale);
        canvas.drawLine(x - 10f * scale, bodyBaseY - 164f * scale,
                x + 10f * scale, bodyBaseY - 164f * scale, stroke);
        paint.setColor(accent);
        Path plume = new Path();
        plume.moveTo(x - dir * 3f * scale, bodyBaseY - 238f * scale);
        plume.cubicTo(x - dir * 12f * scale, bodyBaseY - 278f * scale,
                x - dir * 57f * scale, bodyBaseY - 274f * scale,
                x - dir * 43f * scale, bodyBaseY - 236f * scale);
        plume.cubicTo(x - dir * 31f * scale, bodyBaseY - 251f * scale,
                x - dir * 14f * scale, bodyBaseY - 250f * scale,
                x - dir * 3f * scale, bodyBaseY - 238f * scale);
        plume.close();
        canvas.drawPath(plume, paint);

        // Sol kol ve kabartmalı kalkan.
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeWidth(15f * scale);
        stroke.setColor(stoneMid);
        canvas.drawLine(x - dir * 31f * scale, bodyBaseY - 137f * scale,
                x - dir * 67f * scale, bodyBaseY - 91f * scale, stroke);
        paint.setShader(new RadialGradient(x - dir * 72f * scale, bodyBaseY - 68f * scale,
                42f * scale, new int[]{stoneLight, stoneDark},
                new float[]{0f, 1f}, Shader.TileMode.CLAMP));
        RectF shield = new RectF(x - dir * 75f * scale - 34f * scale,
                bodyBaseY - 113f * scale, x - dir * 75f * scale + 34f * scale,
                bodyBaseY - 24f * scale);
        canvas.drawOval(shield, paint);
        paint.setShader(null);
        stroke.setStrokeWidth(4f * scale);
        stroke.setColor(GOLD);
        canvas.drawOval(shield, stroke);
        paint.setColor(accent);
        Path shieldMark = new Path();
        shieldMark.moveTo(shield.centerX(), shield.top + 13f * scale);
        shieldMark.lineTo(shield.right - 13f * scale, shield.centerY());
        shieldMark.lineTo(shield.centerX(), shield.bottom - 12f * scale);
        shieldMark.lineTo(shield.left + 13f * scale, shield.centerY());
        shieldMark.close();
        canvas.drawPath(shieldMark, paint);
        drawCrown(canvas, shield.centerX(), shield.centerY(), 12f * scale, GOLD_LIGHT);

        // Sağ kol ve ışık çizgili uzun kılıç.
        stroke.setStrokeWidth(15f * scale);
        stroke.setColor(stoneMid);
        canvas.drawLine(x + dir * 31f * scale, bodyBaseY - 139f * scale,
                x + dir * 61f * scale, bodyBaseY - 205f * scale, stroke);
        stroke.setStrokeWidth(11f * scale);
        stroke.setColor(Color.rgb(90, 68, 48));
        canvas.drawLine(x + dir * 56f * scale, bodyBaseY - 194f * scale,
                x + dir * 70f * scale, bodyBaseY - 225f * scale, stroke);
        stroke.setStrokeWidth(10f * scale);
        stroke.setColor(Color.rgb(188, 193, 201));
        canvas.drawLine(x + dir * 70f * scale, bodyBaseY - 225f * scale,
                x + dir * 101f * scale, statueTop, stroke);
        stroke.setStrokeWidth(3f * scale);
        stroke.setColor(Color.rgb(238, 241, 244));
        canvas.drawLine(x + dir * 73f * scale, bodyBaseY - 226f * scale,
                x + dir * 98f * scale, statueTop + 5f * scale, stroke);
        stroke.setStrokeWidth(5f * scale);
        stroke.setColor(GOLD);
        canvas.drawLine(x + dir * 52f * scale, bodyBaseY - 214f * scale,
                x + dir * 82f * scale, bodyBaseY - 199f * scale, stroke);

        int shownLevel = player ? statueUpgradeLevel : Math.max(1, 1 + (battleLevel - 1) / 2);
        paint.setColor(Color.rgb(17, 23, 34));
        canvas.drawCircle(x, y - pedestalH * 0.68f, 21f * scale, paint);
        stroke.setStrokeWidth(2f * scale);
        stroke.setColor(GOLD);
        canvas.drawCircle(x, y - pedestalH * 0.68f, 21f * scale, stroke);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(16f * scale);
        paint.setColor(GOLD_LIGHT);
        canvas.drawText("SV " + shownLevel, x, y - pedestalH * 0.68f + 6f * scale, paint);

        drawProfessionalStatueDetails(canvas, x, y, scale, bodyBaseY, player, accent, stoneLight, stoneDark);
        if (damageStage > 0) drawStatueCracks(canvas, x, y, scale, damageStage);
        drawHealthBar(canvas, x - 86f * scale, statueTop - 25f * scale,
                172f * scale, hpRatio, accent, true);
    }

    private void drawProfessionalStatueDetails(Canvas canvas, float x, float y, float scale,
                                                float bodyBaseY, boolean player, int accent,
                                                int stoneLight, int stoneDark) {
        float dir = player ? 1f : -1f;

        // Yüz detayları.
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeWidth(2.2f * scale);
        stroke.setColor(Color.argb(180, 45, 49, 57));
        canvas.drawLine(x - 18f * scale, bodyBaseY - 181f * scale,
                x - 5f * scale, bodyBaseY - 184f * scale, stroke);
        canvas.drawLine(x + 5f * scale, bodyBaseY - 184f * scale,
                x + 18f * scale, bodyBaseY - 181f * scale, stroke);
        Path nose = new Path();
        nose.moveTo(x, bodyBaseY - 181f * scale);
        nose.lineTo(x - 3f * scale, bodyBaseY - 169f * scale);
        nose.lineTo(x + 4f * scale, bodyBaseY - 168f * scale);
        canvas.drawPath(nose, stroke);
        canvas.drawArc(new RectF(x - 15f * scale, bodyBaseY - 173f * scale,
                x + 15f * scale, bodyBaseY - 154f * scale), 20f, 140f, false, stroke);

        // Göğüs zırhı katmanları.
        stroke.setStrokeWidth(2.5f * scale);
        stroke.setColor(Color.argb(175, 205, 210, 216));
        canvas.drawArc(new RectF(x - 33f * scale, bodyBaseY - 139f * scale,
                x + 33f * scale, bodyBaseY - 92f * scale), 205f, 130f, false, stroke);
        canvas.drawLine(x - 25f * scale, bodyBaseY - 97f * scale,
                x + 25f * scale, bodyBaseY - 97f * scale, stroke);
        for (int i = 0; i < 4; i++) {
            float plateTop = bodyBaseY - (67f - i * 10f) * scale;
            paint.setColor(i % 2 == 0 ? Color.argb(205, 82, 88, 98)
                    : Color.argb(205, 64, 70, 80));
            Path plate = new Path();
            plate.moveTo(x - (31f - i * 2f) * scale, plateTop);
            plate.lineTo(x + (31f - i * 2f) * scale, plateTop);
            plate.lineTo(x + (25f - i * 2f) * scale, plateTop + 13f * scale);
            plate.lineTo(x - (25f - i * 2f) * scale, plateTop + 13f * scale);
            plate.close();
            canvas.drawPath(plate, paint);
        }

        // Omuz perçinleri ve parıltı.
        paint.setColor(GOLD_LIGHT);
        for (int side = -1; side <= 1; side += 2) {
            canvas.drawCircle(x + side * 38f * scale, bodyBaseY - 140f * scale, 3.5f * scale, paint);
            canvas.drawCircle(x + side * 47f * scale, bodyBaseY - 132f * scale, 2.6f * scale, paint);
        }
        stroke.setStrokeWidth(2.2f * scale);
        stroke.setColor(Color.argb(180, 238, 241, 244));
        canvas.drawLine(x - 29f * scale, bodyBaseY - 151f * scale,
                x - 18f * scale, bodyBaseY - 76f * scale, stroke);

        // Pelerin kıvrımları.
        stroke.setStrokeWidth(2.3f * scale);
        stroke.setColor(Color.argb(150, 154, 158, 166));
        canvas.drawLine(x - dir * 24f * scale, bodyBaseY - 125f * scale,
                x - dir * 52f * scale, bodyBaseY - 38f * scale, stroke);
        canvas.drawLine(x - dir * 8f * scale, bodyBaseY - 123f * scale,
                x - dir * 28f * scale, bodyBaseY - 34f * scale, stroke);

        // Üs plakası ve isim.
        RectF plaque = new RectF(x - 62f * scale, y - 50f * scale,
                x + 62f * scale, y - 20f * scale);
        paint.setColor(Color.rgb(29, 34, 42));
        canvas.drawRoundRect(plaque, 5f * scale, 5f * scale, paint);
        stroke.setStrokeWidth(1.8f * scale);
        stroke.setColor(GOLD);
        canvas.drawRoundRect(plaque, 5f * scale, 5f * scale, stroke);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(11f * scale);
        paint.setColor(Color.rgb(231, 224, 203));
        canvas.drawText(player ? "UYGAR MUHAFIZI" : enemyStatueTitleLocked(),
                x, plaque.centerY() + 4f * scale, paint);

        // Yan sancaklar ve zincirler.
        for (int side = -1; side <= 1; side += 2) {
            float px = x + side * 82f * scale;
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(3f * scale);
            stroke.setColor(Color.rgb(81, 63, 42));
            canvas.drawLine(px, y - 86f * scale, px, y - 24f * scale, stroke);
            Path flag = new Path();
            flag.moveTo(px, y - 84f * scale);
            flag.lineTo(px + side * 28f * scale, y - 74f * scale);
            flag.lineTo(px + side * 10f * scale, y - 55f * scale);
            flag.lineTo(px + side * 28f * scale, y - 37f * scale);
            flag.lineTo(px, y - 42f * scale);
            flag.close();
            paint.setColor(Color.argb(210, Color.red(accent), Color.green(accent), Color.blue(accent)));
            canvas.drawPath(flag, paint);
            stroke.setStrokeWidth(1.3f * scale);
            stroke.setColor(Color.argb(160, 210, 210, 210));
            canvas.drawLine(x + side * 42f * scale, y - 68f * scale,
                    px, y - 56f * scale, stroke);
        }

        // Ön tarafta enerji/rün oyması.
        paint.setColor(Color.argb(195, Color.red(accent), Color.green(accent), Color.blue(accent)));
        canvas.drawCircle(x, bodyBaseY - 211f * scale, 4f * scale, paint);
        stroke.setStrokeWidth(2f * scale);
        stroke.setColor(Color.argb(190, Color.red(accent), Color.green(accent), Color.blue(accent)));
        canvas.drawLine(x + dir * 77f * scale, bodyBaseY - 234f * scale,
                x + dir * 96f * scale, bodyBaseY - 270f * scale, stroke);

        paint.setColor(Color.argb(120, 240, 230, 205));
        Path rune = new Path();
        rune.moveTo(x, y - 92f * scale);
        rune.lineTo(x + 13f * scale, y - 79f * scale);
        rune.lineTo(x, y - 66f * scale);
        rune.lineTo(x - 13f * scale, y - 79f * scale);
        rune.close();
        canvas.drawPath(rune, paint);
    }

    private String enemyStatueTitleLocked() {
        int chapter = chapterForLevelLocked(battleLevel);
        if (chapter == 2) return "KIZIL FATİH";
        if (chapter == 3) return "BUZ NÖBETÇİSİ";
        if (chapter == 4) return "KÜL HÜKÜMDARI";
        if (chapter == 5) return "GÖLGE HAKANI";
        return "DEMİR FATİH";
    }

    private void drawStatueCracks(Canvas canvas, float x, float y, float scale, int stage) {
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.SQUARE);
        stroke.setStrokeWidth(Math.max(1.6f, 2.4f * scale));
        stroke.setColor(Color.argb(220, 28, 29, 32));
        for (int i = 0; i < 2 + stage * 2; i++) {
            float sx = x - 48f * scale + i * 17f * scale;
            float sy = y - (68f + (i % 3) * 31f) * scale;
            Path crack = new Path();
            crack.moveTo(sx, sy);
            crack.lineTo(sx + ((i % 2 == 0) ? 8f : -8f) * scale, sy + 13f * scale);
            crack.lineTo(sx + ((i % 2 == 0) ? 2f : -2f) * scale, sy + 28f * scale);
            if (stage >= 2) crack.lineTo(sx + ((i % 2 == 0) ? 12f : -12f) * scale, sy + 44f * scale);
            canvas.drawPath(crack, stroke);
        }
        paint.setColor(Color.argb(175, 70, 66, 61));
        for (int i = 0; i < 4 + stage * 2; i++) {
            float rx = x - 58f * scale + i * 18f * scale;
            float ry = y - 8f * scale + (i % 2) * 4f * scale;
            canvas.drawOval(new RectF(rx, ry, rx + (4f + (i % 3) * 2f) * scale,
                    ry + (2.5f + (i % 2)) * scale), paint);
        }
    }

    private void drawCastleCracks(Canvas canvas, float x, float y, float bodyW, float bodyH,
                                  float scale, int stage) {
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.SQUARE);
        stroke.setStrokeWidth(Math.max(1.4f, 2.1f * scale));
        stroke.setColor(Color.argb(210, 22, 24, 28));
        int crackCount = 2 + stage * 2;
        for (int i = 0; i < crackCount; i++) {
            float startX = x - bodyW * 0.38f + (i * 0.17f + 0.05f) * bodyW;
            float startY = y - bodyH * (0.82f - (i % 3) * 0.16f);
            Path crack = new Path();
            crack.moveTo(startX, startY);
            crack.lineTo(startX + ((i % 2 == 0) ? 8f : -8f) * scale, startY + 13f * scale);
            crack.lineTo(startX + ((i % 2 == 0) ? 2f : -2f) * scale, startY + 26f * scale);
            crack.lineTo(startX + ((i % 2 == 0) ? 12f : -12f) * scale, startY + 39f * scale);
            canvas.drawPath(crack, stroke);
        }
        stroke.setStrokeCap(Paint.Cap.ROUND);
    }

    private void drawBattlements(Canvas canvas, float left, float right, float top, float scale, int color) {
        paint.setColor(color);
        float block = 12f * scale;
        for (float bx = left; bx < right; bx += block * 1.7f) {
            canvas.drawRect(bx, top - block, Math.min(right, bx + block), top + 2f, paint);
        }
    }

    private void drawUnit(Canvas canvas, Unit unit, boolean playerSide) {
        if (unit.siege) {
            drawSiegeRam(canvas, unit, playerSide);
            return;
        }
        float scale = Math.max(1.34f, Math.min(tabletLayout ? 2.24f : 1.82f, height / 475f));
        scale *= unit.lane < 0 ? 0.92f : unit.lane > 0 ? 1.07f : 1f;
        scale *= unit.visualScale;
        float x = unit.x;
        float y = groundY + laneOffset(unit.lane);
        int teamColor = playerSide ? BLUE : enemyAccentColorLocked();
        int darkTeam = playerSide ? Color.rgb(25, 60, 102) : Color.rgb(92, 28, 30);
        int bodyColor = unit.hitFlash > 0f ? Color.WHITE : Color.rgb(38, 42, 49);
        int outfitTier = playerSide ? equippedOutfitLevelLocked(unit.type) : 0;
        if (unit.hero && unit.hitFlash <= 0f) {
            bodyColor = Color.rgb(71, 82, 104);
            teamColor = GOLD_LIGHT;
            darkTeam = Color.rgb(31, 48, 78);
            outfitTier = 0;
        }
        if (playerSide && unit.hitFlash <= 0f && !unit.hero) {
            if (outfitTier == 1) {
                bodyColor = Color.rgb(95, 106, 120);
                teamColor = Color.rgb(121, 190, 244);
                darkTeam = Color.rgb(42, 70, 92);
            } else if (outfitTier == 2) {
                bodyColor = Color.rgb(53, 68, 92);
                teamColor = GOLD_LIGHT;
                darkTeam = Color.rgb(35, 46, 71);
            } else if (outfitTier >= 3) {
                bodyColor = Color.rgb(48, 37, 61);
                teamColor = Color.rgb(194, 112, 255);
                darkTeam = Color.rgb(31, 22, 43);
            }
        }
        float dir = playerSide ? 1f : -1f;
        float stepWave = unit.moving ? (float) Math.sin(unit.anim) : 0f;
        float footPlant = unit.moving ? Math.abs((float) Math.sin(unit.anim)) : 0f;
        float breath = !unit.moving && unit.attackAnim <= 0f
                ? (float) Math.sin(ambientClock * 2.1f + unit.formationSlot * 0.47f) * 1.1f * scale : 0f;
        float bob = unit.moving ? -footPlant * 3.2f * scale : breath;
        float attackDuration = unit.type == UnitType.ARCHER ? 0.44f
                : unit.type == UnitType.SPEAR ? 0.52f
                : unit.type == UnitType.SWORD ? 0.38f : 0.34f;
        float attackPhase = unit.attackAnim > 0f
                ? Math.max(0f, Math.min(1f, 1f - unit.attackAnim / attackDuration)) : 0f;
        float attackSwing = unit.attackAnim > 0f ? (float) Math.sin(attackPhase * Math.PI) : 0f;
        float recoilProgress = unit.hitRecoil > 0f ? 1f - unit.hitRecoil / 0.24f : 0f;
        float recoilX = unit.hitRecoil > 0f
                ? -dir * (float) Math.sin(recoilProgress * Math.PI) * 10f * scale : 0f;
        float attackLunge = unit.type == UnitType.SWORD ? dir * attackSwing * 6.5f * scale
                : unit.type == UnitType.SPEAR && !unit.rangedAttack ? dir * attackSwing * 8.5f * scale : 0f;
        float bodyLean = unit.moving ? -dir * stepWave * 3.0f
                : unit.attackAnim > 0f ? dir * (-5f + attackPhase * 10f) : 0f;
        x += recoilX + attackLunge;
        y += bob;

        if (unit.hero) {
            int heroAuraAlpha = 45 + (int) (22f * (0.5f + 0.5f * Math.sin(ambientClock * 4.2f)));
            paint.setColor(Color.argb(heroAuraAlpha, 255, 196, 76));
            canvas.drawCircle(x, y - 42f * scale, (44f + heroLeadershipLevel * 2f) * scale, paint);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(2.5f * scale);
            stroke.setColor(Color.argb(185, 255, 219, 119));
            canvas.drawCircle(x, y - 42f * scale, 39f * scale, stroke);
        }
        if (playerSide && warCryTimer > 0f && unit.type != UnitType.MINER) {
            int auraAlpha = 28 + (int) (18f * (0.5f + 0.5f * Math.sin(ambientClock * 7f + unit.anim)));
            paint.setColor(Color.argb(auraAlpha, 255, 195, 86));
            canvas.drawCircle(x, y - 37f * scale, 34f * scale, paint);
        }
        if (unit.boss) {
            int pulse = 74 + (int) (26f * (0.5f + 0.5f * Math.sin(ambientClock * 4.5f)));
            paint.setColor(Color.argb(pulse, 255, 49, 45));
            canvas.drawCircle(x, y - 43f * scale, 52f * scale, paint);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(3f * scale);
            stroke.setColor(Color.argb(190, 255, 171, 72));
            canvas.drawCircle(x, y - 43f * scale, 48f * scale, stroke);
        } else if (unit.commander) {
            paint.setColor(Color.argb(58, 255, 76, 64));
            canvas.drawCircle(x, y - 40f * scale, 39f * scale, paint);
        }
        paint.setColor(Color.argb(90, 0, 0, 0));
        canvas.drawOval(new RectF(x - 28f * scale, y - 5f, x + 28f * scale, y + 6f), paint);

        canvas.save();
        canvas.rotate(bodyLean, x, y - 38f * scale);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        if (unit.type == UnitType.MINER) {
            boolean mining = unit.minerState == MINER_MINING;
            float miningSwing = mining ? (float) Math.sin(unit.anim * 1.52f) * 0.96f : -0.18f;
            paint.setColor(Color.rgb(92, 65, 42));
            canvas.drawRoundRect(new RectF(x - 13f * scale, y - 48f * scale,
                    x + 13f * scale, y - 10f * scale), 6f * scale, 6f * scale, paint);
            paint.setColor(Color.rgb(214, 166, 97));
            canvas.drawCircle(x, y - 59f * scale, 13f * scale, paint);
            paint.setColor(Color.rgb(68, 52, 39));
            canvas.drawArc(new RectF(x - 15f * scale, y - 74f * scale,
                    x + 15f * scale, y - 50f * scale), 190f, 160f, true, paint);
            paint.setColor(GOLD);
            canvas.drawRect(x - 10f * scale, y - 48f * scale, x + 10f * scale, y - 43f * scale, paint);
            paint.setColor(Color.rgb(255, 236, 204));
            canvas.drawCircle(x - 4f * scale, y - 60f * scale, 1.7f * scale, paint);
            canvas.drawCircle(x + 4f * scale, y - 60f * scale, 1.7f * scale, paint);
            drawUnitArmorDetails(canvas, unit, x, y, scale, dir, teamColor, bodyColor, playerSide);
            stroke.setColor(bodyColor);
            stroke.setStrokeWidth(5f * scale);
            float walk = unit.moving ? (float) Math.sin(unit.anim) * 6f * scale : 0f;
            canvas.drawLine(x - 5f * scale, y - 13f * scale, x - 14f * scale + walk, y, stroke);
            canvas.drawLine(x + 5f * scale, y - 13f * scale, x + 14f * scale - walk, y, stroke);
            float toolX = x + (25f + miningSwing * 15f) * scale;
            float toolY = y - (56f - miningSwing * 17f) * scale;
            canvas.drawLine(x + 4f * scale, y - 38f * scale, toolX, toolY, stroke);
            stroke.setColor(Color.rgb(183, 138, 77));
            stroke.setStrokeWidth(4f * scale);
            canvas.drawLine(toolX - 5f * scale, toolY - 8f * scale,
                    toolX + 14f * scale, toolY + 8f * scale, stroke);
            canvas.drawLine(toolX - 5f * scale, toolY - 8f * scale,
                    toolX + 14f * scale, toolY - 14f * scale, stroke);
            if (unit.carriedGold > 0f) {
                paint.setColor(Color.rgb(104, 70, 36));
                canvas.drawOval(new RectF(x - 29f * scale, y - 34f * scale,
                        x - 8f * scale, y - 7f * scale), paint);
                paint.setColor(GOLD_LIGHT);
                canvas.drawCircle(x - 18f * scale, y - 22f * scale, 5f * scale, paint);
            }
            if (mining) {
                float impactPulse = Math.max(0f, miningSwing - 0.58f) / 0.38f;
                paint.setColor(Color.argb(150 + (int) (90f * impactPulse), 255, 207, 92));
                canvas.drawCircle(x + 34f * scale, y - 17f * scale,
                        (3f + impactPulse * 3f) * scale, paint);
                canvas.drawCircle(x + 45f * scale, y - 11f * scale,
                        (2f + impactPulse * 1.8f) * scale, paint);
                if (impactPulse > 0.15f) {
                    stroke.setStyle(Paint.Style.STROKE);
                    stroke.setStrokeWidth(1.5f * scale);
                    stroke.setColor(Color.argb((int) (210f * impactPulse), 255, 231, 151));
                    canvas.drawLine(x + 31f * scale, y - 19f * scale,
                            x + 47f * scale, y - 29f * scale, stroke);
                    canvas.drawLine(x + 34f * scale, y - 14f * scale,
                            x + 51f * scale, y - 8f * scale, stroke);
                }
            }
        } else {
            paint.setColor(darkTeam);
            Path cape = new Path();
            cape.moveTo(x - dir * 5f * scale, y - 51f * scale);
            cape.lineTo(x - dir * (28f + stepWave * 3f) * scale,
                    y - (8f + footPlant * 2f) * scale);
            cape.lineTo(x + dir * 6f * scale, y - 12f * scale);
            cape.close();
            canvas.drawPath(cape, paint);

            paint.setColor(bodyColor);
            canvas.drawRoundRect(new RectF(x - 12f * scale, y - 50f * scale,
                    x + 12f * scale, y - 12f * scale), 6f * scale, 6f * scale, paint);
            paint.setColor(teamColor);
            canvas.drawRect(x - 11f * scale, y - 42f * scale, x + 11f * scale, y - 34f * scale, paint);
            paint.setColor(unit.hitFlash > 0f ? Color.WHITE : Color.rgb(153, 160, 167));
            canvas.drawCircle(x, y - 62f * scale,
                    (unit.type == UnitType.ARCHER ? 12f : 14f) * scale, paint);
            paint.setColor(Color.rgb(52, 58, 67));
            canvas.drawArc(new RectF(x - 16f * scale, y - 79f * scale,
                    x + 16f * scale, y - 53f * scale), 180f, 180f, true, paint);
            paint.setColor(teamColor);
            canvas.drawRect(x - 14f * scale, y - 66f * scale, x + 14f * scale, y - 61f * scale, paint);
            paint.setColor(GOLD_LIGHT);
            canvas.drawRect(x - 7f * scale, y - 65f * scale, x + 7f * scale, y - 62f * scale, paint);
            paint.setColor(Color.rgb(18, 22, 28));
            canvas.drawRect(x + dir * 2f * scale, y - 63f * scale,
                    x + dir * 7f * scale, y - 60f * scale, paint);
            drawUnitArmorDetails(canvas, unit, x, y, scale, dir, teamColor, bodyColor, playerSide);

            float legSwing = unit.moving ? stepWave * 8.5f * scale : 0f;
            stroke.setColor(bodyColor);
            stroke.setStrokeWidth((unit.type == UnitType.ARCHER ? 4.6f : unit.type == UnitType.SPEAR ? 5.4f : 6f) * scale);
            canvas.drawLine(x - 4f * scale, y - 15f * scale, x - 14f * scale + legSwing, y, stroke);
            canvas.drawLine(x + 4f * scale, y - 15f * scale, x + 14f * scale - legSwing, y, stroke);

            if (unit.type == UnitType.SWORD) {
                float windUp = unit.attackAnim > 0f && attackPhase < 0.34f
                        ? (0.34f - attackPhase) / 0.34f : 0f;
                float weaponLift = (attackSwing * 24f - windUp * 10f) * scale;
                canvas.drawLine(x, y - 41f * scale, x - dir * 18f * scale, y - 29f * scale, stroke);
                canvas.drawLine(x, y - 41f * scale,
                        x + dir * (18f + attackSwing * 9f) * scale,
                        y - (31f + attackSwing * 18f) * scale, stroke);
                paint.setColor(teamColor);
                RectF shield = new RectF(x - dir * 33f * scale - 12f * scale,
                        y - 48f * scale, x - dir * 33f * scale + 12f * scale,
                        y - 17f * scale);
                canvas.drawOval(shield, paint);
                stroke.setColor(GOLD);
                stroke.setStrokeWidth(2f * scale);
                canvas.drawOval(shield, stroke);
                drawCrown(canvas, shield.centerX(), shield.centerY(), 6f * scale, GOLD_LIGHT);
                stroke.setColor(Color.rgb(224, 226, 229));
                stroke.setStrokeWidth(4f * scale);
                canvas.drawLine(x + dir * 14f * scale, y - 30f * scale - weaponLift * 0.2f,
                        x + dir * (42f - attackSwing * 10f) * scale,
                        y - (62f - attackSwing * 26f) * scale, stroke);
                stroke.setColor(Color.rgb(124, 83, 48));
                stroke.setStrokeWidth(3f * scale);
                canvas.drawLine(x + dir * 10f * scale, y - 25f * scale,
                        x + dir * 19f * scale, y - 34f * scale, stroke);
                if (unit.attackAnim > 0f) {
                    drawSlashTrail(canvas, x + dir * 21f * scale, y - 42f * scale,
                            dir, scale, attackPhase, playerSide);
                }
            } else if (unit.type == UnitType.SPEAR) {
                float thrust = unit.rangedAttack ? attackSwing * 7f : attackSwing * 20f;
                float lift = unit.rangedAttack ? (1f - attackPhase) * 18f : 0f;
                canvas.drawLine(x, y - 41f * scale, x - dir * 15f * scale, y - 28f * scale, stroke);
                canvas.drawLine(x, y - 41f * scale,
                        x + dir * (18f + thrust * 0.45f) * scale,
                        y - (31f + lift * 0.25f) * scale, stroke);
                stroke.setColor(Color.rgb(130, 87, 47));
                stroke.setStrokeWidth(4f * scale);
                float spearStartX = x - dir * (24f - lift * 0.25f) * scale;
                float spearStartY = y - (36f + lift) * scale;
                float spearEndX = x + dir * (58f + thrust) * scale;
                float spearEndY = y - (42f + lift * 0.35f) * scale;
                canvas.drawLine(spearStartX, spearStartY, spearEndX, spearEndY, stroke);
                paint.setColor(Color.rgb(225, 230, 235));
                Path spearHead = new Path();
                spearHead.moveTo(spearEndX + dir * 12f * scale, spearEndY);
                spearHead.lineTo(spearEndX - dir * 2f * scale, spearEndY - 7f * scale);
                spearHead.lineTo(spearEndX - dir * 2f * scale, spearEndY + 7f * scale);
                spearHead.close();
                canvas.drawPath(spearHead, paint);
                paint.setColor(teamColor);
                canvas.drawOval(new RectF(x - dir * 30f * scale - 11f * scale,
                        y - 46f * scale, x - dir * 30f * scale + 11f * scale,
                        y - 18f * scale), paint);
                if (unit.attackAnim > 0f && !unit.rangedAttack) {
                    stroke.setStyle(Paint.Style.STROKE);
                    stroke.setStrokeWidth(3f * scale);
                    stroke.setColor(Color.argb((int) (170f * attackSwing),
                            playerSide ? 112 : 255, playerSide ? 207 : 124, playerSide ? 255 : 96));
                    canvas.drawLine(spearEndX - dir * 12f * scale, spearEndY,
                            spearEndX + dir * 22f * scale, spearEndY, stroke);
                }
            } else {
                float drawPull = attackSwing * 12f * scale;
                canvas.drawLine(x, y - 41f * scale, x - dir * 16f * scale, y - 27f * scale, stroke);
                canvas.drawLine(x, y - 41f * scale, x + dir * 17f * scale, y - 30f * scale, stroke);
                stroke.setColor(Color.rgb(181, 121, 60));
                stroke.setStrokeWidth(3f * scale);
                RectF bow = new RectF(x + dir * 8f * scale - 18f * scale,
                        y - 65f * scale, x + dir * 8f * scale + 18f * scale,
                        y - 17f * scale);
                canvas.drawArc(bow, playerSide ? -80f : 100f, 160f, false, stroke);
                stroke.setColor(Color.rgb(220, 223, 226));
                stroke.setStrokeWidth(1.5f * scale);
                float stringX = x + dir * 8f * scale - dir * drawPull;
                canvas.drawLine(stringX, y - 62f * scale, stringX, y - 20f * scale, stroke);
                stroke.setColor(Color.rgb(225, 227, 230));
                stroke.setStrokeWidth(1.7f * scale);
                canvas.drawLine(stringX, y - 41f * scale,
                        x + dir * (39f + attackSwing * 8f) * scale, y - 41f * scale, stroke);
                paint.setColor(playerSide ? Color.rgb(92, 174, 255) : Color.rgb(255, 102, 89));
                canvas.drawCircle(x + dir * 22f * scale, y - 41f * scale,
                        (2.3f + attackPhase * 1.4f) * scale * attackSwing, paint);
                if (unit.attackAnim > 0f && attackPhase > 0.72f) {
                    stroke.setStyle(Paint.Style.STROKE);
                    stroke.setStrokeWidth(1.8f * scale);
                    stroke.setColor(Color.argb((int) (180f * (1f - attackPhase)),
                            playerSide ? 105 : 255, playerSide ? 213 : 132, playerSide ? 255 : 105));
                    canvas.drawCircle(x + dir * 25f * scale, y - 41f * scale,
                            10f * scale * attackPhase, stroke);
                }
            }
        }
        if (playerSide && outfitTier > 0) {
            drawEquippedOutfitDetails(canvas, unit, x, y, scale, outfitTier, teamColor);
        }
        canvas.restore();
        if (unit.hero) {
            drawCrown(canvas, x, y - 106f * scale, 11f * scale, GOLD_LIGHT);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            paint.setTextSize(10.5f * scale);
            paint.setColor(GOLD_LIGHT);
            canvas.drawText("ALTIN MUHAFIZ • SV" + heroLevel, x, y - 119f * scale, paint);
        } else if (unit.boss) {
            drawCrown(canvas, x, y - 105f * scale, 11f * scale, GOLD_LIGHT);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            paint.setTextSize(10.5f * scale);
            paint.setColor(Color.rgb(255, 173, 104));
            canvas.drawText("BÖLÜM BOSSU", x, y - 119f * scale, paint);
        } else if (unit.commander) {
            drawCrown(canvas, x, y - 94f * scale, 8f * scale, Color.rgb(255, 108, 84));
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            paint.setTextSize(9.5f * scale);
            paint.setColor(Color.rgb(255, 190, 120));
            canvas.drawText("KOMUTAN", x, y - 105f * scale, paint);
        }
        float healthWidth = unit.hero ? 94f * scale
                : unit.boss ? 112f * scale : unit.commander ? 78f * scale : 56f * scale;
        float healthY = unit.hero ? 132f : unit.boss ? 132f : unit.commander ? 116f : 91f;
        drawHealthBar(canvas, x - healthWidth * 0.5f, y - healthY * scale,
                healthWidth, unit.hp / unit.maxHp,
                unit.hero ? GOLD_LIGHT : unit.boss ? Color.rgb(255, 68, 57)
                        : unit.commander ? Color.rgb(255, 95, 74) : teamColor,
                unit.hero || unit.commander);
    }

    private void drawEquippedOutfitDetails(Canvas canvas, Unit unit, float x, float y,
                                           float scale, int tier, int accent) {
        if (tier >= 1) {
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(2.2f * scale);
            stroke.setColor(tier >= 2 ? GOLD_LIGHT : Color.rgb(197, 212, 226));
            canvas.drawRoundRect(new RectF(x - 13f * scale, y - 51f * scale,
                    x + 13f * scale, y - 11f * scale), 6f * scale, 6f * scale, stroke);
        }
        if (tier >= 2) {
            drawCrown(canvas, x, y - 83f * scale, 6f * scale, GOLD_LIGHT);
            paint.setColor(Color.argb(135, Color.red(accent), Color.green(accent), Color.blue(accent)));
            canvas.drawCircle(x, y - 35f * scale, 4.5f * scale, paint);
        }
        if (tier >= 3) {
            int pulse = 32 + (int) (18f * (0.5f + 0.5f * Math.sin(ambientClock * 3f + unit.anim)));
            paint.setColor(Color.argb(pulse, 194, 112, 255));
            canvas.drawCircle(x, y - 38f * scale, 31f * scale, paint);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(2f * scale);
            stroke.setColor(Color.argb(150, 217, 155, 255));
            canvas.drawArc(new RectF(x - 24f * scale, y - 72f * scale,
                    x + 24f * scale, y - 23f * scale), 205f, 130f, false, stroke);
        }
    }

    private void drawUnitArmorDetails(Canvas canvas, Unit unit, float x, float y,
                                      float scale, float dir, int teamColor, int bodyColor,
                                      boolean playerSide) {
        // v0.2.9: Birliklere daha profesyonel görünüm için kask, omuzluk ve sınıf detayları.
        paint.setColor(Color.argb(180, 255, 255, 255));
        canvas.drawCircle(x - dir * 4f * scale, y - 66f * scale, 2.0f * scale, paint);
        canvas.drawCircle(x + dir * 4f * scale, y - 66f * scale, 2.0f * scale, paint);
        paint.setColor(Color.argb(165, 34, 38, 46));
        canvas.drawRect(x - 9f * scale, y - 63f * scale, x + 9f * scale, y - 59f * scale, paint);

        paint.setColor(teamColor);
        canvas.drawRoundRect(new RectF(x - 18f * scale, y - 53f * scale,
                x - 5f * scale, y - 39f * scale), 4f * scale, 4f * scale, paint);
        canvas.drawRoundRect(new RectF(x + 5f * scale, y - 53f * scale,
                x + 18f * scale, y - 39f * scale), 4f * scale, 4f * scale, paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setColor(Color.argb(160, 236, 219, 191));
        stroke.setStrokeWidth(1.5f * scale);
        canvas.drawRoundRect(new RectF(x - 18f * scale, y - 53f * scale,
                x - 5f * scale, y - 39f * scale), 4f * scale, 4f * scale, stroke);
        canvas.drawRoundRect(new RectF(x + 5f * scale, y - 53f * scale,
                x + 18f * scale, y - 39f * scale), 4f * scale, 4f * scale, stroke);

        if (unit.type == UnitType.ARCHER) {
            paint.setColor(Color.rgb(103, 73, 48));
            Path quiver = new Path();
            quiver.moveTo(x - dir * 19f * scale, y - 49f * scale);
            quiver.lineTo(x - dir * 29f * scale, y - 56f * scale);
            quiver.lineTo(x - dir * 33f * scale, y - 28f * scale);
            quiver.lineTo(x - dir * 21f * scale, y - 22f * scale);
            quiver.close();
            canvas.drawPath(quiver, paint);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setColor(Color.rgb(226, 228, 234));
            stroke.setStrokeWidth(1.7f * scale);
            for (int i = 0; i < 3; i++) {
                float ax = x - dir * (28f - i * 4f) * scale;
                canvas.drawLine(ax, y - 57f * scale, ax, y - 70f * scale, stroke);
            }
        } else if (unit.type == UnitType.SPEAR) {
            paint.setColor(Color.rgb(120, 80, 44));
            canvas.drawRoundRect(new RectF(x - dir * 24f * scale - 5f * scale,
                    y - 52f * scale, x - dir * 24f * scale + 5f * scale,
                    y - 18f * scale), 3f * scale, 3f * scale, paint);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(2f * scale);
            stroke.setColor(Color.rgb(225, 230, 235));
            canvas.drawLine(x - dir * 24f * scale, y - 58f * scale,
                    x - dir * 24f * scale, y - 70f * scale, stroke);
        } else if (unit.type == UnitType.SWORD) {
            paint.setColor(Color.argb(135, 255, 255, 255));
            canvas.drawRect(x - 5f * scale, y - 38f * scale, x + 5f * scale, y - 28f * scale, paint);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setColor(Color.argb(125, 42, 46, 54));
            stroke.setStrokeWidth(1.4f * scale);
            canvas.drawLine(x, y - 38f * scale, x, y - 28f * scale, stroke);
            canvas.drawLine(x - 5f * scale, y - 33f * scale, x + 5f * scale, y - 33f * scale, stroke);
        } else if (unit.type == UnitType.MINER) {
            paint.setColor(Color.rgb(112, 79, 50));
            canvas.drawRoundRect(new RectF(x - 22f * scale, y - 43f * scale,
                    x - 8f * scale, y - 24f * scale), 4f * scale, 4f * scale, paint);
            paint.setColor(GOLD_LIGHT);
            canvas.drawCircle(x - 15f * scale, y - 34f * scale, 3.4f * scale, paint);
        }
    }

    private void drawSlashTrail(Canvas canvas, float x, float y, float dir, float scale,
                                float phase, boolean playerSide) {
        float alphaWave = (float) Math.sin(Math.max(0f, Math.min(1f, phase)) * Math.PI);
        int alpha = (int) (185f * alphaWave);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeWidth(7f * scale * (0.65f + alphaWave * 0.35f));
        int base = playerSide ? Color.rgb(108, 190, 255) : Color.rgb(255, 111, 91);
        stroke.setColor(Color.argb(alpha, Color.red(base), Color.green(base), Color.blue(base)));
        RectF arc = new RectF(x - 38f * scale, y - 38f * scale,
                x + 38f * scale, y + 38f * scale);
        float start = dir > 0f ? -92f : 92f;
        float sweep = dir > 0f ? 116f : -116f;
        canvas.drawArc(arc, start + phase * 26f * dir, sweep, false, stroke);
    }

    private void drawHealthBar(Canvas canvas, float x, float y, float w, float ratio, int color, boolean ornate) {
        ratio = Math.max(0f, Math.min(1f, ratio));
        float h = ornate ? 11f : 7f;
        paint.setColor(Color.argb(215, 8, 11, 17));
        canvas.drawRoundRect(new RectF(x, y, x + w, y + h), h / 2f, h / 2f, paint);
        paint.setColor(color);
        canvas.drawRoundRect(new RectF(x + 2f, y + 2f, x + 2f + (w - 4f) * ratio, y + h - 2f),
                Math.max(2f, h / 3f), Math.max(2f, h / 3f), paint);
        if (ornate) {
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(1.5f);
            stroke.setColor(GOLD);
            canvas.drawRoundRect(new RectF(x - 1f, y - 1f, x + w + 1f, y + h + 1f), h / 2f, h / 2f, stroke);
        }
    }

    private void drawHud(Canvas canvas) {
        // v0.5.2: birlik menüsü açılır/kapanır; seçili birlik için hızlı eğitim kartı ve HUD hız düğmesi.
        float topH = Math.max(52f * uiScale, height * (tabletLayout ? 0.072f : 0.090f));
        topH = Math.min(topH, 92f * uiScale);
        float hudMaxW = tabletLayout ? 1600f * uiScale : width - safePadding * 2f;
        float hudW = Math.min(width - safePadding * 2f, hudMaxW);
        float hudLeft = (width - hudW) / 2f;
        RectF top = new RectF(hudLeft, safePadding * 0.50f, hudLeft + hudW, safePadding * 0.50f + topH);
        drawPanel(canvas, top, 13f * uiScale, true);

        float section = top.width() / 3f;
        stroke.setColor(Color.argb(82, 226, 173, 62));
        stroke.setStrokeWidth(Math.max(1f, 1.3f * uiScale));
        for (int i = 1; i <= 2; i++) {
            float sx = top.left + section * i;
            canvas.drawLine(sx, top.top + 8f * uiScale, sx, top.bottom - 8f * uiScale, stroke);
        }

        float iconR = Math.max(10f * uiScale, top.height() * 0.20f);
        float pad = 16f * uiScale;
        paint.setTextAlign(Paint.Align.LEFT);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(13.5f * uiScale, top.height() * 0.26f));
        paint.setColor(GOLD_LIGHT);

        float s1 = top.left;
        drawCoin(canvas, s1 + pad + iconR, top.centerY() - 2f * uiScale, iconR);
        canvas.drawText("ALTIN " + (int) gold, s1 + pad + iconR * 2.2f,
                top.centerY() + paint.getTextSize() * 0.30f, paint);

        float s2 = top.left + section;
        drawCrossedSwords(canvas, s2 + pad + iconR, top.centerY() - 2f * uiScale, iconR * 0.88f, GOLD);
        String battleText = arenaMode ? "ARENA • DALGA " + wave
                : "BÖLÜM " + battleLevel + " • DALGA " + wave;
        canvas.drawText(battleText, s2 + pad + iconR * 2.2f,
                top.centerY() + paint.getTextSize() * 0.30f, paint);
        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(Math.max(9.5f * uiScale, top.height() * 0.145f));
        paint.setColor(Color.rgb(193, 203, 219));
        canvas.drawText((commandMode == CommandMode.ATTACK ? "Saldırı" : "Savunma")
                        + " • Ordu " + countCombatUnitsLocked(playerUnits) + "/" + playerCombatLimitLocked()
                        + " • Hız x" + trimMultiplier(gameSpeed),
                s2 + pad + iconR * 2.2f, top.centerY() + top.height() * 0.32f, paint);

        float s3 = top.left + section * 2f;
        drawShield(canvas, s3 + pad + iconR, top.centerY() - 2f * uiScale, iconR, GOLD);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(12.5f * uiScale, top.height() * 0.21f));
        paint.setColor(Color.WHITE);
        canvas.drawText("HEYKEL CANI", s3 + pad + iconR * 2.0f, top.centerY() - 8f * uiScale, paint);
        drawHealthBar(canvas, s3 + pad + iconR * 2.0f, top.centerY() + 6f * uiScale,
                Math.max(120f * uiScale, section * 0.55f), playerBaseHp / playerStatueMaxHp(), BLUE, true);

        boolean attackActive = commandMode == CommandMode.ATTACK;
        drawButton(canvas, attackButton, attackActive ? "SALDIRI AKTİF" : "SALDIR",
                attackActive ? "Ön cepheyi it" : "İleri hücum", true);
        drawButton(canvas, defendButton, !attackActive ? "SAVUNMA AKTİF" : "SAVUN",
                !attackActive ? "Savunma hattı kur" : "Heykel hattını koru", true);
        drawButton(canvas, tacticalButton, tacticalPanel ? "TAKTİĞİ KAPAT" : "TAKTİK",
                formationLabelLocked(), true);
        drawButton(canvas, speedHudButton, "HIZ x" + trimMultiplier(gameSpeed), "1–4x", true);
        drawButton(canvas, pauseButton, "Ⅱ DURDUR", "Menü", true);

        drawButton(canvas, unitMenuToggleButton, unitMenuOpen ? "BİRLİKLER ▲" : "BİRLİKLER ▼",
                unitMenuOpen ? "Menüyü kapat" : "Birlik seç", true);
        drawQuickRecruitButton(canvas);
        drawButton(canvas, devButton, tabletLayout ? "</> ARAÇLAR" : "</> MOD",
                tabletLayout ? "Geliştirici paneli" : "Araçlar", true);
        if (unitMenuOpen) drawUnitSelectionMenu(canvas);

        drawSkillButton(canvas, warCryButton, "NARA", "+hasar • +hız",
                warCryCooldown, warCryUnlockedLocked(), warCryTimer > 0f, Color.rgb(255, 189, 74));
        drawSkillButton(canvas, statueShieldButton, "KALKAN", "Heykel koruma",
                statueShieldCooldown, statueShieldUnlockedLocked(), statueShieldTimer > 0f, Color.rgb(105, 231, 255));
        drawSkillButton(canvas, arrowRainButton, "OK YAĞMURU", "Alan hasarı",
                arrowRainCooldown, arrowRainUnlockedLocked(), arrowRainTimer > 0f, Color.rgb(163, 126, 255));
        drawCameraPositionIndicator(canvas);
    }

    private void drawUnitSelectionMenu(Canvas canvas) {
        float margin = 7f * uiScale;
        RectF panel = new RectF(minerButton.left - margin, minerButton.top - margin,
                archerButton.right + margin, archerButton.bottom + margin);
        paint.setColor(Color.argb(236, 8, 14, 24));
        canvas.drawRoundRect(panel, 15f * uiScale, 15f * uiScale, paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(1.8f * uiScale);
        stroke.setColor(Color.argb(190, 226, 173, 62));
        canvas.drawRoundRect(panel, 15f * uiScale, 15f * uiScale, stroke);

        drawSelectableUnitCard(canvas, minerButton, UnitType.MINER);
        drawSelectableUnitCard(canvas, swordButton, UnitType.SWORD);
        drawSelectableUnitCard(canvas, spearButton, UnitType.SPEAR);
        drawSelectableUnitCard(canvas, archerButton, UnitType.ARCHER);
    }

    private void drawSelectableUnitCard(Canvas canvas, RectF rect, UnitType type) {
        boolean unlocked = type != UnitType.ARCHER || isArcherUnlockedLocked();
        boolean selected = selectedUnitType == type;
        int count = countUnitsOfTypeLocked(playerUnits, type);
        String title = unitSelectionTitleLocked(type);
        String cost = unlocked ? Integer.toString(Math.round(unitCostLocked(type))) : "BÖLÜM 3";
        String detail = unlocked ? count + "/" + unitLimitLocked(type) + " • "
                + (selected ? "SEÇİLİ" : "SEÇ") : "KİLİTLİ";
        drawUnitCard(canvas, rect, type, title, cost, detail, unlocked);
        if (selected) {
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(3.2f * uiScale);
            stroke.setColor(GOLD_LIGHT);
            canvas.drawRoundRect(new RectF(rect.left + 2f * uiScale, rect.top + 2f * uiScale,
                    rect.right - 2f * uiScale, rect.bottom - 2f * uiScale),
                    12f * uiScale, 12f * uiScale, stroke);
        }
    }

    private void drawQuickRecruitButton(Canvas canvas) {
        UnitType type = selectedUnitType;
        boolean unlocked = type != UnitType.ARCHER || isArcherUnlockedLocked();
        float cost = unitCostLocked(type);
        int count = countUnitsOfTypeLocked(playerUnits, type);
        String title = unlocked ? "EĞİT • " + unitDisplayNameLocked(type) : "OKÇU KİLİTLİ";
        String detail = unlocked
                ? Math.round(cost) + " ALTIN • " + count + "/" + unitLimitLocked(type)
                : "BÖLÜM 3'TE AÇILIR";
        boolean enabled = unlocked && unitCanBuyLocked(type);
        drawButton(canvas, quickUnitButton, title, detail, enabled);
        drawUnitIcon(canvas, quickUnitButton.left + 24f * uiScale, quickUnitButton.centerY(),
                Math.min(18f * uiScale, quickUnitButton.height() * 0.29f), type, unlocked);
    }

    private String unitSelectionTitleLocked(UnitType type) {
        if (type == UnitType.MINER) return "MADENCİ SV" + minerUpgradeLevel;
        if (type == UnitType.SWORD) return swordUnitTitleLocked();
        if (type == UnitType.SPEAR) return "MIZRAK G" + spearPowerLevel + " M" + spearRangeLevel;
        return isArcherUnlockedLocked() ? "OKÇU SV" + archerUpgradeLevel : "OKÇU KİLİTLİ";
    }

    private float unitCostLocked(UnitType type) {
        if (type == UnitType.MINER) return 50f;
        if (type == UnitType.SWORD) return 100f;
        if (type == UnitType.SPEAR) return 175f;
        return 150f;
    }

    private int unitLimitLocked(UnitType type) {
        if (type == UnitType.MINER) return playerMinerLimitLocked();
        if (type == UnitType.SWORD) return playerSwordLimitLocked();
        if (type == UnitType.SPEAR) return playerSpearLimitLocked();
        return playerArcherLimitLocked();
    }

    private boolean unitCanBuyLocked(UnitType type) {
        if (gold < unitCostLocked(type)) return false;
        if (countUnitsOfTypeLocked(playerUnits, type) >= unitLimitLocked(type)) return false;
        return type == UnitType.MINER || countCombatUnitsLocked(playerUnits) < playerCombatLimitLocked();
    }

    private void selectUnitLocked(UnitType type) {
        if (type == UnitType.ARCHER && !isArcherUnlockedLocked()) {
            showToastLocked("OKÇU BÖLÜM 3'TE AÇILIR");
            return;
        }
        selectedUnitType = type;
        unitMenuOpen = false;
        showToastLocked(unitDisplayNameLocked(type) + " SEÇİLDİ");
    }

    private void buySelectedUnitLocked() {
        if (selectedUnitType == UnitType.ARCHER && !isArcherUnlockedLocked()) {
            showToastLocked("OKÇU BÖLÜM 3'TE AÇILIR");
            return;
        }
        buyUnitLocked(selectedUnitType, unitCostLocked(selectedUnitType));
    }

    private void cycleGameSpeedLocked() {
        if (gameSpeed < 2f) gameSpeed = 2f;
        else if (gameSpeed < 3f) gameSpeed = 3f;
        else if (gameSpeed < 4f) gameSpeed = 4f;
        else gameSpeed = 1f;
        showToastLocked("OYUN HIZI x" + trimMultiplier(gameSpeed));
    }

    private void drawCameraPositionIndicator(Canvas canvas) {
        float maxCamera = Math.max(1f, worldWidth - width);
        float trackW = Math.min(245f * uiScale, width * 0.20f);
        float trackH = Math.max(13f * uiScale, 13f);
        float x = width * 0.5f - trackW * 0.5f;
        float anchorTop = unitMenuOpen ? minerButton.top : quickUnitButton.top;
        float y = anchorTop - trackH - 7f * uiScale;
        RectF track = new RectF(x, y, x + trackW, y + trackH);
        paint.setColor(Color.argb(190, 7, 12, 21));
        canvas.drawRoundRect(track, trackH * 0.5f, trackH * 0.5f, paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(Math.max(1f, 1.3f * uiScale));
        stroke.setColor(Color.argb(185, 226, 173, 62));
        canvas.drawRoundRect(track, trackH * 0.5f, trackH * 0.5f, stroke);

        float viewportRatio = Math.min(1f, width / Math.max(width, worldWidth));
        float viewW = Math.max(24f * uiScale, trackW * viewportRatio);
        float travel = Math.max(0f, trackW - viewW);
        float viewLeft = x + travel * Math.max(0f, Math.min(1f, cameraX / maxCamera));
        RectF viewport = new RectF(viewLeft + 2f * uiScale, y + 2f * uiScale,
                viewLeft + viewW - 2f * uiScale, y + trackH - 2f * uiScale);
        paint.setShader(new LinearGradient(viewport.left, viewport.top, viewport.right, viewport.bottom,
                Color.argb(220, 103, 177, 255), Color.argb(210, 255, 198, 82), Shader.TileMode.CLAMP));
        canvas.drawRoundRect(viewport, trackH * 0.38f, trackH * 0.38f, paint);
        paint.setShader(null);

        float playerDot = x + trackW * (playerBaseX() / Math.max(1f, worldWidth));
        float enemyDot = x + trackW * (enemyBaseX() / Math.max(1f, worldWidth));
        paint.setColor(BLUE);
        canvas.drawCircle(playerDot, track.centerY(), 3.2f * uiScale, paint);
        paint.setColor(enemyAccentColorLocked());
        canvas.drawCircle(enemyDot, track.centerY(), 3.2f * uiScale, paint);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(8f, 8.5f * uiScale));
        paint.setColor(Color.rgb(203, 211, 223));
        canvas.drawText(cameraDragging ? "KAMERA SÜRÜKLENİYOR" : "SAVAŞ ALANI",
                track.centerX(), track.top - 3f * uiScale, paint);
    }

    private void drawTacticalPanel(Canvas canvas) {
        float margin = 7f * uiScale;
        RectF panel = new RectF(formationButton.left - margin, formationButton.top - margin,
                towerButton.right + margin, towerButton.bottom + margin);
        paint.setColor(Color.argb(228, 9, 15, 26));
        canvas.drawRoundRect(panel, 14f * uiScale, 14f * uiScale, paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(1.8f * uiScale);
        stroke.setColor(Color.argb(170, 226, 173, 62));
        canvas.drawRoundRect(panel, 14f * uiScale, 14f * uiScale, stroke);

        drawButton(canvas, formationButton, "DİZİLİM", formationLabelLocked(), true);
        if (arenaMode) {
            drawButton(canvas, barricadeButton, "ARENA ORTA HAT", "Savunma yapıları kapalı", false);
            drawButton(canvas, towerButton, "YIĞILMA ÖNLEME", "Birlikler merkezde toplanır", false);
            return;
        }

        String barricadeTitle = playerBarricadeHp > 0f ? "BARİKAT ONAR" : "BARİKAT KUR";
        String barricadeInfo = !barricadeUnlockedLocked() ? "BÖLÜM 2"
                : playerBarricadeHp > 0f
                ? Math.round(playerBarricadeHp) + "/" + Math.round(playerBarricadeMaxHp) + " • 120"
                : "220 ALTIN";
        drawButton(canvas, barricadeButton, barricadeTitle, barricadeInfo, barricadeUnlockedLocked());

        String towerTitle = playerTowerHp > 0f ? "KULE ONAR" : "OKÇU KULESİ";
        String towerInfo = !towerUnlockedLocked() ? "BÖLÜM 4"
                : playerTowerHp > 0f
                ? Math.round(playerTowerHp) + "/" + Math.round(playerTowerMaxHp) + " • 180"
                : "340 ALTIN";
        drawButton(canvas, towerButton, towerTitle, towerInfo, towerUnlockedLocked());
    }

    private void drawDefenseStructures(Canvas canvas) {
        if (arenaMode) return;
        if (playerTowerHp > 0f) drawArcherTower(canvas);
        if (playerBarricadeHp > 0f) drawBarricade(canvas);
    }

    private void drawBarricade(Canvas canvas) {
        float x = playerBarricadeXLocked();
        float y = groundY + 4f * uiScale;
        float ratio = playerBarricadeHp / Math.max(1f, playerBarricadeMaxHp);
        paint.setColor(Color.argb(100, 0, 0, 0));
        canvas.drawOval(new RectF(x - 62f * uiScale, y - 7f * uiScale,
                x + 62f * uiScale, y + 9f * uiScale), paint);
        for (int i = -2; i <= 2; i++) {
            float px = x + i * 24f * uiScale;
            float top = y - (72f + (Math.abs(i) % 2) * 14f) * uiScale;
            Path stake = new Path();
            stake.moveTo(px - 9f * uiScale, y);
            stake.lineTo(px - 7f * uiScale, top + 14f * uiScale);
            stake.lineTo(px, top);
            stake.lineTo(px + 7f * uiScale, top + 14f * uiScale);
            stake.lineTo(px + 9f * uiScale, y);
            stake.close();
            paint.setColor(ratio < 0.35f ? Color.rgb(105, 61, 39) : Color.rgb(131, 82, 48));
            canvas.drawPath(stake, paint);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(2f * uiScale);
            stroke.setColor(Color.rgb(73, 43, 29));
            canvas.drawPath(stake, stroke);
        }
        paint.setColor(Color.rgb(74, 51, 34));
        canvas.drawRoundRect(new RectF(x - 66f * uiScale, y - 51f * uiScale,
                x + 66f * uiScale, y - 35f * uiScale), 5f * uiScale, 5f * uiScale, paint);
        paint.setColor(Color.rgb(171, 122, 66));
        for (int i = -2; i <= 2; i++) {
            canvas.drawCircle(x + i * 25f * uiScale, y - 43f * uiScale, 4f * uiScale, paint);
        }
        if (ratio < 0.55f) {
            stroke.setColor(Color.rgb(50, 31, 25));
            stroke.setStrokeWidth(3f * uiScale);
            canvas.drawLine(x - 33f * uiScale, y - 65f * uiScale,
                    x - 13f * uiScale, y - 37f * uiScale, stroke);
        }
        drawHealthBar(canvas, x - 62f * uiScale, y - 100f * uiScale,
                124f * uiScale, ratio, BLUE, true);
    }

    private void drawArcherTower(Canvas canvas) {
        float x = playerTowerXLocked();
        float y = groundY + 3f * uiScale;
        float ratio = playerTowerHp / Math.max(1f, playerTowerMaxHp);
        paint.setColor(Color.argb(95, 0, 0, 0));
        canvas.drawOval(new RectF(x - 48f * uiScale, y - 6f * uiScale,
                x + 48f * uiScale, y + 8f * uiScale), paint);
        paint.setColor(ratio < 0.35f ? Color.rgb(76, 70, 66) : Color.rgb(98, 94, 87));
        canvas.drawRect(x - 31f * uiScale, y - 126f * uiScale,
                x + 31f * uiScale, y, paint);
        paint.setColor(Color.rgb(53, 57, 64));
        for (int row = 0; row < 5; row++) {
            float yy = y - 18f * uiScale - row * 22f * uiScale;
            canvas.drawRect(x - 30f * uiScale, yy, x + 30f * uiScale,
                    yy + 3f * uiScale, paint);
        }
        paint.setColor(Color.rgb(44, 50, 59));
        canvas.drawRect(x - 45f * uiScale, y - 143f * uiScale,
                x + 45f * uiScale, y - 118f * uiScale, paint);
        for (int i = -2; i <= 2; i++) {
            if (i == 0) continue;
            canvas.drawRect(x + i * 18f * uiScale - 7f * uiScale,
                    y - 158f * uiScale, x + i * 18f * uiScale + 7f * uiScale,
                    y - 137f * uiScale, paint);
        }
        paint.setColor(BLUE);
        Path flag = new Path();
        flag.moveTo(x, y - 182f * uiScale);
        flag.lineTo(x + 38f * uiScale, y - 170f * uiScale);
        flag.lineTo(x, y - 158f * uiScale);
        flag.close();
        canvas.drawPath(flag, paint);
        stroke.setColor(GOLD_LIGHT);
        stroke.setStrokeWidth(3f * uiScale);
        canvas.drawLine(x, y - 190f * uiScale, x, y - 145f * uiScale, stroke);
        drawHealthBar(canvas, x - 55f * uiScale, y - 211f * uiScale,
                110f * uiScale, ratio, BLUE, true);
    }

    private void drawSiegeRam(Canvas canvas, Unit unit, boolean playerSide) {
        float x = unit.x;
        float y = groundY + laneOffset(unit.lane);
        float s = Math.max(1.15f, unit.visualScale) * uiScale;
        int accent = playerSide ? BLUE : RED;
        paint.setColor(Color.argb(100, 0, 0, 0));
        canvas.drawOval(new RectF(x - 58f * s, y - 7f * s, x + 58f * s, y + 8f * s), paint);
        paint.setColor(Color.rgb(77, 55, 38));
        canvas.drawRoundRect(new RectF(x - 50f * s, y - 54f * s,
                x + 45f * s, y - 12f * s), 10f * s, 10f * s, paint);
        paint.setColor(Color.rgb(45, 48, 54));
        Path roof = new Path();
        roof.moveTo(x - 56f * s, y - 51f * s);
        roof.lineTo(x - 34f * s, y - 80f * s);
        roof.lineTo(x + 30f * s, y - 80f * s);
        roof.lineTo(x + 51f * s, y - 51f * s);
        roof.close();
        canvas.drawPath(roof, paint);
        paint.setColor(accent);
        canvas.drawRect(x - 40f * s, y - 67f * s, x + 38f * s, y - 60f * s, paint);
        paint.setColor(Color.rgb(189, 193, 197));
        canvas.drawRoundRect(new RectF(x - 68f * s, y - 43f * s,
                x + 62f * s, y - 29f * s), 7f * s, 7f * s, paint);
        Path head = new Path();
        head.moveTo(x - 75f * s, y - 36f * s);
        head.lineTo(x - 58f * s, y - 49f * s);
        head.lineTo(x - 58f * s, y - 23f * s);
        head.close();
        paint.setColor(Color.rgb(116, 119, 124));
        canvas.drawPath(head, paint);
        paint.setColor(Color.rgb(31, 34, 39));
        for (int i = -1; i <= 1; i += 2) {
            canvas.drawCircle(x + i * 34f * s, y - 8f * s, 13f * s, paint);
            paint.setColor(Color.rgb(119, 86, 52));
            canvas.drawCircle(x + i * 34f * s, y - 8f * s, 7f * s, paint);
            paint.setColor(Color.rgb(31, 34, 39));
        }
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(10f * s);
        paint.setColor(Color.rgb(255, 188, 118));
        canvas.drawText("KUŞATMA", x, y - 90f * s, paint);
        drawHealthBar(canvas, x - 66f * s, y - 108f * s,
                132f * s, unit.hp / unit.maxHp, accent, true);
    }

    private void drawSkillButton(Canvas canvas, RectF rect, String title, String subtitle,
                                 float cooldown, boolean unlocked, boolean active, int accent) {
        boolean ready = unlocked && cooldown <= 0f;
        float radius = Math.max(7f * uiScale, rect.height() * 0.17f);
        paint.setColor(Color.argb(120, 0, 0, 0));
        canvas.drawRoundRect(new RectF(rect.left + 2f * uiScale, rect.top + 3f * uiScale,
                rect.right + 2f * uiScale, rect.bottom + 3f * uiScale), radius, radius, paint);
        paint.setShader(new LinearGradient(rect.left, rect.top, rect.left, rect.bottom,
                active ? Color.rgb(61, 65, 75) : Color.rgb(38, 48, 64),
                Color.rgb(10, 16, 27), Shader.TileMode.CLAMP));
        canvas.drawRoundRect(rect, radius, radius, paint);
        paint.setShader(null);
        if (active || ready) {
            paint.setColor(Color.argb(active ? 72 : 35,
                    Color.red(accent), Color.green(accent), Color.blue(accent)));
            canvas.drawRoundRect(new RectF(rect.left + 3f * uiScale, rect.top + 3f * uiScale,
                    rect.right - 3f * uiScale, rect.bottom - 3f * uiScale),
                    Math.max(4f, radius - 2f * uiScale), Math.max(4f, radius - 2f * uiScale), paint);
        }
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(Math.max(1.2f, 1.8f * uiScale));
        stroke.setColor(unlocked ? accent : Color.rgb(87, 92, 101));
        canvas.drawRoundRect(rect, radius, radius, stroke);
        stroke.setStrokeWidth(Math.max(0.8f, 1f * uiScale));
        stroke.setColor(unlocked ? Color.argb(145, 235, 225, 194) : Color.argb(80, 145, 145, 145));
        canvas.drawRoundRect(new RectF(rect.left + 3f * uiScale, rect.top + 3f * uiScale,
                rect.right - 3f * uiScale, rect.bottom - 3f * uiScale),
                Math.max(4f, radius - 2f * uiScale), Math.max(4f, radius - 2f * uiScale), stroke);

        float emblemX = rect.left + Math.max(14f * uiScale, rect.height() * 0.25f);
        float emblemR = Math.max(5f * uiScale, rect.height() * 0.105f);
        paint.setColor(unlocked ? accent : Color.rgb(95, 99, 108));
        canvas.drawCircle(emblemX, rect.centerY(), emblemR, paint);
        stroke.setColor(Color.argb(210, 16, 21, 30));
        stroke.setStrokeWidth(Math.max(1f, 1.2f * uiScale));
        canvas.drawLine(emblemX - emblemR * 0.55f, rect.centerY(),
                emblemX + emblemR * 0.55f, rect.centerY(), stroke);
        canvas.drawLine(emblemX, rect.centerY() - emblemR * 0.55f,
                emblemX, rect.centerY() + emblemR * 0.55f, stroke);

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(Math.max(9.5f * uiScale, rect.height() * 0.25f));
        paint.setColor(ready || active ? Color.WHITE : unlocked ? Color.rgb(190, 197, 210) : Color.GRAY);
        float textX = rect.centerX() + emblemR * 0.35f;
        canvas.drawText(unlocked ? title : "KİLİTLİ", textX,
                rect.top + rect.height() * 0.43f, paint);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(7.5f * uiScale, rect.height() * 0.17f));
        paint.setColor(unlocked ? Color.rgb(206, 213, 225) : Color.rgb(120, 124, 132));
        String status = !unlocked ? (title.contains("KALKAN") ? "BÖLÜM 2" : title.contains("YAĞMURU") ? "BÖLÜM 3" : "BÖLÜM 1")
                : active ? "AKTİF" : cooldown > 0f ? Math.max(1, Math.round(cooldown)) + " SN" : subtitle;
        canvas.drawText(status, textX, rect.bottom - rect.height() * 0.17f, paint);
        if (cooldown > 0f && unlocked) {
            float maxCooldown = title.contains("NARA") ? 30f : title.contains("KALKAN") ? 38f : 26f;
            float ratio = Math.max(0f, Math.min(1f, cooldown / maxCooldown));
            paint.setColor(Color.argb(135, 3, 6, 12));
            canvas.drawRoundRect(new RectF(rect.left, rect.top,
                    rect.right, rect.top + rect.height() * ratio), radius, radius, paint);
        }
    }

    private void drawCommanderBanner(Canvas canvas) {
        float alpha = Math.min(1f, commanderBannerTimer / 0.45f);
        float w = Math.min(width * 0.72f, 850f * uiScale);
        float h = Math.max(62f * uiScale, height * 0.10f);
        RectF banner = new RectF((width - w) / 2f, height * 0.27f,
                (width + w) / 2f, height * 0.27f + h);
        paint.setColor(Color.argb((int) (205f * alpha), 50, 8, 12));
        canvas.drawRoundRect(banner, 18f * uiScale, 18f * uiScale, paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3f * uiScale);
        stroke.setColor(Color.argb((int) (235f * alpha), 255, 104, 84));
        canvas.drawRoundRect(banner, 18f * uiScale, 18f * uiScale, stroke);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(Math.max(25f * uiScale, h * 0.43f));
        paint.setColor(Color.argb((int) (255f * alpha), 255, 185, 112));
        canvas.drawText("DÜŞMAN KOMUTANI", banner.centerX(), banner.centerY() + paint.getTextSize() * 0.34f, paint);
    }

    private void drawBossBanner(Canvas canvas) {
        float alpha = Math.min(1f, bossBannerTimer / 0.55f);
        float w = Math.min(width * 0.78f, 940f * uiScale);
        float h = Math.max(72f * uiScale, height * 0.115f);
        RectF banner = new RectF((width - w) / 2f, height * 0.25f,
                (width + w) / 2f, height * 0.25f + h);
        paint.setColor(Color.argb((int) (220f * alpha), 57, 5, 10));
        canvas.drawRoundRect(banner, 20f * uiScale, 20f * uiScale, paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(4f * uiScale);
        stroke.setColor(Color.argb((int) (245f * alpha), 255, 83, 65));
        canvas.drawRoundRect(banner, 20f * uiScale, 20f * uiScale, stroke);
        drawCrown(canvas, banner.left + 55f * uiScale, banner.centerY(), 18f * uiScale, GOLD_LIGHT);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(Math.max(28f * uiScale, h * 0.44f));
        paint.setColor(Color.argb((int) (255f * alpha), 255, 184, 105));
        canvas.drawText(arenaMode ? "ARENA ŞAMPİYONU" : "BÖLÜM BOSSU", banner.centerX(), banner.centerY() + paint.getTextSize() * 0.34f, paint);
    }

    private void drawStatueShieldEffect(Canvas canvas) {
        float pulse = 0.88f + 0.08f * (float) Math.sin(ambientClock * 5f);
        float radiusX = 128f * uiScale * pulse;
        float radiusY = 225f * uiScale * pulse;
        paint.setShader(new RadialGradient(playerBaseX(), groundY - 105f * uiScale,
                radiusY, new int[]{Color.argb(38, 105, 231, 255), Color.TRANSPARENT},
                new float[]{0.15f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawOval(new RectF(playerBaseX() - radiusX, groundY - 105f * uiScale - radiusY,
                playerBaseX() + radiusX, groundY - 105f * uiScale + radiusY), paint);
        paint.setShader(null);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(4f * uiScale);
        stroke.setColor(Color.argb(190, 105, 231, 255));
        canvas.drawOval(new RectF(playerBaseX() - radiusX, groundY - 105f * uiScale - radiusY,
                playerBaseX() + radiusX, groundY - 105f * uiScale + radiusY), stroke);
    }

    private void drawArrowRainEffect(Canvas canvas) {
        float progress = 1f - arrowRainTimer / 1.35f;
        int arrowCount = 18;
        for (int i = 0; i < arrowCount; i++) {
            float local = (progress * 1.8f + i * 0.137f) % 1f;
            float offset = ((i * 97) % 620 - 310) * uiScale;
            float ax = arrowRainCenterX + offset;
            float ay = groundY - (460f - local * 445f) * uiScale;
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(2.2f * uiScale);
            stroke.setColor(Color.argb(220, 224, 226, 231));
            canvas.drawLine(ax - 12f * uiScale, ay - 28f * uiScale,
                    ax + 5f * uiScale, ay + 9f * uiScale, stroke);
            paint.setColor(Color.rgb(163, 126, 255));
            Path head = new Path();
            head.moveTo(ax + 5f * uiScale, ay + 9f * uiScale);
            head.lineTo(ax - 2f * uiScale, ay + 3f * uiScale);
            head.lineTo(ax + 9f * uiScale, ay + 1f * uiScale);
            head.close();
            canvas.drawPath(head, paint);
        }
        paint.setColor(Color.argb(30, 163, 126, 255));
        canvas.drawOval(new RectF(arrowRainCenterX - 350f * uiScale, groundY - 35f * uiScale,
                arrowRainCenterX + 350f * uiScale, groundY + 24f * uiScale), paint);
    }

    private int countCombatUnitsLocked(List<Unit> units) {
        int count = 0;
        for (Unit unit : units) {
            if (unit.hp > 0f && unit.type != UnitType.MINER && !unit.hero) count++;
        }
        return count;
    }

    private void drawUnitCard(Canvas canvas, RectF rect, UnitType type, String title, String cost,
                              String subtitle, boolean enabled) {
        float radius = Math.max(8f * uiScale, rect.height() * 0.12f);
        paint.setShader(new LinearGradient(rect.left, rect.top, rect.left, rect.bottom,
                enabled ? Color.rgb(47, 59, 76) : Color.rgb(42, 44, 49),
                enabled ? Color.rgb(11, 18, 30) : Color.rgb(23, 25, 29), Shader.TileMode.CLAMP));
        canvas.drawRoundRect(rect, radius, radius, paint);
        paint.setShader(null);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(Math.max(1.4f, 1.9f * uiScale));
        int accent = type == UnitType.MINER ? Color.rgb(238, 188, 81)
                : type == UnitType.SWORD ? Color.rgb(95, 174, 255)
                : type == UnitType.SPEAR ? Color.rgb(129, 218, 165)
                : Color.rgb(183, 137, 255);
        stroke.setColor(enabled ? accent : Color.rgb(88, 92, 101));
        canvas.drawRoundRect(rect, radius, radius, stroke);

        float cardPad = Math.max(5f, 6f * uiScale);
        float iconW = Math.min(rect.width() * 0.32f, rect.height() * 0.82f);
        RectF iconBox = new RectF(rect.left + cardPad, rect.top + cardPad,
                rect.left + cardPad + iconW, rect.bottom - cardPad);
        paint.setShader(new RadialGradient(iconBox.centerX(), iconBox.centerY(), iconBox.width() * 0.72f,
                new int[]{enabled ? Color.argb(130, Color.red(accent), Color.green(accent), Color.blue(accent))
                        : Color.argb(60, 120, 120, 120), Color.rgb(17, 24, 36)},
                new float[]{0f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(iconBox, 8f * uiScale, 8f * uiScale, paint);
        paint.setShader(null);
        drawUnitIcon(canvas, iconBox.centerX(), iconBox.centerY() + 6f * uiScale,
                Math.min(iconBox.width(), iconBox.height()) * 0.31f, type, enabled);

        float textLeft = iconBox.right + 8f * uiScale;
        float textAreaW = Math.max(36f, rect.right - textLeft - 7f * uiScale);
        paint.setTextAlign(Paint.Align.LEFT);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setColor(enabled ? Color.WHITE : Color.GRAY);
        paint.setTextSize(fitTextSize(title, Math.max(12f, rect.height() * 0.20f),
                Math.max(8.5f, rect.height() * 0.115f), textAreaW));
        canvas.drawText(title, textLeft, rect.top + rect.height() * 0.32f, paint);

        drawCoin(canvas, textLeft + 8f * uiScale, rect.top + rect.height() * 0.55f,
                Math.max(6f, 6.5f * uiScale));
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setColor(enabled ? GOLD_LIGHT : Color.DKGRAY);
        paint.setTextSize(Math.max(10f, rect.height() * 0.145f));
        canvas.drawText(cost, textLeft + 19f * uiScale, rect.top + rect.height() * 0.60f, paint);

        paint.setTypeface(Typeface.DEFAULT);
        paint.setColor(enabled ? Color.rgb(191, 202, 217) : Color.DKGRAY);
        paint.setTextSize(fitTextSize(subtitle, Math.max(8.5f, rect.height() * 0.105f),
                Math.max(7f, rect.height() * 0.083f), textAreaW));
        canvas.drawText(subtitle, textLeft, rect.bottom - 10f * uiScale, paint);
    }

    private void drawUnitIcon(Canvas canvas, float x, float y, float s, UnitType type, boolean enabled) {
        int c = enabled ? GOLD_LIGHT : Color.GRAY;
        paint.setColor(Color.rgb(44, 48, 55));
        canvas.drawCircle(x, y - s * 0.72f, s * 0.36f, paint);
        paint.setColor(c);
        canvas.drawCircle(x, y - s * 0.80f, s * 0.30f, paint);
        paint.setColor(Color.rgb(45, 49, 56));
        canvas.drawRoundRect(new RectF(x - s * 0.30f, y - s * 0.45f, x + s * 0.30f, y + s * 0.38f),
                s * 0.15f, s * 0.15f, paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        if (type == UnitType.MINER) {
            stroke.setColor(c);
            stroke.setStrokeWidth(Math.max(2f, s * 0.10f));
            canvas.drawLine(x - s * 0.25f, y - s * 0.05f, x + s * 0.42f, y - s * 0.67f, stroke);
            canvas.drawLine(x + s * 0.26f, y - s * 0.72f, x + s * 0.54f, y - s * 0.55f, stroke);
        } else if (type == UnitType.SWORD) {
            stroke.setColor(c);
            stroke.setStrokeWidth(Math.max(2f, s * 0.09f));
            canvas.drawLine(x + s * 0.12f, y - s * 0.05f, x + s * 0.62f, y - s * 0.73f, stroke);
            paint.setColor(enabled ? BLUE : Color.DKGRAY);
            canvas.drawOval(new RectF(x - s * 0.62f, y - s * 0.18f, x - s * 0.18f, y + s * 0.42f), paint);
        } else if (type == UnitType.SPEAR) {
            stroke.setColor(Color.rgb(138, 91, 49));
            stroke.setStrokeWidth(Math.max(2f, s * 0.09f));
            canvas.drawLine(x - s * 0.42f, y + s * 0.30f,
                    x + s * 0.65f, y - s * 0.76f, stroke);
            paint.setColor(c);
            Path iconHead = new Path();
            iconHead.moveTo(x + s * 0.78f, y - s * 0.89f);
            iconHead.lineTo(x + s * 0.53f, y - s * 0.76f);
            iconHead.lineTo(x + s * 0.66f, y - s * 0.63f);
            iconHead.close();
            canvas.drawPath(iconHead, paint);
        } else {
            stroke.setColor(c);
            stroke.setStrokeWidth(Math.max(2f, s * 0.08f));
            RectF bow = new RectF(x - s * 0.10f, y - s * 0.68f, x + s * 0.72f, y + s * 0.38f);
            canvas.drawArc(bow, -92f, 184f, false, stroke);
            canvas.drawLine(x + s * 0.30f, y - s * 0.65f, x + s * 0.30f, y + s * 0.35f, stroke);
        }
    }

    private void drawDeveloperPanel(Canvas canvas) {
        paint.setColor(Color.argb(72, 0, 0, 0));
        canvas.drawRect(0f, 0f, width, height, paint);

        RectF panel = new RectF(addGoldButton.left - 12f, addGoldButton.top - 48f,
                speedButton.right + 12f, speedButton.bottom + 12f);
        drawPanel(canvas, panel, 18f, true);

        paint.setTextAlign(Paint.Align.LEFT);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(18f * uiScale, height * (tabletLayout ? 0.022f : 0.030f)));
        paint.setColor(GOLD_LIGHT);
        canvas.drawText("GELİŞTİRİCİ MODU", panel.left + 18f, panel.top + 31f, paint);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(Math.max(12f, height * 0.019f));
        paint.setColor(Color.rgb(205, 211, 222));
        canvas.drawText("Dışarı dokun: kapat", panel.right - 76f, panel.top + 29f, paint);

        drawButton(canvas, addGoldButton, "+1000 ALTIN", "Anında ekle", true);
        drawButton(canvas, damageButton, "HASAR x" + trimMultiplier(damageMultiplier), "1 / 2 / 5 / 10", true);
        drawButton(canvas, godButton, godMode ? "ÖLÜMSÜZ: AÇIK" : "ÖLÜMSÜZ: KAPALI", "Heykel korunur", true);
        drawButton(canvas, speedButton, "HIZ x" + trimMultiplier(gameSpeed), "1x / 2x / 3x / 4x", true);
    }

    private String trimMultiplier(float value) {
        if (Math.abs(value - Math.round(value)) < 0.01f) return Integer.toString(Math.round(value));
        return String.format(Locale.US, "%.1f", value);
    }

    private float fitTextSize(String text, float maxSize, float minSize, float maxWidth) {
        paint.setTextSize(maxSize);
        float measured = Math.max(1f, paint.measureText(text));
        if (measured <= maxWidth) return maxSize;
        return Math.max(minSize, maxSize * maxWidth / measured);
    }

    private void drawPanel(Canvas canvas, RectF rect, float radius, boolean enabled) {
        paint.setStyle(Paint.Style.FILL);

        // Dış gölge ve koyu metal gövde.
        paint.setColor(Color.argb(110, 0, 0, 0));
        canvas.drawRoundRect(new RectF(rect.left + 4f * uiScale, rect.top + 6f * uiScale,
                rect.right + 4f * uiScale, rect.bottom + 6f * uiScale),
                radius, radius, paint);

        paint.setShader(new LinearGradient(rect.left, rect.top, rect.left, rect.bottom,
                enabled ? Color.rgb(31, 45, 66) : Color.rgb(55, 58, 64),
                enabled ? Color.rgb(8, 14, 25) : Color.rgb(31, 33, 37),
                Shader.TileMode.CLAMP));
        canvas.drawRoundRect(rect, radius, radius, paint);
        paint.setShader(null);

        // Üst yüzey parlaması kartlara derinlik verir.
        float sheenH = Math.max(4f * uiScale, rect.height() * 0.10f);
        paint.setShader(new LinearGradient(rect.left, rect.top, rect.left, rect.top + sheenH,
                enabled ? Color.argb(82, 255, 255, 255) : Color.argb(26, 255, 255, 255),
                Color.TRANSPARENT, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(new RectF(rect.left + 2f * uiScale, rect.top + 2f * uiScale,
                rect.right - 2f * uiScale, rect.top + sheenH),
                Math.max(3f, radius - 2f), Math.max(3f, radius - 2f), paint);
        paint.setShader(null);

        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(Math.max(2f, 2.4f * uiScale));
        stroke.setColor(enabled ? Color.argb(235, 226, 173, 62) : Color.rgb(85, 89, 96));
        canvas.drawRoundRect(rect, radius, radius, stroke);

        RectF inner = new RectF(rect.left + 5f * uiScale, rect.top + 5f * uiScale,
                rect.right - 5f * uiScale, rect.bottom - 5f * uiScale);
        stroke.setStrokeWidth(Math.max(1f, 1.1f * uiScale));
        stroke.setColor(enabled ? Color.argb(96, 255, 227, 150) : Color.argb(45, 220, 220, 220));
        canvas.drawRoundRect(inner, Math.max(3f, radius - 5f * uiScale),
                Math.max(3f, radius - 5f * uiScale), stroke);
    }

    private void drawMainButton(Canvas canvas, RectF rect, String title, String subtitle) {
        // Ana eylem düğmesi: altın çift çerçeve, merkez parlaması ve sağ ok.
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new RadialGradient(rect.centerX(), rect.centerY(),
                Math.max(rect.width(), rect.height()) * 0.60f,
                new int[]{Color.rgb(43, 61, 86), Color.rgb(12, 20, 35), Color.rgb(6, 11, 20)},
                new float[]{0f, 0.66f, 1f}, Shader.TileMode.CLAMP));
        paint.setShadowLayer(12f * uiScale, 0f, 6f * uiScale, Color.argb(220, 0, 0, 0));
        canvas.drawRoundRect(rect, 22f * uiScale, 22f * uiScale, paint);
        paint.clearShadowLayer();
        paint.setShader(null);

        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(Math.max(3f, 3.4f * uiScale));
        stroke.setColor(Color.rgb(236, 188, 73));
        canvas.drawRoundRect(rect, 22f * uiScale, 22f * uiScale, stroke);
        stroke.setStrokeWidth(Math.max(1.5f, 1.8f * uiScale));
        stroke.setColor(Color.argb(190, 255, 226, 142));
        canvas.drawRoundRect(new RectF(rect.left + 7f * uiScale, rect.top + 7f * uiScale,
                        rect.right - 7f * uiScale, rect.bottom - 7f * uiScale),
                15f * uiScale, 15f * uiScale, stroke);

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        float titleSize = fitTextSize(title, rect.height() * 0.37f,
                Math.max(20f, 22f * uiScale), rect.width() * 0.78f);
        paint.setTextSize(titleSize);
        paint.setShadowLayer(7f * uiScale, 0f, 3f * uiScale, Color.BLACK);
        paint.setColor(GOLD_LIGHT);
        canvas.drawText(title, rect.centerX(), rect.centerY() - rect.height() * 0.04f, paint);
        paint.clearShadowLayer();

        paint.setTypeface(Typeface.DEFAULT_BOLD);
        float subtitleSize = fitTextSize(subtitle, rect.height() * 0.17f,
                Math.max(10f, 11f * uiScale), rect.width() * 0.72f);
        paint.setTextSize(subtitleSize);
        paint.setColor(Color.rgb(220, 228, 238));
        canvas.drawText(subtitle, rect.centerX(), rect.centerY() + rect.height() * 0.29f, paint);

        float arrowX = rect.right - Math.max(26f * uiScale, rect.height() * 0.30f);
        float arrowR = Math.max(11f * uiScale, rect.height() * 0.12f);
        paint.setColor(Color.argb(46, 255, 216, 112));
        canvas.drawCircle(arrowX, rect.centerY(), arrowR * 1.45f, paint);
        stroke.setColor(GOLD_LIGHT);
        stroke.setStrokeWidth(Math.max(2f, 2.6f * uiScale));
        canvas.drawLine(arrowX - arrowR * 0.40f, rect.centerY() - arrowR * 0.55f,
                arrowX + arrowR * 0.25f, rect.centerY(), stroke);
        canvas.drawLine(arrowX + arrowR * 0.25f, rect.centerY(),
                arrowX - arrowR * 0.40f, rect.centerY() + arrowR * 0.55f, stroke);
    }

    private void drawButton(Canvas canvas, RectF rect, String title, String subtitle, boolean enabled) {
        float radius = Math.max(8f * uiScale, rect.height() * 0.15f);
        RectF shadowRect = new RectF(rect.left + 2f * uiScale, rect.top + 4f * uiScale,
                rect.right + 2f * uiScale, rect.bottom + 4f * uiScale);
        paint.setColor(Color.argb(130, 0, 0, 0));
        canvas.drawRoundRect(shadowRect, radius, radius, paint);

        int topColor = enabled ? Color.rgb(54, 65, 82) : Color.rgb(43, 46, 52);
        int bottomColor = enabled ? Color.rgb(13, 20, 33) : Color.rgb(24, 26, 31);
        paint.setShader(new LinearGradient(rect.left, rect.top, rect.left, rect.bottom,
                topColor, bottomColor, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(rect, radius, radius, paint);
        paint.setShader(null);

        float bevel = Math.max(3f * uiScale, rect.height() * 0.065f);
        paint.setColor(enabled ? Color.argb(80, 255, 224, 152) : Color.argb(34, 200, 200, 200));
        canvas.drawRoundRect(new RectF(rect.left + bevel, rect.top + bevel,
                rect.right - bevel, rect.top + bevel * 2.0f), radius * 0.55f, radius * 0.55f, paint);
        paint.setColor(Color.argb(95, 0, 0, 0));
        canvas.drawRoundRect(new RectF(rect.left + bevel, rect.bottom - bevel * 1.8f,
                rect.right - bevel, rect.bottom - bevel), radius * 0.45f, radius * 0.45f, paint);

        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(Math.max(1.4f, 2f * uiScale));
        stroke.setColor(enabled ? Color.rgb(208, 158, 63) : Color.rgb(91, 96, 105));
        canvas.drawRoundRect(rect, radius, radius, stroke);
        stroke.setStrokeWidth(Math.max(0.8f, 1f * uiScale));
        stroke.setColor(enabled ? Color.argb(155, 255, 225, 147) : Color.argb(90, 150, 150, 150));
        canvas.drawRoundRect(new RectF(rect.left + 4f * uiScale, rect.top + 4f * uiScale,
                rect.right - 4f * uiScale, rect.bottom - 4f * uiScale),
                Math.max(4f, radius - 3f * uiScale), Math.max(4f, radius - 3f * uiScale), stroke);

        float crestX = rect.left + Math.max(17f * uiScale, rect.height() * 0.22f);
        float crestS = Math.max(5f * uiScale, rect.height() * 0.075f);
        paint.setColor(enabled ? GOLD_LIGHT : Color.rgb(92, 96, 104));
        Path spearHead = new Path();
        spearHead.moveTo(crestX, rect.centerY() - crestS * 1.35f);
        spearHead.lineTo(crestX + crestS, rect.centerY());
        spearHead.lineTo(crestX, rect.centerY() + crestS * 1.35f);
        spearHead.lineTo(crestX - crestS, rect.centerY());
        spearHead.close();
        canvas.drawPath(spearHead, paint);
        stroke.setStrokeWidth(Math.max(1f, 1.2f * uiScale));
        stroke.setColor(enabled ? Color.rgb(104, 73, 34) : Color.rgb(57, 60, 66));
        canvas.drawLine(crestX, rect.centerY() - crestS * 0.60f,
                crestX, rect.centerY() + crestS * 0.60f, stroke);

        // Köşe zırh plakaları.
        float corner = Math.max(7f * uiScale, rect.height() * 0.11f);
        stroke.setStrokeWidth(Math.max(1.2f, 1.6f * uiScale));
        stroke.setColor(enabled ? Color.argb(180, 226, 173, 62) : Color.argb(100, 105, 110, 120));
        canvas.drawLine(rect.left + 5f * uiScale, rect.top + corner,
                rect.left + corner, rect.top + 5f * uiScale, stroke);
        canvas.drawLine(rect.right - 5f * uiScale, rect.top + corner,
                rect.right - corner, rect.top + 5f * uiScale, stroke);
        canvas.drawLine(rect.left + 5f * uiScale, rect.bottom - corner,
                rect.left + corner, rect.bottom - 5f * uiScale, stroke);
        canvas.drawLine(rect.right - 5f * uiScale, rect.bottom - corner,
                rect.right - corner, rect.bottom - 5f * uiScale, stroke);

        boolean compact = subtitle == null || subtitle.length() == 0 || rect.height() < 48f * uiScale;
        float usableW = rect.width() - Math.max(44f * uiScale, rect.height() * 0.38f);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        float titleMax = compact ? rect.height() * 0.35f : rect.height() * 0.27f;
        float titleSize = fitTextSize(title, titleMax,
                Math.max(10f, 11f * uiScale), usableW * 0.90f);
        paint.setTextSize(titleSize);
        paint.setColor(enabled ? Color.rgb(246, 243, 233) : Color.rgb(139, 143, 151));
        float textCenterX = rect.centerX() + crestS * 0.42f;
        float titleY = compact ? rect.centerY() + titleSize * 0.34f
                : rect.centerY() - rect.height() * 0.055f;
        canvas.drawText(title, textCenterX, titleY, paint);

        if (!compact) {
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            float subtitleSize = fitTextSize(subtitle, rect.height() * 0.145f,
                    Math.max(8f, 8.5f * uiScale), usableW * 0.92f);
            paint.setTextSize(subtitleSize);
            paint.setColor(enabled ? Color.rgb(188, 202, 219) : Color.rgb(92, 96, 104));
            canvas.drawText(subtitle, textCenterX,
                    rect.centerY() + rect.height() * 0.29f, paint);
        }
    }


    private void drawShopScreen(Canvas canvas) {
        drawScreenFrame(canvas, true);
        drawButton(canvas, backButton, "‹ ANA MENÜ", "Satın alımlar kaydedilir", true);

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(Math.min(tabletLayout ? 76f : 58f, width * 0.055f));
        paint.setColor(GOLD_LIGHT);
        paint.setShadowLayer(8f, 0f, 4f, Color.BLACK);
        canvas.drawText("ELMAS MAĞAZASI", width * 0.5f, height * 0.135f, paint);
        paint.clearShadowLayer();

        drawDiamondIcon(canvas, width * 0.5f - 72f * uiScale, height * 0.176f,
                14f * uiScale, Color.rgb(105, 231, 255));
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(16f, 21f * uiScale));
        paint.setColor(Color.WHITE);
        canvas.drawText("ELMAS: " + diamonds, width * 0.5f + 18f * uiScale, height * 0.184f, paint);

        drawButton(canvas, shopOutfitsTabButton, "KIYAFETLER", "Kozmetik görünüm", !shopPowerPage);
        drawButton(canvas, shopPowersTabButton, "KALICI GÜÇLER", "En fazla 3 seviye", shopPowerPage);

        if (!shopPowerPage) {
            drawOutfitCard(canvas, shopMinerOutfitButton, shopMinerBuyButton, UnitType.MINER,
                    minerOutfitOwned, minerOutfitEquipped);
            drawOutfitCard(canvas, shopSwordOutfitButton, shopSwordBuyButton, UnitType.SWORD,
                    swordOutfitOwned, swordOutfitEquipped);
            drawOutfitCard(canvas, shopSpearOutfitButton, shopSpearBuyButton, UnitType.SPEAR,
                    spearOutfitOwned, spearOutfitEquipped);
            drawOutfitCard(canvas, shopArcherOutfitButton, shopArcherBuyButton, UnitType.ARCHER,
                    archerOutfitOwned, archerOutfitEquipped);
        } else {
            drawDiamondPowerCard(canvas, shopStatuePowerButton, "HEYKEL MUHAFIZI",
                    diamondStatueBoost, "+%8 heykel canı ve +1 ordu sınırı", "statue");
            drawDiamondPowerCard(canvas, shopMinerPowerButton, "ELMAS USTASI",
                    diamondMinerBoost, "+%12 kazı/yük, +%6 madenci canı", "miner");
            drawDiamondPowerCard(canvas, shopSwordPowerButton, "ÇELİK YÜREK",
                    diamondSwordBoost, "+%8 savaşçı canı ve hasarı", "sword");
            drawDiamondPowerCard(canvas, shopArcherPowerButton, "ŞAHİN GÖZÜ",
                    diamondArcherBoost, "+%8 hasar, +%6 menzil", "archer");
        }

        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(Math.max(11f, 13f * uiScale));
        paint.setColor(Color.rgb(180, 194, 214));
        canvas.drawText(shopPowerPage
                        ? "Kalıcı güçler tüm savaşlarda ve maden kazısında etkilidir."
                        : "Kartın üstüne dokun: sahip olduğun kıyafeti değiştir. Alt düğme: yenisini satın al.",
                width * 0.5f, height - safePadding, paint);
    }

    private void drawOutfitCard(Canvas canvas, RectF card, RectF buyButton, UnitType type,
                                int owned, int equipped) {
        drawPanel(canvas, card, 20f * uiScale, true);
        int previewColor = outfitAccentColorLocked(equipped);
        drawOutfitPreview(canvas, card.centerX(), card.top + card.height() * 0.30f,
                Math.min(card.width(), card.height()) * 0.22f, type, equipped, previewColor);

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(16f, card.height() * 0.105f));
        paint.setColor(Color.WHITE);
        canvas.drawText(unitDisplayNameLocked(type), card.centerX(), card.top + card.height() * 0.52f, paint);
        paint.setTextSize(Math.max(14f, card.height() * 0.09f));
        paint.setColor(previewColor);
        canvas.drawText(outfitNameLocked(type, equipped), card.centerX(), card.top + card.height() * 0.64f, paint);
        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(Math.max(11f, card.height() * 0.066f));
        paint.setColor(Color.rgb(192, 202, 218));
        canvas.drawText("Açılan: " + (owned + 1) + " / 4  •  Giyilen: " + (equipped + 1),
                card.centerX(), card.top + card.height() * 0.74f, paint);

        int nextTier = owned + 1;
        boolean maxed = owned >= 3;
        String title = maxed ? "TÜM KIYAFETLER AÇIK" : "SATIN AL: " + outfitNameLocked(type, nextTier);
        String subtitle = maxed ? "Üst bölüme dokunarak değiştir"
                : outfitCostLocked(type, nextTier) + " ELMAS";
        drawButton(canvas, buyButton, title, subtitle, maxed || diamonds >= outfitCostLocked(type, nextTier));
    }

    private void drawOutfitPreview(Canvas canvas, float x, float y, float s, UnitType type,
                                   int tier, int accent) {
        float scale = Math.max(0.8f, s / 62f);
        int armor = tier == 0 ? Color.rgb(70, 76, 86)
                : tier == 1 ? Color.rgb(139, 151, 164)
                : tier == 2 ? Color.rgb(45, 72, 112)
                : Color.rgb(37, 27, 52);
        int cloth = tier == 0 ? BLUE : accent;
        paint.setColor(Color.argb(90, 0, 0, 0));
        canvas.drawOval(new RectF(x - 32f * scale, y + 34f * scale,
                x + 32f * scale, y + 44f * scale), paint);
        paint.setColor(armor);
        canvas.drawRoundRect(new RectF(x - 17f * scale, y - 22f * scale,
                x + 17f * scale, y + 30f * scale), 8f * scale, 8f * scale, paint);
        paint.setColor(cloth);
        canvas.drawRect(x - 16f * scale, y - 8f * scale, x + 16f * scale, y + 3f * scale, paint);
        paint.setColor(tier >= 2 ? GOLD_LIGHT : Color.rgb(174, 179, 187));
        canvas.drawCircle(x, y - 41f * scale, 17f * scale, paint);
        paint.setColor(armor);
        canvas.drawArc(new RectF(x - 20f * scale, y - 61f * scale,
                x + 20f * scale, y - 34f * scale), 180f, 180f, true, paint);
        if (tier >= 1) {
            paint.setColor(accent);
            canvas.drawRect(x - 18f * scale, y - 45f * scale, x + 18f * scale, y - 39f * scale, paint);
        }
        if (tier >= 2) drawCrown(canvas, x, y - 65f * scale, 9f * scale, GOLD_LIGHT);
        if (tier >= 3) {
            paint.setColor(Color.argb(90, Color.red(accent), Color.green(accent), Color.blue(accent)));
            canvas.drawCircle(x, y - 10f * scale, 42f * scale, paint);
        }
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeWidth(6f * scale);
        stroke.setColor(armor);
        canvas.drawLine(x - 7f * scale, y + 25f * scale, x - 20f * scale, y + 42f * scale, stroke);
        canvas.drawLine(x + 7f * scale, y + 25f * scale, x + 20f * scale, y + 42f * scale, stroke);
        if (type == UnitType.MINER) {
            stroke.setColor(Color.rgb(181, 128, 67));
            stroke.setStrokeWidth(4f * scale);
            canvas.drawLine(x + 10f * scale, y, x + 39f * scale, y - 30f * scale, stroke);
            canvas.drawLine(x + 29f * scale, y - 36f * scale, x + 45f * scale, y - 24f * scale, stroke);
        } else if (type == UnitType.SWORD) {
            stroke.setColor(Color.rgb(224, 228, 234));
            stroke.setStrokeWidth(5f * scale);
            canvas.drawLine(x + 12f * scale, y + 1f * scale, x + 42f * scale, y - 41f * scale, stroke);
            drawShield(canvas, x - 29f * scale, y + 2f * scale, 16f * scale, accent);
        } else if (type == UnitType.SPEAR) {
            stroke.setColor(tier >= 2 ? Color.rgb(225, 229, 236) : Color.rgb(164, 119, 67));
            stroke.setStrokeWidth(4.6f * scale);
            canvas.drawLine(x - 10f * scale, y + 26f * scale, x + 47f * scale, y - 50f * scale, stroke);
            paint.setColor(tier >= 2 ? GOLD_LIGHT : Color.rgb(201, 207, 216));
            Path tip = new Path();
            tip.moveTo(x + 47f * scale, y - 50f * scale);
            tip.lineTo(x + 36f * scale, y - 38f * scale);
            tip.lineTo(x + 51f * scale, y - 34f * scale);
            tip.close();
            canvas.drawPath(tip, paint);
            drawShield(canvas, x - 28f * scale, y + 3f * scale, 14f * scale, accent);
        } else {
            stroke.setColor(Color.rgb(181, 121, 60));
            stroke.setStrokeWidth(4f * scale);
            canvas.drawArc(new RectF(x + 4f * scale, y - 34f * scale,
                    x + 48f * scale, y + 28f * scale), -80f, 160f, false, stroke);
        }
    }

    private void drawDiamondPowerCard(Canvas canvas, RectF rect, String title, int level,
                                      String benefit, String target) {
        boolean maxed = level >= 3;
        int cost = diamondPowerCostLocked(level, "statue".equals(target));
        boolean affordable = !maxed && diamonds >= cost;
        drawPanel(canvas, rect, 18f * uiScale, true);
        float iconY = rect.top + rect.height() * 0.27f;
        drawDiamondIcon(canvas, rect.centerX(), iconY, Math.min(rect.width(), rect.height()) * 0.12f,
                maxed ? Color.rgb(123, 255, 186) : Color.rgb(105, 231, 255));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(14f, rect.height() * 0.095f));
        paint.setColor(Color.WHITE);
        canvas.drawText(title, rect.centerX(), rect.top + rect.height() * 0.49f, paint);
        paint.setTextSize(Math.max(13f, rect.height() * 0.085f));
        paint.setColor(GOLD_LIGHT);
        canvas.drawText("SEVİYE " + level + " / 3", rect.centerX(), rect.top + rect.height() * 0.61f, paint);
        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(Math.max(10f, rect.height() * 0.060f));
        paint.setColor(Color.rgb(194, 205, 222));
        canvas.drawText(benefit, rect.centerX(), rect.top + rect.height() * 0.73f, paint);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(12f, rect.height() * 0.075f));
        paint.setColor(maxed ? Color.rgb(123, 255, 186) : affordable ? GOLD_LIGHT : Color.rgb(166, 174, 190));
        canvas.drawText(maxed ? "AZAMİ GÜÇ" : "GÜÇLENDİR • " + cost + " ELMAS",
                rect.centerX(), rect.bottom - 18f * uiScale, paint);
    }

    private String unitDisplayNameLocked(UnitType type) {
        if (type == UnitType.MINER) return "MADENCİ";
        if (type == UnitType.SWORD) return "SAVAŞÇI";
        if (type == UnitType.SPEAR) return "MIZRAKLI";
        return "OKÇU";
    }

    private String outfitNameLocked(UnitType type, int tier) {
        if (type == UnitType.SPEAR) {
            if (tier <= 0) return "SINIR MIZRAKLISI";
            if (tier == 1) return "BRONZ FALANKS";
            if (tier == 2) return "KRALİYET MIZRAĞI";
            return "GÖLGE CENTURION";
        }
        if (tier <= 0) return "KLASİK BİRLİK";
        if (tier == 1) return "ÇELİK MUHAFIZ";
        if (tier == 2) return "KRALİYET ZIRHI";
        return "GÖLGE LEJYONU";
    }

    private int outfitAccentColorLocked(int tier) {
        if (tier <= 0) return BLUE;
        if (tier == 1) return Color.rgb(151, 206, 255);
        if (tier == 2) return GOLD_LIGHT;
        return Color.rgb(194, 112, 255);
    }

    private int outfitCostLocked(UnitType type, int tier) {
        int base = type == UnitType.MINER ? 3 : (type == UnitType.SWORD || type == UnitType.SPEAR) ? 4 : 5;
        if (tier <= 1) return base;
        if (tier == 2) return base * 2 + 3;
        return base * 4 + 5;
    }

    private int ownedOutfitLevelLocked(UnitType type) {
        if (type == UnitType.MINER) return minerOutfitOwned;
        if (type == UnitType.SWORD) return swordOutfitOwned;
        if (type == UnitType.SPEAR) return spearOutfitOwned;
        return archerOutfitOwned;
    }

    private int equippedOutfitLevelLocked(UnitType type) {
        if (type == UnitType.MINER) return minerOutfitEquipped;
        if (type == UnitType.SWORD) return swordOutfitEquipped;
        if (type == UnitType.SPEAR) return spearOutfitEquipped;
        return archerOutfitEquipped;
    }

    private void setOwnedOutfitLevelLocked(UnitType type, int value) {
        if (type == UnitType.MINER) minerOutfitOwned = value;
        else if (type == UnitType.SWORD) swordOutfitOwned = value;
        else if (type == UnitType.SPEAR) spearOutfitOwned = value;
        else archerOutfitOwned = value;
    }

    private void setEquippedOutfitLevelLocked(UnitType type, int value) {
        if (type == UnitType.MINER) minerOutfitEquipped = value;
        else if (type == UnitType.SWORD) swordOutfitEquipped = value;
        else if (type == UnitType.SPEAR) spearOutfitEquipped = value;
        else archerOutfitEquipped = value;
    }

    private void cycleOutfitLocked(UnitType type) {
        int owned = ownedOutfitLevelLocked(type);
        int next = (equippedOutfitLevelLocked(type) + 1) % (owned + 1);
        setEquippedOutfitLevelLocked(type, next);
        saveProgressLocked();
        showToastLocked(unitDisplayNameLocked(type) + " • " + outfitNameLocked(type, next));
    }

    private void tryBuyOutfitLocked(UnitType type) {
        int owned = ownedOutfitLevelLocked(type);
        if (owned >= 3) {
            showToastLocked("TÜM KIYAFETLER AÇIK");
            return;
        }
        int nextTier = owned + 1;
        int cost = outfitCostLocked(type, nextTier);
        if (diamonds < cost) {
            showToastLocked("YETERLİ ELMAS YOK • GEREKEN " + cost);
            return;
        }
        diamonds -= cost;
        setOwnedOutfitLevelLocked(type, nextTier);
        setEquippedOutfitLevelLocked(type, nextTier);
        saveProgressLocked();
        invalidateMenuCacheLocked();
        showToastLocked(outfitNameLocked(type, nextTier) + " AÇILDI");
    }

    private int diamondPowerCostLocked(int currentLevel, boolean statue) {
        int base = statue ? 7 : 5;
        return base + currentLevel * (statue ? 8 : 6);
    }

    private void tryBuyDiamondPowerLocked(String target) {
        int level;
        boolean statue = "statue".equals(target);
        if (statue) level = diamondStatueBoost;
        else if ("miner".equals(target)) level = diamondMinerBoost;
        else if ("sword".equals(target)) level = diamondSwordBoost;
        else level = diamondArcherBoost;
        if (level >= 3) {
            showToastLocked("AZAMİ ELMAS GÜCÜNE ULAŞTI");
            return;
        }
        int cost = diamondPowerCostLocked(level, statue);
        if (diamonds < cost) {
            showToastLocked("YETERLİ ELMAS YOK • GEREKEN " + cost);
            return;
        }
        diamonds -= cost;
        if (statue) diamondStatueBoost++;
        else if ("miner".equals(target)) diamondMinerBoost++;
        else if ("sword".equals(target)) diamondSwordBoost++;
        else diamondArcherBoost++;
        saveProgressLocked();
        invalidateMenuCacheLocked();
        resetGameLocked();
        showToastLocked("KALICI GÜÇLENDİRME TAMAMLANDI");
    }

    private void drawUpgradeScreen(Canvas canvas) {
        drawScreenFrame(canvas, true);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(Math.min(tabletLayout ? 78f : 58f, width * 0.055f));
        paint.setColor(GOLD_LIGHT);
        paint.setShadowLayer(8f, 0f, 4f, Color.BLACK);
        canvas.drawText("GELİŞTİRMELER", width / 2f, height * 0.17f, paint);
        paint.clearShadowLayer();

        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(17f, 21f * uiScale));
        paint.setColor(Color.WHITE);
        canvas.drawText("Geliştirme puanı: " + upgradePoints + "  •  Bölüm: " + campaignLevel,
                width / 2f, height * 0.235f, paint);
        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(Math.max(12f, 14f * uiScale));
        paint.setColor(Color.rgb(190, 202, 220));
        canvas.drawText("Her zafer puan kazandırır. Mızrak gücü ve menzili ayrı geliştirilir.",
                width / 2f, height * 0.275f, paint);

        drawButton(canvas, backButton, "‹ ANA MENÜ", "İlerlemeni kaydet", true);
        drawUpgradeCard(canvas, upgradeStatueButton, "SAVAŞÇI HEYKELİ", statueUpgradeLevel,
                "+430 can ve ordu sınırı", upgradeCost(statueUpgradeLevel, true), true, UnitType.SWORD);
        drawUpgradeCard(canvas, upgradeMinerButton, "MADENCİ", minerUpgradeLevel,
                "Daha hızlı kazı ve +9 yük", upgradeCost(minerUpgradeLevel, false), true, UnitType.MINER);
        drawUpgradeCard(canvas, upgradeSwordButton, "SAVAŞÇI", swordUpgradeLevel,
                "+can ve hasar", upgradeCost(swordUpgradeLevel, false), true, UnitType.SWORD);
        drawSpearUpgradeCard(canvas);
        drawUpgradeCard(canvas, upgradeArcherButton, "OKÇU", archerUpgradeLevel,
                isArcherUnlockedLocked() ? "+can ve hasar" : "Bölüm 3'te açılır",
                upgradeCost(archerUpgradeLevel, false), isArcherUnlockedLocked(), UnitType.ARCHER);

        String nextReward = nextRewardLabelLocked();
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(14f, 17f * uiScale));
        paint.setColor(GOLD_LIGHT);
        canvas.drawText(nextReward, width / 2f, height - safePadding * 1.25f, paint);
    }

    private void drawSpearUpgradeCard(Canvas canvas) {
        drawPanel(canvas, upgradeSpearCard, 18f * uiScale, true);
        float iconY = upgradeSpearCard.top + upgradeSpearCard.height() * 0.25f;
        drawUnitIcon(canvas, upgradeSpearCard.centerX(), iconY + 12f * uiScale,
                Math.min(upgradeSpearCard.width(), upgradeSpearCard.height()) * 0.15f,
                UnitType.SPEAR, true);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(Math.max(13f, upgradeSpearCard.height() * 0.115f));
        paint.setColor(Color.WHITE);
        canvas.drawText("MIZRAKLI BİRLİK", upgradeSpearCard.centerX(),
                upgradeSpearCard.top + upgradeSpearCard.height() * 0.50f, paint);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(10f, upgradeSpearCard.height() * 0.075f));
        paint.setColor(Color.rgb(205, 214, 226));
        canvas.drawText("Yakın saplama • Uzak atış x2", upgradeSpearCard.centerX(),
                upgradeSpearCard.top + upgradeSpearCard.height() * 0.62f, paint);
        drawSpearUpgradeSubButton(canvas, upgradeSpearPowerButton, "GÜÇ",
                spearPowerLevel, upgradeCost(spearPowerLevel, false));
        drawSpearUpgradeSubButton(canvas, upgradeSpearRangeButton, "MENZİL",
                spearRangeLevel, upgradeCost(spearRangeLevel, false));
    }

    private void drawSpearUpgradeSubButton(Canvas canvas, RectF rect, String label,
                                            int level, int cost) {
        boolean maxed = level >= 5;
        boolean affordable = !maxed && upgradePoints >= cost;
        paint.setShader(new LinearGradient(rect.left, rect.top, rect.left, rect.bottom,
                affordable ? Color.rgb(74, 58, 30) : Color.rgb(37, 43, 53),
                Color.rgb(13, 18, 28), Shader.TileMode.CLAMP));
        canvas.drawRoundRect(rect, 8f * uiScale, 8f * uiScale, paint);
        paint.setShader(null);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(Math.max(1.2f, 1.6f * uiScale));
        stroke.setColor(maxed ? Color.rgb(112, 220, 150) : affordable ? GOLD_LIGHT : Color.rgb(117, 125, 139));
        canvas.drawRoundRect(rect, 8f * uiScale, 8f * uiScale, stroke);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(9f, rect.height() * 0.28f));
        paint.setColor(Color.WHITE);
        canvas.drawText(label + " " + level + "/5", rect.centerX(), rect.top + rect.height() * 0.42f, paint);
        paint.setTextSize(Math.max(8f, rect.height() * 0.22f));
        paint.setColor(maxed ? Color.rgb(112, 220, 150) : affordable ? GOLD_LIGHT : Color.rgb(163, 171, 184));
        canvas.drawText(maxed ? "AZAMİ" : cost + " PUAN", rect.centerX(),
                rect.top + rect.height() * 0.78f, paint);
    }

    private void drawUpgradeCard(Canvas canvas, RectF rect, String title, int level,
                                 String benefit, int cost, boolean unlocked, UnitType type) {
        boolean maxed = level >= 5;
        boolean affordable = unlocked && !maxed && upgradePoints >= cost;
        drawPanel(canvas, rect, 18f * uiScale, unlocked);
        float iconY = rect.top + rect.height() * 0.32f;
        drawUnitIcon(canvas, rect.centerX(), iconY + 18f * uiScale,
                Math.min(rect.width(), rect.height()) * 0.18f, type, unlocked);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(15f, rect.height() * 0.13f));
        paint.setColor(unlocked ? Color.WHITE : Color.GRAY);
        canvas.drawText(title, rect.centerX(), rect.top + rect.height() * 0.56f, paint);
        paint.setTextSize(Math.max(13f, rect.height() * 0.105f));
        paint.setColor(GOLD_LIGHT);
        canvas.drawText("SEVİYE " + level + " / 5", rect.centerX(), rect.top + rect.height() * 0.69f, paint);
        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(Math.max(10f, rect.height() * 0.078f));
        paint.setColor(unlocked ? Color.rgb(195, 205, 220) : Color.GRAY);
        canvas.drawText(benefit, rect.centerX(), rect.top + rect.height() * 0.79f, paint);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(12f, rect.height() * 0.09f));
        paint.setColor(maxed ? Color.rgb(112, 220, 150) : affordable ? GOLD_LIGHT : Color.rgb(170, 176, 188));
        String action = !unlocked ? "KİLİTLİ" : maxed ? "AZAMİ SEVİYE" : "GELİŞTİR  •  " + cost + " PUAN";
        canvas.drawText(action, rect.centerX(), rect.bottom - 13f * uiScale, paint);
    }

    private String nextRewardLabelLocked() {
        if (campaignLevel < 2) return "SONRAKİ ÖDÜL: Bölüm 2 • Çelik Kılıç + Barikat";
        if (campaignLevel < 3) return "SONRAKİ ÖDÜL: Bölüm 3 • Okçu Birliği";
        if (campaignLevel < 4) return "SONRAKİ ÖDÜL: Bölüm 4 • Okçu Kulesi";
        if (campaignLevel < 5) return "SONRAKİ ÖDÜL: Bölüm 5 • Kraliyet Kılıcı";
        if (campaignLevel < 6) return "SONRAKİ ÖDÜL: Bölüm 6 • Uzun Yay";
        if (campaignLevel < 8) return "SONRAKİ ÖDÜL: Bölüm 8 • Efsane Kılıç";
        return "TÜM ANA ÖDÜLLER AÇILDI";
    }

    private void drawArenaResultScreen(Canvas canvas) {
        paint.setColor(Color.argb(235, 3, 5, 14));
        canvas.drawRect(0f, 0f, width, height, paint);

        float panelW = Math.min(width * 0.86f, (tabletLayout ? 1180f : 920f) * uiScale);
        float panelH = Math.min(height * 0.78f, (tabletLayout ? 690f : 530f) * uiScale);
        RectF panel = new RectF((width - panelW) * 0.5f, height * 0.10f,
                (width + panelW) * 0.5f, height * 0.10f + panelH);
        drawPanel(canvas, panel, 28f * uiScale, true);

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(Math.max(32f * uiScale, Math.min(64f * uiScale, panel.height() * 0.12f)));
        paint.setColor(Color.rgb(218, 179, 255));
        canvas.drawText("ARENA SONUÇLARI", panel.centerX(), panel.top + panel.height() * 0.16f, paint);

        boolean anyRecord = arenaNewWaveRecord || arenaNewKillRecord;
        if (anyRecord) {
            RectF record = new RectF(panel.centerX() - panel.width() * 0.28f,
                    panel.top + panel.height() * 0.20f, panel.centerX() + panel.width() * 0.28f,
                    panel.top + panel.height() * 0.29f);
            paint.setColor(Color.argb(215, 62, 25, 96));
            canvas.drawRoundRect(record, 18f * uiScale, 18f * uiScale, paint);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(2.5f * uiScale);
            stroke.setColor(Color.rgb(224, 177, 255));
            canvas.drawRoundRect(record, 18f * uiScale, 18f * uiScale, stroke);
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            paint.setTextSize(Math.max(16f * uiScale, record.height() * 0.38f));
            paint.setColor(Color.WHITE);
            canvas.drawText("★ YENİ ARENA REKORU ★", record.centerX(),
                    record.centerY() + paint.getTextSize() * 0.34f, paint);
        }

        float cardsTop = panel.top + panel.height() * (anyRecord ? 0.34f : 0.28f);
        float gap = 12f * uiScale;
        float cardW = (panel.width() - gap * 5f) / 4f;
        float cardH = panel.height() * 0.24f;
        String[] labels = {"ULAŞILAN DALGA", "YENİLEN DÜŞMAN", "ŞAMPİYON", "KAZANILAN ELMAS"};
        String[] values = {Integer.toString(wave), Integer.toString(arenaKillsThisRun),
                Integer.toString(arenaChampionsThisRun), "+" + arenaRunDiamondReward};
        int[] accents = {Color.rgb(206, 165, 255), Color.rgb(255, 132, 106),
                GOLD_LIGHT, Color.rgb(105, 231, 255)};
        for (int i = 0; i < 4; i++) {
            float left = panel.left + gap + i * (cardW + gap);
            RectF card = new RectF(left, cardsTop, left + cardW, cardsTop + cardH);
            drawPanel(canvas, card, 18f * uiScale, false);
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            paint.setTextSize(Math.max(10f * uiScale, card.height() * 0.12f));
            paint.setColor(Color.rgb(182, 193, 213));
            canvas.drawText(labels[i], card.centerX(), card.top + card.height() * 0.30f, paint);
            paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
            paint.setTextSize(Math.max(28f * uiScale, card.height() * 0.37f));
            paint.setColor(accents[i]);
            canvas.drawText(values[i], card.centerX(), card.top + card.height() * 0.69f, paint);
        }

        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(15f * uiScale, panel.height() * 0.035f));
        paint.setColor(Color.WHITE);
        canvas.drawText("Profil XP  +" + arenaRunXpReward + "   •   Rekor dalga " + arenaBestWave
                        + "   •   Rekor düşman " + arenaBestKills,
                panel.centerX(), panel.top + panel.height() * 0.70f, paint);

        RectF reward = new RectF(panel.left + panel.width() * 0.16f, panel.top + panel.height() * 0.76f,
                panel.right - panel.width() * 0.16f, panel.top + panel.height() * 0.87f);
        paint.setColor(Color.argb(210, 17, 26, 46));
        canvas.drawRoundRect(reward, 16f * uiScale, 16f * uiScale, paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(2f * uiScale);
        stroke.setColor(Color.argb(190, 226, 173, 62));
        canvas.drawRoundRect(reward, 16f * uiScale, 16f * uiScale, stroke);
        paint.setTextSize(Math.max(13f * uiScale, reward.height() * 0.28f));
        paint.setColor(GOLD_LIGHT);
        canvas.drawText(arenaRunDiamondReward > 0
                        ? "Dalga ve koşu ödülleri hesabına eklendi"
                        : "Bir sonraki elmas ödülü için 3. dalgaya ulaş",
                reward.centerX(), reward.centerY() + paint.getTextSize() * 0.34f, paint);

        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(Math.max(13f * uiScale, panel.height() * 0.030f));
        paint.setColor(Color.rgb(205, 214, 229));
        canvas.drawText("Ekrana dokunarak ana menüye dön", panel.centerX(),
                panel.bottom - panel.height() * 0.055f, paint);
    }

    private void drawResult(Canvas canvas) {
        boolean arenaResult = arenaMode && screen == Screen.LOSE;
        if (arenaResult) {
            drawArenaResultScreen(canvas);
            return;
        }
        paint.setColor(Color.argb(225, 4, 8, 16));
        canvas.drawRect(0f, 0f, width, height, paint);
        float resultW = Math.min(width * 0.72f, (tabletLayout ? 820f : 620f) * uiScale);
        float resultH = Math.min(height * 0.48f, (tabletLayout ? 430f : 330f) * uiScale);
        RectF result = new RectF((width - resultW) / 2f, height * 0.24f,
                (width + resultW) / 2f, height * 0.24f + resultH);
        drawPanel(canvas, result, 24f, true);
        drawCrest(canvas, width / 2f, result.top + result.height() * 0.22f,
                Math.max(28f, height * 0.05f), screen == Screen.WIN ? GOLD : RED);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(Math.min(70f, width * 0.065f));
        paint.setColor(screen == Screen.WIN ? GOLD_LIGHT : Color.rgb(245, 100, 87));
        canvas.drawText(screen == Screen.WIN ? "BÖLÜM TAMAMLANDI" : "HEYKEL YIKILDI",
                width / 2f, height * 0.48f, paint);
        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(Math.max(16f, height * 0.032f));
        paint.setColor(Color.WHITE);
        canvas.drawText("Ekrana dokunarak ana menüye dön", width / 2f, height * 0.56f, paint);
        if (screen == Screen.WIN) {
            for (int star = 0; star < 3; star++) {
                drawMapStar(canvas, width / 2f + (star - 1) * 42f * uiScale,
                        height * 0.605f, 14f * uiScale, star < earnedStarsThisBattle);
            }
            String resultLine = firstClearBattle
                    ? "Bölüm " + completedLevel + " tamamlandı  •  +" + earnedUpgradePoints + " geliştirme puanı"
                    : "Bölüm " + completedLevel + " tekrar tamamlandı"
                    + (replayRewardDiamonds > 0 ? "  •  +" + replayRewardDiamonds + " elmas" : "");
            paint.setColor(Color.WHITE);
            canvas.drawText(resultLine, width / 2f, height * 0.66f, paint);
            if (firstClearBattle) {
                String reward = levelRewardForReachedLevelLocked(campaignLevel);
                if (!reward.isEmpty()) {
                    paint.setColor(GOLD_LIGHT);
                    canvas.drawText(reward, width / 2f, height * 0.71f, paint);
                }
                if (earnedChapterDiamonds > 0 || earnedChapterPoints > 0) {
                    paint.setColor(Color.rgb(202, 162, 255));
                    canvas.drawText("KRALLIK ÖDÜLÜ • +" + earnedChapterDiamonds
                                    + " elmas • +" + earnedChapterPoints + " puan",
                            width / 2f, height * 0.76f, paint);
                }
            }
        } else {
            canvas.drawText("Bölüm " + battleLevel + "  •  Ulaşılan dalga: " + wave, width / 2f, height * 0.62f, paint);
        }
    }

    private void drawToast(Canvas canvas) {
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(16f, height * 0.027f));
        float toastWidth = Math.min(width * 0.62f, Math.max(260f, paint.measureText(toastText) + 74f));
        RectF box = new RectF((width - toastWidth) / 2f, height * 0.13f,
                (width + toastWidth) / 2f, height * 0.13f + 50f);
        drawPanel(canvas, box, 16f, true);
        paint.setColor(Color.WHITE);
        canvas.drawText(toastText, width / 2f, box.centerY() + 7f, paint);
    }

    private void drawCoin(Canvas canvas, float x, float y, float r) {
        paint.setColor(Color.rgb(132, 88, 24));
        canvas.drawCircle(x, y, r + 2f, paint);
        paint.setColor(GOLD_LIGHT);
        canvas.drawCircle(x, y, r, paint);
        paint.setColor(Color.rgb(181, 122, 33));
        canvas.drawCircle(x, y, r * 0.62f, paint);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(r * 1.05f);
        paint.setColor(GOLD_LIGHT);
        canvas.drawText("S", x, y + r * 0.38f, paint);
    }

    private void drawCrossedSwords(Canvas canvas, float x, float y, float s, int color) {
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(Math.max(2f, s * 0.18f));
        stroke.setColor(color);
        canvas.drawLine(x - s * 0.65f, y - s * 0.65f, x + s * 0.65f, y + s * 0.65f, stroke);
        canvas.drawLine(x + s * 0.65f, y - s * 0.65f, x - s * 0.65f, y + s * 0.65f, stroke);
        stroke.setStrokeWidth(Math.max(1.5f, s * 0.12f));
        canvas.drawLine(x - s * 0.78f, y - s * 0.50f, x - s * 0.48f, y - s * 0.80f, stroke);
        canvas.drawLine(x + s * 0.78f, y - s * 0.50f, x + s * 0.48f, y - s * 0.80f, stroke);
    }

    private void drawShield(Canvas canvas, float x, float y, float s, int color) {
        Path shield = new Path();
        shield.moveTo(x, y - s);
        shield.lineTo(x + s * 0.72f, y - s * 0.55f);
        shield.lineTo(x + s * 0.58f, y + s * 0.35f);
        shield.lineTo(x, y + s);
        shield.lineTo(x - s * 0.58f, y + s * 0.35f);
        shield.lineTo(x - s * 0.72f, y - s * 0.55f);
        shield.close();
        paint.setColor(Color.rgb(35, 42, 52));
        canvas.drawPath(shield, paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(Math.max(1.5f, s * 0.12f));
        stroke.setColor(color);
        canvas.drawPath(shield, stroke);
    }

    private void drawCrest(Canvas canvas, float x, float y, float s, int color) {
        drawShield(canvas, x, y + s * 0.36f, s * 0.72f, color);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(Math.max(2f, s * 0.10f));
        stroke.setColor(color);
        canvas.drawLine(x, y - s * 0.18f, x, y + s * 0.78f, stroke);
        canvas.drawLine(x - s * 0.28f, y + s * 0.22f, x + s * 0.28f, y + s * 0.22f, stroke);
        drawCrown(canvas, x, y - s * 0.55f, s * 0.35f, color);
    }

    private void drawCrown(Canvas canvas, float x, float y, float s, int color) {
        Path crown = new Path();
        crown.moveTo(x - s, y + s * 0.55f);
        crown.lineTo(x - s * 0.78f, y - s * 0.42f);
        crown.lineTo(x - s * 0.26f, y + s * 0.02f);
        crown.lineTo(x, y - s * 0.62f);
        crown.lineTo(x + s * 0.26f, y + s * 0.02f);
        crown.lineTo(x + s * 0.78f, y - s * 0.42f);
        crown.lineTo(x + s, y + s * 0.55f);
        crown.close();
        paint.setColor(color);
        canvas.drawPath(crown, paint);
        canvas.drawRect(x - s, y + s * 0.48f, x + s, y + s * 0.78f, paint);
    }

    private void showToastLocked(String text) {
        toastText = text;
        toastTimer = 1.7f;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        synchronized (stateLock) {
            float x = event.getX();
            float y = event.getY();
            int action = event.getAction();

            if (fatalError != null) return true;
            if (action == MotionEvent.ACTION_DOWN) {
                touchDownX = x;
                touchDownY = y;
                touchStartCameraX = cameraX;
                cameraDragging = false;
                cameraDragEligible = screen == Screen.PLAYING
                        && y > arrowRainButton.bottom + 6f * uiScale
                        && y < (unitMenuOpen ? minerButton.top : quickUnitButton.top) - 6f * uiScale
                        && !developerPanel && !tacticalPanel;
                return true;
            }
            if (action == MotionEvent.ACTION_MOVE) {
                if (cameraDragEligible) {
                    float dx = x - touchDownX;
                    if (Math.abs(dx) > 10f * uiScale) cameraDragging = true;
                    if (cameraDragging) {
                        float maxCamera = Math.max(0f, worldWidth - width);
                        cameraX = Math.max(0f, Math.min(maxCamera, touchStartCameraX - dx));
                        manualCameraHoldTimer = 3.8f;
                    }
                }
                return true;
            }
            if (action == MotionEvent.ACTION_CANCEL) {
                cameraDragEligible = false;
                cameraDragging = false;
                return true;
            }
            if (action != MotionEvent.ACTION_UP) return true;
            if (cameraDragging) {
                cameraDragEligible = false;
                cameraDragging = false;
                manualCameraHoldTimer = 3.8f;
                return true;
            }
            cameraDragEligible = false;

            if (screen == Screen.MENU) {
                if (categoryBattleButton.contains(x, y)) {
                    screen = Screen.HUB_BATTLE;
                    return true;
                }
                if (categoryProgressButton.contains(x, y)) {
                    screen = Screen.HUB_PROGRESS;
                    return true;
                }
                if (categoryEconomyButton.contains(x, y)) {
                    screen = Screen.HUB_ECONOMY;
                    return true;
                }
                if (categorySystemButton.contains(x, y)) {
                    screen = Screen.HUB_SYSTEM;
                    return true;
                }
                if (startButton.contains(x, y)) {
                    startBattleLocked(campaignLevel);
                }
                return true;
            }

            if (screen == Screen.HUB_BATTLE) {
                if (backButton.contains(x, y)) {
                    screen = Screen.MENU;
                    invalidateMenuCacheLocked();
                    return true;
                }
                if (hubPrimaryButton.contains(x, y)) {
                    startBattleLocked(campaignLevel);
                    return true;
                }
                if (hubSecondaryButton.contains(x, y)) {
                    mapPage = Math.max(0, Math.min(4, (mapSelectedLevel - 1) / 10));
                    screen = Screen.MAP;
                    return true;
                }
                if (hubTertiaryButton.contains(x, y)) {
                    screen = Screen.ARENA;
                    return true;
                }
                return true;
            }

            if (screen == Screen.HUB_PROGRESS) {
                if (backButton.contains(x, y)) {
                    screen = Screen.MENU;
                    invalidateMenuCacheLocked();
                    return true;
                }
                if (hubPrimaryButton.contains(x, y)) {
                    screen = Screen.HERO;
                    return true;
                }
                if (hubSecondaryButton.contains(x, y)) {
                    screen = Screen.UPGRADES;
                    return true;
                }
                if (hubTertiaryButton.contains(x, y)) {
                    ensureDailyMissionsLocked();
                    missionsAchievementsPage = false;
                    screen = Screen.MISSIONS;
                    return true;
                }
                return true;
            }

            if (screen == Screen.HUB_ECONOMY) {
                if (backButton.contains(x, y)) {
                    screen = Screen.MENU;
                    invalidateMenuCacheLocked();
                    return true;
                }
                if (hubPrimaryButton.contains(x, y)) {
                    prepareMineLayerLocked();
                    screen = Screen.MINE;
                    return true;
                }
                if (hubSecondaryButton.contains(x, y)) {
                    shopPowerPage = false;
                    screen = Screen.SHOP;
                    return true;
                }
                if (hubTertiaryButton.contains(x, y)) {
                    shopPowerPage = true;
                    screen = Screen.SHOP;
                    return true;
                }
                return true;
            }

            if (screen == Screen.HUB_SYSTEM) {
                if (backButton.contains(x, y)) {
                    screen = Screen.MENU;
                    invalidateMenuCacheLocked();
                    return true;
                }
                if (hubPrimaryButton.contains(x, y) || hubSecondaryButton.contains(x, y)) {
                    fullResetArmed = false;
                    resetConfirmTimer = 0f;
                    screen = Screen.SETTINGS;
                    return true;
                }
                if (hubTertiaryButton.contains(x, y)) {
                    showToastLocked("UYGAR WARS v0.5.3 • kritik vuruş, zırh ve hasar türleri");
                    return true;
                }
                return true;
            }

            if (screen == Screen.ARENA) {
                if (backButton.contains(x, y)) {
                    screen = Screen.MENU;
                    invalidateMenuCacheLocked();
                    return true;
                }
                if (arenaStartButton.contains(x, y)) {
                    startArenaLocked();
                    return true;
                }
                return true;
            }

            if (screen == Screen.MAP) {
                if (backButton.contains(x, y)) {
                    screen = Screen.MENU;
                    invalidateMenuCacheLocked();
                    return true;
                }
                if (mapPrevButton.contains(x, y) && mapPage > 0) {
                    mapPage--;
                    invalidateSceneCachesLocked();
                    return true;
                }
                int maxMapPage = Math.max(0, Math.min(4, (campaignLevel - 1) / 10));
                if (mapNextButton.contains(x, y) && mapPage < maxMapPage) {
                    mapPage++;
                    invalidateSceneCachesLocked();
                    return true;
                }
                int pageStart = mapPage * 10 + 1;
                for (int index = 0; index < mapLevelButtons.length; index++) {
                    int level = pageStart + index;
                    if (level <= campaignLevel && mapLevelButtons[index].contains(x, y)) {
                        mapSelectedLevel = level;
                        return true;
                    }
                }
                if (mapStartButton.contains(x, y)) {
                    startBattleLocked(mapSelectedLevel);
                    return true;
                }
                return true;
            }

            if (screen == Screen.MISSIONS) {
                ensureDailyMissionsLocked();
                if (backButton.contains(x, y)) {
                    saveProgressLocked();
                    invalidateMenuCacheLocked();
                    screen = Screen.MENU;
                    return true;
                }
                if (missionDailyTabButton.contains(x, y)) {
                    missionsAchievementsPage = false;
                    return true;
                }
                if (missionAchievementTabButton.contains(x, y)) {
                    missionsAchievementsPage = true;
                    return true;
                }
                if (!missionsAchievementsPage) {
                    if (dailyWinButton.contains(x, y)) claimDailyMissionLocked(0);
                    else if (dailyMineButton.contains(x, y)) claimDailyMissionLocked(1);
                    else if (dailyKillButton.contains(x, y)) claimDailyMissionLocked(2);
                    else if (dailyChestButton.contains(x, y)) claimDailyChestLocked();
                    else if (battleChestButton.contains(x, y)) claimBattleChestLocked();
                } else {
                    for (int index = 0; index < achievementButtons.length; index++) {
                        if (achievementButtons[index].contains(x, y)) {
                            claimAchievementLocked(index);
                            break;
                        }
                    }
                }
                return true;
            }

            if (screen == Screen.HERO) {
                if (backButton.contains(x, y)) {
                    saveProgressLocked();
                    invalidateMenuCacheLocked();
                    screen = Screen.MENU;
                    return true;
                }
                if (heroPowerButton.contains(x, y)) tryUpgradeHeroTraitLocked("power");
                else if (heroArmorButton.contains(x, y)) tryUpgradeHeroTraitLocked("armor");
                else if (heroLeadershipButton.contains(x, y)) tryUpgradeHeroTraitLocked("leadership");
                return true;
            }

            if (screen == Screen.UPGRADES) {
                if (backButton.contains(x, y)) {
                    screen = Screen.MENU;
                    invalidateMenuCacheLocked();
                    return true;
                }
                if (upgradeStatueButton.contains(x, y)) tryUpgradeLocked("statue");
                else if (upgradeMinerButton.contains(x, y)) tryUpgradeLocked("miner");
                else if (upgradeSwordButton.contains(x, y)) tryUpgradeLocked("sword");
                else if (upgradeSpearPowerButton.contains(x, y)) tryUpgradeLocked("spear_power");
                else if (upgradeSpearRangeButton.contains(x, y)) tryUpgradeLocked("spear_range");
                else if (upgradeArcherButton.contains(x, y)) tryUpgradeLocked("archer");
                return true;
            }

            if (screen == Screen.SHOP) {
                if (backButton.contains(x, y)) {
                    saveProgressLocked();
                    invalidateMenuCacheLocked();
                    screen = Screen.MENU;
                    return true;
                }
                if (shopOutfitsTabButton.contains(x, y)) {
                    shopPowerPage = false;
                    return true;
                }
                if (shopPowersTabButton.contains(x, y)) {
                    shopPowerPage = true;
                    return true;
                }
                if (!shopPowerPage) {
                    if (shopMinerBuyButton.contains(x, y)) tryBuyOutfitLocked(UnitType.MINER);
                    else if (shopSwordBuyButton.contains(x, y)) tryBuyOutfitLocked(UnitType.SWORD);
                    else if (shopSpearBuyButton.contains(x, y)) tryBuyOutfitLocked(UnitType.SPEAR);
                    else if (shopArcherBuyButton.contains(x, y)) tryBuyOutfitLocked(UnitType.ARCHER);
                    else if (shopMinerOutfitButton.contains(x, y)) cycleOutfitLocked(UnitType.MINER);
                    else if (shopSwordOutfitButton.contains(x, y)) cycleOutfitLocked(UnitType.SWORD);
                    else if (shopSpearOutfitButton.contains(x, y)) cycleOutfitLocked(UnitType.SPEAR);
                    else if (shopArcherOutfitButton.contains(x, y)) cycleOutfitLocked(UnitType.ARCHER);
                } else {
                    if (shopStatuePowerButton.contains(x, y)) tryBuyDiamondPowerLocked("statue");
                    else if (shopMinerPowerButton.contains(x, y)) tryBuyDiamondPowerLocked("miner");
                    else if (shopSwordPowerButton.contains(x, y)) tryBuyDiamondPowerLocked("sword");
                    else if (shopArcherPowerButton.contains(x, y)) tryBuyDiamondPowerLocked("archer");
                }
                return true;
            }

            if (screen == Screen.MINE) {
                if (backButton.contains(x, y)) {
                    saveProgressLocked();
                    invalidateMenuCacheLocked();
                    screen = Screen.MENU;
                    return true;
                }
                if (mineDigButton.contains(x, y)) manualMineHitLocked();
                return true;
            }

            if (screen == Screen.SETTINGS) {
                if (backButton.contains(x, y)) {
                    fullResetArmed = false;
                    resetConfirmTimer = 0f;
                    screen = Screen.MENU;
                    invalidateMenuCacheLocked();
                    return true;
                }
                if (musicToggleButton.contains(x, y)) {
                    musicEnabled = !musicEnabled;
                    preferences.edit().putInt("music_enabled", musicEnabled ? 1 : 0).apply();
                    if (musicEnabled) {
                        currentMusicTrack = -1;
                        updateMusicForScreenLocked();
                        showToastLocked("MÜZİK AÇILDI");
                    } else {
                        stopMusicLocked();
                        showToastLocked("MÜZİK KAPATILDI");
                    }
                    return true;
                }
                if (effectsToggleButton.contains(x, y)) {
                    effectsEnabled = !effectsEnabled;
                    preferences.edit().putInt("effects_enabled", effectsEnabled ? 1 : 0).apply();
                    if (effectsEnabled) {
                        playSoundLocked(sndShield, 0.82f, 1.08f);
                        showToastLocked("EFEKTLER AÇILDI");
                    } else {
                        showToastLocked("EFEKTLER KAPATILDI");
                    }
                    return true;
                }
                if (musicVolumeButton.contains(x, y)) {
                    musicVolumeLevel = musicVolumeLevel >= 4 ? 1 : musicVolumeLevel + 1;
                    preferences.edit().putInt("music_volume_level", musicVolumeLevel).apply();
                    applyMusicVolumeLocked();
                    showToastLocked("MÜZİK SEVİYESİ %" + musicVolumePercentLocked());
                    return true;
                }
                if (effectsVolumeButton.contains(x, y)) {
                    effectsVolumeLevel = effectsVolumeLevel >= 4 ? 1 : effectsVolumeLevel + 1;
                    preferences.edit().putInt("effects_volume_level", effectsVolumeLevel).apply();
                    playSoundLocked(sndSwordHit, 0.90f, 1.02f);
                    showToastLocked("EFEKT SEVİYESİ %" + effectsVolumePercentLocked());
                    return true;
                }
                if (resetLevelButton.contains(x, y)) {
                    campaignLevel = 1;
                    battleLevel = 1;
                    mapSelectedLevel = 1;
                    mapPage = 0;
                    wins = 0;
                    clearCampaignRecordsLocked();
                    resetGameLocked();
                    saveProgressLocked();
                    invalidateMenuCacheLocked();
                    showToastLocked("BÖLÜM İLERLEMESİ SIFIRLANDI");
                    return true;
                }
                if (resetProgressButton.contains(x, y)) {
                    if (!fullResetArmed) {
                        fullResetArmed = true;
                        resetConfirmTimer = 5f;
                        showToastLocked("ONAY İÇİN TEKRAR DOKUN");
                    } else {
                        resetAllProgressLocked();
                        showToastLocked("TÜM İLERLEME SIFIRLANDI");
                    }
                    return true;
                }
                return true;
            }

            if (screen == Screen.PAUSED) {
                if (pauseContinueButton.contains(x, y)) {
                    screen = Screen.PLAYING;
                    lastFrame = SystemClock.uptimeMillis();
                    return true;
                }
                if (pauseRestartButton.contains(x, y)) {
                    if (arenaMode) {
                        startArenaLocked();
                    } else {
                        resetGameLocked();
                        spawnPlayerHeroLocked();
                        screen = Screen.PLAYING;
                        waveBannerTimer = 1.4f;
                        showToastLocked("BÖLÜM YENİDEN BAŞLADI");
                    }
                    return true;
                }
                if (pauseMenuButton.contains(x, y)) {
                    resetGameLocked();
                    arenaMode = false;
                    screen = Screen.MENU;
                    invalidateMenuCacheLocked();
                    return true;
                }
                return true;
            }

            if (screen == Screen.WIN || screen == Screen.LOSE) {
                resetGameLocked();
                arenaMode = false;
                updateResponsiveMetricsLocked();
                screen = Screen.MENU;
                invalidateMenuCacheLocked();
                return true;
            }

            if (pauseButton.contains(x, y)) {
                developerPanel = false;
                tacticalPanel = false;
                unitMenuOpen = false;
                screen = Screen.PAUSED;
                return true;
            }

            if (tacticalButton.contains(x, y)) {
                developerPanel = false;
                unitMenuOpen = false;
                tacticalPanel = !tacticalPanel;
                return true;
            }
            if (tacticalPanel) {
                if (formationButton.contains(x, y)) cycleFormationLocked();
                else if (arenaMode && (barricadeButton.contains(x, y) || towerButton.contains(x, y))) {
                    showToastLocked("ARENA'DA SAVUNMA YAPISI YOK");
                } else if (barricadeButton.contains(x, y)) buildOrRepairBarricadeLocked();
                else if (towerButton.contains(x, y)) buildOrRepairTowerLocked();
                else tacticalPanel = false;
                return true;
            }

            if (developerPanel) {
                if (addGoldButton.contains(x, y)) {
                    gold += 1000f;
                    showToastLocked("1000 ALTIN EKLENDİ");
                    return true;
                }
                if (damageButton.contains(x, y)) {
                    if (damageMultiplier < 2f) damageMultiplier = 2f;
                    else if (damageMultiplier < 5f) damageMultiplier = 5f;
                    else if (damageMultiplier < 10f) damageMultiplier = 10f;
                    else damageMultiplier = 1f;
                    showToastLocked("HASAR x" + trimMultiplier(damageMultiplier));
                    return true;
                }
                if (godButton.contains(x, y)) {
                    godMode = !godMode;
                    showToastLocked(godMode ? "ÖLÜMSÜZ MOD AÇIK" : "ÖLÜMSÜZ MOD KAPALI");
                    return true;
                }
                if (speedButton.contains(x, y)) {
                    cycleGameSpeedLocked();
                    return true;
                }
            }

            if (speedHudButton.contains(x, y)) {
                cycleGameSpeedLocked();
                return true;
            }
            if (unitMenuToggleButton.contains(x, y)) {
                tacticalPanel = false;
                developerPanel = false;
                unitMenuOpen = !unitMenuOpen;
                return true;
            }
            if (quickUnitButton.contains(x, y)) {
                buySelectedUnitLocked();
                return true;
            }
            if (unitMenuOpen) {
                if (minerButton.contains(x, y)) selectUnitLocked(UnitType.MINER);
                else if (swordButton.contains(x, y)) selectUnitLocked(UnitType.SWORD);
                else if (spearButton.contains(x, y)) selectUnitLocked(UnitType.SPEAR);
                else if (archerButton.contains(x, y)) selectUnitLocked(UnitType.ARCHER);
                else unitMenuOpen = false;
                return true;
            }

            if (attackButton.contains(x, y)) {
                commandMode = CommandMode.ATTACK;
                showToastLocked("SALDIRI EMRİ VERİLDİ");
                return true;
            }
            if (defendButton.contains(x, y)) {
                commandMode = CommandMode.DEFEND;
                showToastLocked("SAVUNMA HATTI KURULDU");
                return true;
            }

            if (warCryButton.contains(x, y)) {
                activateWarCryLocked();
                return true;
            }
            if (statueShieldButton.contains(x, y)) {
                activateStatueShieldLocked();
                return true;
            }
            if (arrowRainButton.contains(x, y)) {
                activateArrowRainLocked();
                return true;
            }

            if (devButton.contains(x, y)) {
                tacticalPanel = false;
                unitMenuOpen = false;
                developerPanel = !developerPanel;
                return true;
            }
            if (developerPanel) {
                developerPanel = false;
                return true;
            }

        }
        return true;
    }

    private void buyUnitLocked(UnitType type, float cost) {
        if (gold < cost) {
            showToastLocked("YETERLİ ALTIN YOK");
            return;
        }

        int currentType = countUnitsOfTypeLocked(playerUnits, type);
        if (type == UnitType.MINER && currentType >= playerMinerLimitLocked()) {
            showToastLocked("MADENCİ SINIRI: " + playerMinerLimitLocked());
            return;
        }
        if (type == UnitType.SWORD && currentType >= playerSwordLimitLocked()) {
            showToastLocked("SAVAŞÇI SINIRI: " + playerSwordLimitLocked());
            return;
        }
        if (type == UnitType.ARCHER && currentType >= playerArcherLimitLocked()) {
            showToastLocked("OKÇU SINIRI: " + playerArcherLimitLocked());
            return;
        }
        if (type == UnitType.SPEAR && currentType >= playerSpearLimitLocked()) {
            showToastLocked("MIZRAKLI SINIRI: " + playerSpearLimitLocked());
            return;
        }
        if (type != UnitType.MINER && countCombatUnitsLocked(playerUnits) >= playerCombatLimitLocked()) {
            showToastLocked("ORDU SINIRI: " + playerCombatLimitLocked());
            return;
        }

        gold -= cost;
        float spawnX = type == UnitType.MINER
                ? playerBaseX() + 116f * uiScale + countPlayerMinersLocked() * 20f * uiScale
                : playerBaseX() + 148f * uiScale;
        Unit unit = createPlayerUnitLocked(type, spawnX, playerUnits.size());
        if (type == UnitType.MINER) {
            unit.assignedMine = findAvailableMineLocked(currentType);
            unit.minerState = unit.assignedMine >= 0 ? MINER_TO_MINE : MINER_IDLE;
        }
        playerUnits.add(unit);
        if (type != UnitType.MINER) applyFormationLanesLocked();
    }

    private Unit createPlayerUnitLocked(UnitType type, float x, int spawnIndex) {
        Unit unit = Unit.create(type, true, x, spawnIndex);
        int upgrade = type == UnitType.MINER ? minerUpgradeLevel
                : type == UnitType.SWORD ? swordUpgradeLevel
                : type == UnitType.SPEAR ? spearPowerLevel : archerUpgradeLevel;
        float hpMultiplier = 1f + (upgrade - 1) * 0.16f;
        float damageUpgrade = 1f + (upgrade - 1) * 0.18f;
        unit.maxHp *= hpMultiplier;
        unit.damage *= damageUpgrade;
        unit.armor *= 1f + (upgrade - 1) * 0.10f;
        unit.criticalChance += (upgrade - 1) * 0.008f;
        if (type == UnitType.MINER) {
            unit.maxHp *= 1f + diamondMinerBoost * 0.06f;
            unit.speed *= 1f + diamondMinerBoost * 0.04f;
        }
        if (type == UnitType.SWORD || type == UnitType.SPEAR) {
            float diamondPower = 1f + diamondSwordBoost * 0.08f;
            unit.maxHp *= diamondPower;
            unit.damage *= diamondPower * swordWeaponMultiplierLocked();
            if (type == UnitType.SPEAR) {
                unit.range *= (1f + (spearRangeLevel - 1) * 0.13f)
                        * (1f + diamondSwordBoost * 0.05f);
                unit.attackDelay *= Math.max(0.82f, 1f - (spearPowerLevel - 1) * 0.035f);
            }
        }
        if (type == UnitType.ARCHER) {
            unit.maxHp *= 1f + diamondArcherBoost * 0.05f;
            unit.damage *= 1f + diamondArcherBoost * 0.08f;
            unit.range *= 1f + diamondArcherBoost * 0.07f;
            if (battleLevel >= 6) unit.range *= 1.15f;
        }
        unit.hp = unit.maxHp;
        return unit;
    }

    private Unit createEnemyUnitLocked(UnitType type, float x, int spawnIndex) {
        Unit unit = Unit.create(type, false, x, spawnIndex);
        float difficulty = enemyDifficultyMultiplier();
        unit.maxHp *= (1f + (difficulty - 1f) * 0.86f) * chapterEnemyHpMultiplierLocked();
        unit.damage *= (1f + (difficulty - 1f) * 0.78f) * chapterEnemyDamageMultiplierLocked();
        unit.armor *= 1f + Math.min(0.48f, (battleLevel - 1) * 0.012f);
        unit.criticalChance += Math.min(0.08f, (battleLevel - 1) * 0.002f);
        unit.speed *= Math.min(1.32f, 1f + (battleLevel - 1) * 0.018f);
        unit.hp = unit.maxHp;
        return unit;
    }

    private int chapterForLevelLocked(int level) {
        return Math.max(1, Math.min(5, (Math.max(1, level) - 1) / 10 + 1));
    }

    private String chapterNameLocked(int chapter) {
        if (chapter == 2) return "KIZIL ÇÖL";
        if (chapter == 3) return "BUZ GEÇİDİ";
        if (chapter == 4) return "KÜL DİYARI";
        if (chapter == 5) return "GÖLGE HİSARI";
        return "AY VADİSİ";
    }

    private String chapterFactionLocked(int chapter) {
        if (chapter == 2) return "KIZIL AKINCILAR";
        if (chapter == 3) return "BUZ MUHAFIZLARI";
        if (chapter == 4) return "KÜL SAVAŞÇILARI";
        if (chapter == 5) return "GÖLGE LEJYONU";
        return "GÜMÜŞ LEJYON";
    }

    private String chapterEffectLocked(int chapter) {
        if (chapter == 2) return "Maden yükü +%10 • Düşman ekonomi +%6";
        if (chapter == 3) return "Hareket -%8 • Okçu menzili +%10";
        if (chapter == 4) return "Düşman hasarı +%10 • Kule hasarı +%12";
        if (chapter == 5) return "Düşman canı +%12 • Düşman hasarı +%8";
        return "Dengeli savaş alanı";
    }

    private int enemyAccentColorLocked() {
        int chapter = arenaMode ? 6 : chapterForLevelLocked(battleLevel);
        if (chapter == 2) return Color.rgb(211, 91, 52);
        if (chapter == 3) return Color.rgb(96, 184, 225);
        if (chapter == 4) return Color.rgb(222, 82, 55);
        if (chapter == 5) return Color.rgb(151, 91, 218);
        if (chapter == 6) return Color.rgb(176, 104, 238);
        return RED;
    }

    private float chapterEnemyHpMultiplierLocked() {
        if (arenaMode) return 1f;
        return chapterForLevelLocked(battleLevel) == 5 ? 1.12f : 1f;
    }

    private float chapterEnemyDamageMultiplierLocked() {
        if (arenaMode) return 1f;
        int chapter = chapterForLevelLocked(battleLevel);
        if (chapter == 4) return 1.10f;
        if (chapter == 5) return 1.08f;
        return 1f;
    }

    private float chapterEnemyEconomyMultiplierLocked() {
        if (arenaMode) return 1f;
        return chapterForLevelLocked(battleLevel) == 2 ? 1.06f : 1f;
    }

    private float chapterMovementMultiplierLocked(boolean playerSide) {
        if (arenaMode) return 1f;
        return chapterForLevelLocked(battleLevel) == 3 ? 0.92f : 1f;
    }

    private float chapterArcherRangeMultiplierLocked() {
        if (arenaMode) return 1f;
        return chapterForLevelLocked(battleLevel) == 3 ? 1.10f : 1f;
    }

    private float chapterMinerCarryMultiplierLocked() {
        if (arenaMode) return 1f;
        return chapterForLevelLocked(battleLevel) == 2 ? 1.10f : 1f;
    }

    private float chapterTowerDamageMultiplierLocked() {
        if (arenaMode) return 1f;
        return chapterForLevelLocked(battleLevel) == 4 ? 1.12f : 1f;
    }

    private void claimChapterRewardIfNeededLocked(int level) {
        if (level < 10 || level % 10 != 0) return;
        int chapter = chapterForLevelLocked(level);
        if (chapterRewardClaimed[chapter]) return;
        chapterRewardClaimed[chapter] = true;
        earnedChapterDiamonds = 3 + chapter * 2;
        earnedChapterPoints = Math.max(1, chapter);
        diamonds += earnedChapterDiamonds;
        upgradePoints += earnedChapterPoints;
        campaignRecordsDirty = true;
    }

    private void drawChapterBanner(Canvas canvas) {
        float progress = 1f - chapterBannerTimer / 3.2f;
        float fadeIn = Math.min(1f, progress / 0.18f);
        float fadeOut = Math.min(1f, chapterBannerTimer / 0.55f);
        float alpha = Math.max(0f, Math.min(fadeIn, fadeOut));
        float bannerW = Math.min(width * 0.64f, 760f * uiScale);
        float bannerH = Math.max(82f * uiScale, height * 0.135f);
        float y = height * 0.24f + (1f - fadeIn) * -28f * uiScale;
        RectF banner = new RectF(width / 2f - bannerW / 2f, y,
                width / 2f + bannerW / 2f, y + bannerH);
        int accent = arenaMode ? Color.rgb(190, 126, 255)
                : enemyAccentColorLocked();
        paint.setColor(Color.argb((int) (216f * alpha), 8, 12, 23));
        canvas.drawRoundRect(banner, 18f * uiScale, 18f * uiScale, paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(2.6f * uiScale);
        stroke.setColor(Color.argb((int) (235f * alpha),
                Color.red(accent), Color.green(accent), Color.blue(accent)));
        canvas.drawRoundRect(banner, 18f * uiScale, 18f * uiScale, stroke);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(Math.max(25f * uiScale, bannerH * 0.34f));
        paint.setColor(Color.argb((int) (255f * alpha), 255, 226, 157));
        String title = arenaMode ? "SONSUZ ARENA" : chapterNameLocked(chapterForLevelLocked(battleLevel));
        canvas.drawText(title, banner.centerX(), banner.top + bannerH * 0.45f, paint);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(Math.max(12f * uiScale, bannerH * 0.16f));
        paint.setColor(Color.argb((int) (240f * alpha), 218, 225, 238));
        String subtitle = arenaMode ? "ŞAMPİYONLARIN SINAVI"
                : chapterFactionLocked(chapterForLevelLocked(battleLevel)) + " • "
                + chapterEffectLocked(chapterForLevelLocked(battleLevel));
        canvas.drawText(subtitle, banner.centerX(), banner.top + bannerH * 0.75f, paint);
    }

    private float playerStatueMaxHp() {
        return (BASE_MAX_HP + (statueUpgradeLevel - 1) * 430f)
                * (1f + diamondStatueBoost * 0.08f);
    }

    private float enemyStatueMaxHp() {
        return BASE_MAX_HP * (1f + (battleLevel - 1) * 0.16f);
    }

    private float enemyDifficultyMultiplier() {
        if (arenaMode) {
            return 1f + (campaignLevel - 1) * 0.055f + Math.max(0, wave - 1) * 0.085f;
        }
        return 1f + (battleLevel - 1) * 0.115f;
    }

    private float enemyEconomyMultiplier() {
        if (arenaMode) {
            return 1f + (campaignLevel - 1) * 0.035f + Math.max(0, wave - 1) * 0.055f;
        }
        return (1f + (battleLevel - 1) * 0.075f) * chapterEnemyEconomyMultiplierLocked();
    }

    private int minerGoldPerSecond() {
        return 9 + (minerUpgradeLevel - 1) * 3;
    }

    private float swordWeaponMultiplierLocked() {
        if (campaignLevel >= 8) return 1.48f;
        if (campaignLevel >= 5) return 1.30f;
        if (campaignLevel >= 2) return 1.15f;
        return 1f;
    }

    private boolean isArcherUnlockedLocked() {
        return campaignLevel >= 3;
    }

    private String swordUnitTitleLocked() {
        if (campaignLevel >= 8) return "ŞAMPİYON SV" + swordUpgradeLevel;
        if (campaignLevel >= 5) return "MUHAFIZ SV" + swordUpgradeLevel;
        return "SAVAŞÇI SV" + swordUpgradeLevel;
    }

    private String swordRewardLabelLocked() {
        if (campaignLevel >= 8) return "Efsane kılıç";
        if (campaignLevel >= 5) return "Kraliyet kılıcı";
        if (campaignLevel >= 2) return "Çelik kılıç";
        return "Temel kılıç";
    }

    private String difficultyLabelLocked() {
        if (campaignLevel <= 2) return "Zorluk: Kolay";
        if (campaignLevel <= 5) return "Zorluk: Orta";
        if (campaignLevel <= 8) return "Zorluk: Zor";
        return "Zorluk: Efsane";
    }

    private String levelRewardForReachedLevelLocked(int reachedLevel) {
        if (reachedLevel == 2) return "YENİ: ÇELİK KILIÇ + SAVUNMA BARİKATI";
        if (reachedLevel == 3) return "YENİ ASKER: OKÇU AÇILDI";
        if (reachedLevel == 4) return "YENİ SAVUNMA: OKÇU KULESİ";
        if (reachedLevel == 5) return "YENİ ÖDÜL: KRALİYET KILICI";
        if (reachedLevel == 6) return "YENİ ÖDÜL: UZUN YAY  •  Okçu menzili +%15";
        if (reachedLevel == 8) return "YENİ ÖDÜL: EFSANE KILIÇ";
        return "";
    }

    private int upgradeCost(int level, boolean statue) {
        return statue ? 2 + level * 2 : 1 + level * 2;
    }

    private void tryUpgradeLocked(String target) {
        int level;
        boolean statue = "statue".equals(target);
        if (statue) level = statueUpgradeLevel;
        else if ("miner".equals(target)) level = minerUpgradeLevel;
        else if ("sword".equals(target)) level = swordUpgradeLevel;
        else if ("spear_power".equals(target)) level = spearPowerLevel;
        else if ("spear_range".equals(target)) level = spearRangeLevel;
        else level = archerUpgradeLevel;

        if ("archer".equals(target) && !isArcherUnlockedLocked()) {
            showToastLocked("OKÇU BÖLÜM 3'TE AÇILIR");
            return;
        }
        if (level >= 5) {
            showToastLocked("AZAMİ SEVİYEYE ULAŞTI");
            return;
        }
        int cost = upgradeCost(level, statue);
        if (upgradePoints < cost) {
            showToastLocked("YETERLİ GELİŞTİRME PUANI YOK");
            return;
        }
        upgradePoints -= cost;
        if (statue) statueUpgradeLevel++;
        else if ("miner".equals(target)) minerUpgradeLevel++;
        else if ("sword".equals(target)) swordUpgradeLevel++;
        else if ("spear_power".equals(target)) spearPowerLevel++;
        else if ("spear_range".equals(target)) spearRangeLevel++;
        else archerUpgradeLevel++;
        saveProgressLocked();
        invalidateMenuCacheLocked();
        resetGameLocked();
        String label = "spear_power".equals(target) ? "MIZRAK GÜCÜ"
                : "spear_range".equals(target) ? "MIZRAK MENZİLİ" : "GELİŞTİRME";
        showToastLocked(label + " TAMAMLANDI");
    }

    private void resetAllProgressLocked() {
        wins = 0;
        campaignLevel = 1;
        battleLevel = 1;
        mapSelectedLevel = 1;
        mapPage = 0;
        clearCampaignRecordsLocked();
        bossesDefeated = 0;
        upgradePoints = 0;
        statueUpgradeLevel = 1;
        minerUpgradeLevel = 1;
        swordUpgradeLevel = 1;
        spearPowerLevel = 1;
        spearRangeLevel = 1;
        archerUpgradeLevel = 1;
        minerOutfitOwned = 0;
        swordOutfitOwned = 0;
        spearOutfitOwned = 0;
        archerOutfitOwned = 0;
        minerOutfitEquipped = 0;
        swordOutfitEquipped = 0;
        spearOutfitEquipped = 0;
        archerOutfitEquipped = 0;
        diamondStatueBoost = 0;
        diamondMinerBoost = 0;
        diamondSwordBoost = 0;
        diamondArcherBoost = 0;
        commandersDefeated = 0;
        shopPowerPage = false;
        diamonds = 0;
        mineDepth = 0;
        mineProgressPermille = 0;
        lastMineReward = 0;
        profileXp = 0;
        lifetimeWins = 0;
        lifetimeKills = 0;
        lifetimeMineLayers = 0;
        battleChestProgress = 0;
        battleChestsOpened = 0;
        dailyDayKey = currentDailyDayKeyLocked();
        dailyWins = 0;
        dailyMineLayers = 0;
        dailyKills = 0;
        dailyWinClaimed = false;
        dailyMineClaimed = false;
        dailyKillClaimed = false;
        dailyChestClaimed = false;
        missionsAchievementsPage = false;
        for (int index = 0; index < achievementClaimed.length; index++) achievementClaimed[index] = false;
        heroLevel = 1;
        heroXp = 0;
        heroPowerLevel = 0;
        heroArmorLevel = 0;
        heroLeadershipLevel = 0;
        heroSpawned = false;
        arenaMode = false;
        arenaBestWave = 0;
        arenaBestKills = 0;
        arenaRuns = 0;
        arenaKillsThisRun = 0;
        arenaLastRewardWave = 0;
        fullResetArmed = false;
        resetConfirmTimer = 0f;
        prepareMineLayerLocked();
        resetGameLocked();
        saveProgressLocked();
        invalidateSceneCachesLocked();
    }

    private void saveProgressLocked() {
        SharedPreferences.Editor editor = preferences.edit()
                .putInt("wins", wins)
                .putInt("campaign_level", campaignLevel)
                .putInt("upgrade_points", upgradePoints)
                .putInt("statue_upgrade", statueUpgradeLevel)
                .putInt("miner_upgrade", minerUpgradeLevel)
                .putInt("sword_upgrade", swordUpgradeLevel)
                .putInt("spear_power_upgrade", spearPowerLevel)
                .putInt("spear_range_upgrade", spearRangeLevel)
                .putInt("archer_upgrade", archerUpgradeLevel)
                .putInt("miner_outfit_owned", minerOutfitOwned)
                .putInt("sword_outfit_owned", swordOutfitOwned)
                .putInt("spear_outfit_owned", spearOutfitOwned)
                .putInt("archer_outfit_owned", archerOutfitOwned)
                .putInt("miner_outfit_equipped", minerOutfitEquipped)
                .putInt("sword_outfit_equipped", swordOutfitEquipped)
                .putInt("spear_outfit_equipped", spearOutfitEquipped)
                .putInt("archer_outfit_equipped", archerOutfitEquipped)
                .putInt("diamond_statue_boost", diamondStatueBoost)
                .putInt("diamond_miner_boost", diamondMinerBoost)
                .putInt("diamond_sword_boost", diamondSwordBoost)
                .putInt("diamond_archer_boost", diamondArcherBoost)
                .putInt("commanders_defeated", commandersDefeated)
                .putInt("bosses_defeated", bossesDefeated)
                .putInt("diamonds", diamonds)
                .putInt("mine_depth", mineDepth)
                .putInt("mine_progress", mineProgressPermille)
                .putInt("profile_xp", profileXp)
                .putInt("lifetime_wins", lifetimeWins)
                .putInt("lifetime_kills", lifetimeKills)
                .putInt("lifetime_mine_layers", lifetimeMineLayers)
                .putInt("battle_chest_progress", battleChestProgress)
                .putInt("battle_chests_opened", battleChestsOpened)
                .putInt("daily_day_key", dailyDayKey)
                .putInt("daily_wins", dailyWins)
                .putInt("daily_mine_layers", dailyMineLayers)
                .putInt("daily_kills", dailyKills)
                .putInt("daily_win_claimed", dailyWinClaimed ? 1 : 0)
                .putInt("daily_mine_claimed", dailyMineClaimed ? 1 : 0)
                .putInt("daily_kill_claimed", dailyKillClaimed ? 1 : 0)
                .putInt("daily_chest_claimed", dailyChestClaimed ? 1 : 0)
                .putInt("hero_level", heroLevel)
                .putInt("hero_xp", heroXp)
                .putInt("hero_power", heroPowerLevel)
                .putInt("hero_armor", heroArmorLevel)
                .putInt("hero_leadership", heroLeadershipLevel)
                .putInt("arena_best_wave", arenaBestWave)
                .putInt("arena_best_kills", arenaBestKills)
                .putInt("arena_runs", arenaRuns);
        for (int index = 0; index < achievementClaimed.length; index++) {
            editor.putInt("achievement_" + index, achievementClaimed[index] ? 1 : 0);
        }
        for (int chapter = 1; chapter <= 5; chapter++) {
            editor.putInt("chapter_reward_" + chapter, chapterRewardClaimed[chapter] ? 1 : 0);
        }
        if (campaignRecordsDirty) {
            for (int level = 1; level <= 50; level++) {
                editor.putInt("level_stars_" + level, levelStars[level]);
                editor.putInt("boss_reward_" + level, bossRewardClaimed[level] ? 1 : 0);
            }
            campaignRecordsDirty = false;
        }
        editor.apply();
    }

    private void clearCampaignRecordsLocked() {
        for (int level = 1; level <= 50; level++) {
            levelStars[level] = 0;
            bossRewardClaimed[level] = false;
        }
        for (int chapter = 1; chapter <= 5; chapter++) chapterRewardClaimed[chapter] = false;
        campaignRecordsDirty = true;
    }

    private int readIntPreference(String key, int fallback, int min, int max) {
        int value = fallback;
        try {
            value = preferences.getInt(key, fallback);
        } catch (ClassCastException invalidStoredType) {
            preferences.edit().remove(key).apply();
        } catch (Throwable ignored) {
            value = fallback;
        }
        return Math.max(min, Math.min(max, value));
    }

    private static int clampUpgradeLevel(int value) {
        return Math.max(1, Math.min(5, value));
    }

    private int menuProgressHashLocked() {
        int hash = campaignLevel;
        hash = hash * 31 + upgradePoints;
        hash = hash * 31 + statueUpgradeLevel;
        hash = hash * 31 + minerUpgradeLevel;
        hash = hash * 31 + swordUpgradeLevel;
        hash = hash * 31 + spearPowerLevel;
        hash = hash * 31 + spearRangeLevel;
        hash = hash * 31 + archerUpgradeLevel;
        hash = hash * 31 + minerOutfitOwned;
        hash = hash * 31 + swordOutfitOwned;
        hash = hash * 31 + spearOutfitOwned;
        hash = hash * 31 + archerOutfitOwned;
        hash = hash * 31 + minerOutfitEquipped;
        hash = hash * 31 + swordOutfitEquipped;
        hash = hash * 31 + archerOutfitEquipped;
        hash = hash * 31 + diamondStatueBoost;
        hash = hash * 31 + diamondMinerBoost;
        hash = hash * 31 + diamondSwordBoost;
        hash = hash * 31 + diamondArcherBoost;
        hash = hash * 31 + commandersDefeated;
        hash = hash * 31 + bossesDefeated;
        for (int level = 1; level <= 50; level++) hash = hash * 31 + levelStars[level];
        hash = hash * 31 + diamonds;
        hash = hash * 31 + mineDepth;
        hash = hash * 31 + profileXp;
        hash = hash * 31 + lifetimeWins;
        hash = hash * 31 + lifetimeKills;
        hash = hash * 31 + lifetimeMineLayers;
        hash = hash * 31 + battleChestProgress;
        hash = hash * 31 + dailyDayKey;
        hash = hash * 31 + dailyWins;
        hash = hash * 31 + dailyMineLayers;
        hash = hash * 31 + dailyKills;
        hash = hash * 31 + arenaBestWave;
        hash = hash * 31 + arenaBestKills;
        hash = hash * 31 + arenaRuns;
        hash = hash * 31 + (dailyWinClaimed ? 1 : 0);
        hash = hash * 31 + (dailyMineClaimed ? 1 : 0);
        hash = hash * 31 + (dailyKillClaimed ? 1 : 0);
        hash = hash * 31 + (dailyChestClaimed ? 1 : 0);
        for (boolean claimed : achievementClaimed) hash = hash * 31 + (claimed ? 1 : 0);
        hash = hash * 31 + heroLevel;
        hash = hash * 31 + heroXp;
        hash = hash * 31 + heroPowerLevel;
        hash = hash * 31 + heroArmorLevel;
        hash = hash * 31 + heroLeadershipLevel;
        return hash;
    }

    private void invalidateMenuCacheLocked() {
        menuCacheWins = -1;
        menuCacheProgressHash = -1;
        if (menuCache != null) {
            menuCache.recycle();
            menuCache = null;
        }
    }

    private static final class Unit {
        UnitType type;
        float x;
        float hp;
        float maxHp;
        float damage;
        float armor;
        float criticalChance;
        float speed;
        float range;
        float attackDelay;
        float attackCooldown;
        float anim;
        float hitFlash;
        float hitRecoil;
        float attackAnim;
        float dustClock;
        float workTimer;
        float carriedGold;
        int lane;
        int formationSlot;
        int assignedMine = -1;
        int minerState = MINER_TO_MINE;
        boolean commander;
        boolean boss;
        boolean siege;
        boolean hero;
        boolean playerSide;
        boolean rangedAttack;
        float visualScale = 1f;
        boolean moving;

        static Unit create(UnitType type, boolean player, float x, int spawnIndex) {
            Unit unit = new Unit();
            unit.type = type;
            unit.playerSide = player;
            unit.x = x;
            unit.attackCooldown = 0.25f;
            unit.formationSlot = spawnIndex;
            unit.lane = type == UnitType.MINER ? 0 : (spawnIndex % 3) - 1;

            if (type == UnitType.MINER) {
                unit.maxHp = 75f;
                unit.damage = 0f;
                unit.armor = 4f;
                unit.criticalChance = 0f;
                unit.speed = 48f;
                unit.range = 0f;
                unit.attackDelay = 1f;
            } else if (type == UnitType.SWORD) {
                unit.maxHp = player ? 175f : 145f;
                unit.damage = player ? 28f : 22f;
                unit.armor = player ? 30f : 25f;
                unit.criticalChance = player ? 0.075f : 0.060f;
                unit.speed = player ? 56f : 48f;
                unit.range = 48f;
                unit.attackDelay = 0.72f;
            } else if (type == UnitType.SPEAR) {
                unit.maxHp = player ? 152f : 132f;
                unit.damage = player ? 27f : 22f;
                unit.armor = player ? 24f : 21f;
                unit.criticalChance = player ? 0.095f : 0.075f;
                unit.speed = player ? 51f : 45f;
                unit.range = player ? 250f : 225f;
                unit.attackDelay = 1.16f;
            } else {
                unit.maxHp = player ? 110f : 96f;
                unit.damage = player ? 34f : 28f;
                unit.armor = player ? 9f : 7f;
                unit.criticalChance = player ? 0.105f : 0.085f;
                unit.speed = player ? 45f : 41f;
                unit.range = player ? 285f : 245f;
                unit.attackDelay = 1.08f;
            }
            unit.hp = unit.maxHp;
            return unit;
        }
    }

    private static final class Projectile {
        Unit target;
        int kind;
        float x;
        float y;
        float startX;
        float startY;
        float lastTargetX;
        float lastTargetY;
        float speed;
        float damage;
        DamageType damageType;
        boolean critical;
        float life;
        float travelDuration;
        float travelElapsed;
        float arcHeight;
        float angleX;
        float angleY;
        float previousX;
        float previousY;
        boolean playerSide;
        boolean targetsBase;
    }

    private static final class Impact {
        float x;
        float y;
        float life;
        float maxLife;
        int color;
    }

    private static final class FloatingText {
        float x;
        float y;
        float life;
        float maxLife;
        int color;
        String value;
    }

    private static final class Particle {
        static final int KIND_DUST = 0;
        static final int KIND_SPARK = 1;
        static final int KIND_DEBRIS = 2;
        static final int KIND_SMOKE = 3;

        float x;
        float y;
        float vx;
        float vy;
        float gravity;
        float size;
        float life;
        float maxLife;
        float rotation;
        float spin;
        int color;
        int kind;
    }

    private static final class DeathEffect {
        UnitType type;
        float x;
        float y;
        float life;
        float maxLife;
        float rotation;
        float rotationSpeed;
        float fallSpeed;
        float vx;
        float vy;
        float groundY;
        int lane;
        boolean playerSide;
        boolean bounced;
    }
}

# UYGAR WARS MVP - no custom ProGuard rules required.

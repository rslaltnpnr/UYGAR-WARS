# UYGAR WARS v0.5.0 — Battlefield Control & Spearman Update

AndroidIDE / Code Studio ile açılabilen telefon ve tablet uyumlu Android oyun projesidir.

## Bu sürümde yenilenen arayüz

- Ana menüde sekiz küçük düğme yerine iki sıra hâlinde dört büyük menü kartı
- Daha kalın metalik çerçeve, çift iç kenar, yüzey parlaması ve daha okunaklı yazılar
- Ana eylem düğmelerinde altın çift çerçeve, merkez ışığı ve yön oku
- Geri düğmeleri ve ekranlar arası geçişlerde daha büyük dokunma alanları
- Bölüm haritasında büyük bölüm kartları ve belirgin seçili/kilitli/tamamlanmış durumları
- Boss bölümlerine özel kırmızı metal kart ve boss rozeti
- Krallık geçiş düğmelerinde krallık adları ve daha büyük oklar
- Haritanın altındaki boş alan yerine seçili bölüm bilgi paneli
- Seçili bölümün zorluğu, yıldızı, bölge etkisi ve boss bilgisi
- Telefon, geniş ekran telefon, 16:10 tablet ve 4:3 tablet için yenilenmiş yerleşim

## Korunan sistemler

- Beş krallık ve farklı savaş alanları
- Sonsuz Arena ve rekor sistemi
- Oyuncu komutanı ve liderlik yetenekleri
- 50 bölümlük harita, yıldız sistemi ve boss savaşları
- Günlük görevler, sandıklar, başarımlar ve oyuncu profili
- Savunma yapıları, formasyonlar ve kuşatma birlikleri
- Elmas madeni, kıyafet mağazası ve kalıcı güçler
- Android 16 güvenli başlangıç düzeltmesi

## Kurulum

1. ZIP dosyasını çıkartın.
2. Code Studio içinde `UYGAR_WARS_v0_5_0_project` klasörünü açın.
3. Gradle işleminin tamamlanmasını bekleyin.
4. Quick Run çalıştırın.


- Arena Rework: arena orta hatta toplandı, arena'da kule/barikat kapatıldı, oyuncu birlikleri sağ uca yığılmak yerine merkez hatta bekliyor.


## v0.4.1.1
- Arena merkez savaş halkası eklendi.
- Arena şampiyonu giriş portalı ve ışık efekti eklendi.
- Arena sonuçları; dalga, düşman, şampiyon, elmas, XP ve rekorlarla ayrı ekranda gösterilir.


- Ana menü 4 ana başlığa ayrıldı: Savaş, Gelişim, Ekonomi ve Ayarlar.
- Alt ekranlar: Battle Hub, Progress Hub, Economy Hub ve System Hub.


- Savaş HUD sadeleştirildi: üst bilgi barı 3 ana bölüme indirildi, komut/skill alanları daha kompakt hale getirildi.
- Birlik görselleri yenilendi: kask, omuzluk, göğüs plakası, okçu okluğu, madenci sırt çantası ve yüz detayları eklendi.


- Battlefield Background Polish: savaş alanına derinlik katmanları, bölgeye özel çevre objeleri, daha yoğun sis ve zemin doku çizgileri eklendi.


- Statue/Base Realism Update: üs platformu büyütüldü, yan destek kuleleri, sancaklar, zincirler, gelişmiş isim plakası ve tema bazlı düşman heykel isimleri eklendi.
- Hasarlı heykellerde çatlaklar ve moloz daha belirgin hale getirildi.


- Soldier Animation Update: yürüyüş ritmi, gövde eğimi, pelerin salınımı, saldırı hamlesi, okçu yay çekişi ve madenci kazma vuruşu geliştirildi.
- Vurulan birliklere geri tepme; ölen birliklere fizik tabanlı düşüş, kayma ve küçük sekme eklendi.
- v0.3.1'de eksik kalan drawUnit çizim bloğu geri getirildi.


- Campaign Map Rework: 2x5 kart ızgarası kaldırıldı; kıvrımlı sefer yolu, dairesel bölüm düğümleri, boss kaleleri, krallık amblemleri ve bölüm ilerleme özeti eklendi.
- Alt seçim paneli krallık rengi, sefer bilgisi ve daha güçlü bölüm başlatma alanıyla yeniden tasarlandı.


- Combat Feel Update: güçlü vuruşlarda hit-stop, ekran darbesi, renkli pulse overlay ve haptik geri bildirim eklendi.
- Yetenek kullanımında (Nara / Kalkan / Ok Yağmuru) sahne tepkisi artırıldı.
- Zafer ve yenilgi ekranına altın/kırmızı sonuç pulse efekti eklendi.


- Gerçek ses sistemi eklendi: kılıç, ok, kazma, üs darbesi, boss girişi, yetenek, zafer ve yenilgi sesleri.
- Kampanya ve Arena için farklı düşük seviyeli döngü savaş müzikleri eklendi.
- Ayarlar ekranına kalıcı SES AÇIK/KAPALI düğmesi eklendi.
- Ses yoğunluğu, aynı anda çok fazla efekt çalmaması için sınıf bazlı cooldown ile dengelendi.


## v0.4.1.1 Derleme Hotfix
- `Unit.y()` çağrısı kaldırıldı; birimin ekran yüksekliği `groundY + laneOffset(target.lane)` ile hesaplanıyor.
- Parametre kabul etmeyen `Impact` kurucusu yerine mevcut `addImpactLocked(...)` yardımcı metodu kullanılıyor.
- Kullanıcının gönderdiği `compileDebugJavaWithJavac` içindeki iki hata giderildi.


## v0.4.2 — Gelişmiş Ses Ayarları

- Müzik ve savaş efektleri ayrı açılıp kapatılabilir.
- Müzik ve efekt seviyeleri ayrı olarak %25, %50, %75 ve %100 arasında değiştirilebilir.
- Ay Vadisi, Kızıl Çöl, Buz Geçidi, Kül Diyarı ve Gölge Hisarı için özgün prosedürel savaş müzikleri eklendi.
- Arena kendi Sonsuz Yarık müziğini kullanmaya devam eder.
- Tüm seçimler SharedPreferences içinde kalıcı olarak saklanır.


## v0.5.0 — Savaş Alanı Kontrolü ve Mızraklı Birlik

- Savaş alanı iki heykel arasında parmakla yatay sürüklenebilir; sürükleme sonrası otomatik kamera kısa süre bekler.
- Oyun hızı 1x, 2x, 3x ve 4x arasında değiştirilebilir.
- Oyuncu ve düşman okçularının menzili artırıldı; oklar artık parabolik/kavisli uçuş kullanır.
- Yeni Mızraklı birlik eklendi: yakında mızrak saplar, uzakta mızrak fırlatır.
- Fırlatılan mızrak normal yakın dövüş hasarının 2 katını verir.
- Kılıç, ok, yaralanma, kazma ve yürüyüş sesleri daha gerçekçi katmanlı WAV sesleriyle yenilendi.
- Mızrak fırlatma ve mızrak darbe sesleri eklendi.


## v0.5.2 – UI, Spearman Progression & Battle Audio Upgrade
- Mızraklı birlik için ayrı güç ve menzil geliştirmeleri eklendi.
- Savaş ekranına heykelleri ve görünür kamera alanını gösteren mini kamera çubuğu eklendi.
- Tüm butonlar zırhlı/oyma savaş temalı tasarımla yenilendi.
- Savaş içi komut, yetenek ve birlik kartları küçültüldü.
- Krallık müzikleri daha savaş odaklı özgün davul, drone ve boru katmanlarıyla yenilendi.
- Kılıç, ok, yaralanma, kazma, yürüyüş ve mızrak sesleri daha profesyonel katmanlarla değiştirildi.


## v0.5.2
- Açılır/kapanır yeni birlik seçim menüsü eklendi.
- Seçilen birlik için tek dokunuşla hızlı eğitim kartı eklendi.
- Savaş HUD'ına 1x–4x hız düğmesi eklendi.
- Mızraklı birlik için savaşçıdan bağımsız dört kıyafet/zırh seviyesi eklendi.
- Mızraklı kıyafetleri ayrı kaydedilir ve mağazada ayrı karttan yönetilir.


## v0.5.3 – Kritik Vuruş, Zırh ve Hasar Türleri

- KESME, DELİCİ ve DARBE olmak üzere üç hasar türü eklendi.
- Savaşçı, mızraklı, okçu ve madenci için ayrı zırh değerleri tanımlandı.
- Kesme, delici ve darbe hasarlarının birlik türlerine göre güçlü/zayıf eşleşmeleri eklendi.
- Oyuncu ve düşman birliklerine kritik vuruş ihtimali eklendi.
- Okçu ve mızraklılar daha yüksek temel kritik şansına sahip.
- Komutan, kahraman, boss ve Savaş Narası kritik şansını artırır.
- Kritik vuruş 1,72 kat hasar, KRİTİK yazısı, parçacık, hit-stop, sarsıntı ve haptik tepki üretir.
- versionName 0.5.3 / versionCode 36.
